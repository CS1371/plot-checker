function [newlift] = airfoilz(ang, lift, newang)

fit = polyfit(ang, lift, 2);
xvals = min(ang):max(ang);
fit = fit(1).*xvals.^2+fit(2).*xvals+fit(3);
hold on
plot(xvals, fit, 'k-');
plot(ang, lift, 'b*');
hold off
newlift = interp1(xvals, fit, newang, 'spline');
newlift = round(newlift, 3);

end