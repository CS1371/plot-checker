function [str] = wordDist(filename)
fh = fopen(filename);
line = fgetl(fh);
wcin = [];
str = 'We''re at Georgia Tech, we can read that!';
tech = 0;
while ischar(line)
    while ~isempty(line)
        [word, line] = strtok(line, ' ');
        word = lower(word);
        letter = word(1);
        if strcmp(word, 'technology')
            tech = 1;
            str = 'We''re at Georgia Tech, we can read that!';
        end
        wc = 0;
        while ~isempty(letter)
            if lower(letter)>96 && lower(letter)<123
                wc = wc+1;
            end
            word = word(2:end);
            if ~isempty(word)
                letter = word(1);
            else
                letter = [];
            end
        end
        if wc>13 && tech~=1
            str = 'We''re at Georgia Tech, we can''t read that. :(';
        end
        wcin = [wcin wc];
    end
    line = fgetl(fh);
end
fclose(fh);
ca = {};
for x=1:max(wcin)
    ca{x,1} = x;
    ca{x,2} = length(find(wcin==x));
end
arr=cell2mat(ca);
x = arr(:,1);
y = arr(:,2);
bar(x,y);
title(sprintf('Can we read %s?', filename(1:end-4)));
xlabel('Length of Word');
ylabel('Number of Occurances');


end