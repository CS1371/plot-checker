function cellGrowth(cellcount, t)
hold on
mean = zeros(1, length(t))+sum(cellcount)./length(cellcount);
plot(t, cellcount, 'r.');
plot(t, mean, 'b-.');
plot(t, ones(1,length(t))*max(cellcount), 'm--');
hold off
xmin = min(t)-.05.*max(t);
xmax = max(t)+.05.*max(t);
ymin = min(cellcount)-.05.*max(cellcount);
ymax = max(cellcount)+.05.*max(cellcount);

axis([xmin, xmax, ymin, ymax]);
axis square;
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');

end