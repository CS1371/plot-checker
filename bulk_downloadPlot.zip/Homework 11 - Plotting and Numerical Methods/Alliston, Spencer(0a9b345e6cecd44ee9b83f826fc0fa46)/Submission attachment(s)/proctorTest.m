function [str, area] = proctorTest(xls, perc)

[ca, headers] = xlsread(xls);
diffy = diff(ca(:,2));
diffx = diff(ca(:,1))./2+ca(1:end-1,1);
diffeq = diffy./diff(ca(:,1));
perfinal = interp1(diffeq, diffx, 0, 'spline');
duw = interp1(ca(:,1), ca(:,2), perfinal, 'spline');
perfinal = round(perfinal, 3);
duwround = round(duw, 3);
unit1 = headers{1}(19:end-1);
unit2 = headers{2}(18:end-1);
str=sprintf('%0.3f %s, %0.3f %s', perfinal, unit1, duwround, unit2);

maxline = duw.*(perc./100);
ca(:,2) = ca(:,2)-maxline;
mask = ca(:,2)>0;
x = ca(:,1);
newx = x(mask);
y = ca(:,2);
newy = y(mask);
area = round(trapz(newx, newy),3);

end