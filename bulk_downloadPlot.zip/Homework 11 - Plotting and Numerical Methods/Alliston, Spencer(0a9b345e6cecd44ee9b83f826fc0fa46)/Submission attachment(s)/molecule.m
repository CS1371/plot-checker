function molecule(lengths, angles, rings)

position = [0; 0];
totpos = [0;0];
angle = 0;
for i = 1:length(lengths)
    angle = angle+angles(i);
    new=[cosd(angle) -sind(angle); sind(angle) cosd(angle)]*[length(i); 0];
    position = position+new;
    totpos = [totpos position];
end
[carr, hexr] = findCenter(totpos);
circles = carr(:, rings);
hexr = hexr(rings);
hold on
plot(totpos(1,:), totpos(2,:), 'k-');

for t = 1:length(hexr)
    theta = linspace(0,2.*pi);
    r = hexr(t).*.65;
    plot(circles(1,t)+r*cos(theta), circles(2,t)+r*sin(theta), 'b');
    
end
hold off
axis equal
axis off

end