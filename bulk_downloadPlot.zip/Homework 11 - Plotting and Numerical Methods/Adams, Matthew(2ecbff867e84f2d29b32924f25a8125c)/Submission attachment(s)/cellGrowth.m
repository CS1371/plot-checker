function cellGrowth(cellVec,timeVec)
xLength = length(timeVec);% Here i find the length of the time vector
newVec = ones(1,xLength);% I do this so that i can plot the max and average population
xmin = min(timeVec) - (.05.* max(timeVec));% These lines create the axes bounds
xmax = max(timeVec) .* 1.05;
ymin = min(cellVec) - (.05.* max(cellVec));
ymax = max(cellVec) .* 1.05;
newAxis = [xmin, xmax, ymin, ymax]; % I create the new axis vector
figure;
plot(timeVec,cellVec,'r.');% I plot the original data in red points
hold on;
meanPop = mean(cellVec);
meanPop = meanPop .* newVec; %I find the mean population and plot it
plot(timeVec,meanPop,'b-.');
maxPop = max(cellVec);
maxPop = maxPop .* newVec; %I find the max population plot it
plot(timeVec,maxPop,'m--');
title('Cell Growth vs Time'); %I then title the graph and axes and square the axes
xlabel('Time');
ylabel('# Cells');
axis(newAxis); %I apply the new axes
axis square;
end
