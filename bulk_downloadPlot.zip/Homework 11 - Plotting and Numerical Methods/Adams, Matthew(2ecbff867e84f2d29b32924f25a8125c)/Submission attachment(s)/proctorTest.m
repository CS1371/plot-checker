function [str, curveArea] = proctorTest(file,percentile)
[num, txt, ~] = xlsread(file);% The first thing i do is get the data and seperate it for ease of use
moistContent = num(:,1);
DryWeight = num(:,2);
moistUnits = txt{1};
dryUnits = txt{2};
index1 = find(moistUnits == '(');
index2 = find(moistUnits == ')');
moistUnits = moistUnits((index1 + 1):(index2 - 1));% I then find the units for the moisture content
index3 = find(dryUnits == '(');
index4 = find(dryUnits == ')');
dryUnits = dryUnits((index3 + 1):(index4 - 1)); %I also find the units for the dry content

derivY = diff(DryWeight)./diff(moistContent);% I find the derivative of y
derivX = [];
for i = 1:length(moistContent)-1
    midpoint = (moistContent(i) + moistContent(i+1))./2;% I create the mid point vector of x
    derivX = [derivX; midpoint];
end

xmax1 = interp1(derivY,derivX,0,'spline'); %I then use spline interpolation to find where the derivative equals 0
ymax1 = interp1(moistContent,DryWeight,xmax1,'spline'); %I then interpolate using that value and the original data
xmax = round(xmax1,3); %i round my outputs
ymax = round(ymax1,3);
str = sprintf('%0.3f %s, %0.3f %s', xmax,moistUnits,ymax,dryUnits); %I put my outputs into the correct string
minDry = (percentile./100) .* ymax1;
newDry = DryWeight - minDry;
newDry = newDry(newDry >= 0);
newMoist = moistContent(newDry >= 0); %I then find the values corresponding to an area above the percentile and integrate
curveArea = trapz(newMoist,newDry);
curveArea = round(curveArea,3);% I round my answer
end

