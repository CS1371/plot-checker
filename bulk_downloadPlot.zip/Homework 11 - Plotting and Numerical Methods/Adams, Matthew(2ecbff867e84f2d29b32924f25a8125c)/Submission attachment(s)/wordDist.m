function str = wordDist(file)
fid = fopen(file);% I open the file,get the first line and initialize the output
line = fgetl(fid);
vec = [];
str = 'We''re at Georgia Tech, we can''t read that :(';
while ischar(line)
    line = line((line == ' ') | (line >= 'a' & line <= 'z') | (line >= 'A' & line <= 'Z')); %I get just the letters and spaces in each line
    while ~isempty(line)
        [word, line] = strtok(line,' ');% I strtok each line and find the length of each word
        if strcmpi(word, 'technology')
            str = 'We''re at Georgia Tech, we can read that!'; %I also check the word against technology
        end
        vec = [vec length(word)];% I put the word in a vector
    end
    line = fgetl(fid);
end
wordLengths = vec(vec > 13);% I find which words are greater than 13 in length
if isempty(wordLengths) 
    str = 'We''re at Georgia Tech, we can read that!'; %I set the output
end
vec2 = 1:max(vec);
vec3 = [];
for i = 1:length(vec2)
    newVec = vec(vec == i); % i then use a for loop as a counter in preparation to make a bar graph
    vec3 = [vec3 length(newVec)];
end     
bar(vec2,vec3);% I create the bar graph and label it accordingly
xlabel('Length of Word');
ylabel('Number of Occurrences');
TitleStr = sprintf('Can we read %s?',file(1:end-4));
title(TitleStr);
end


    

        
