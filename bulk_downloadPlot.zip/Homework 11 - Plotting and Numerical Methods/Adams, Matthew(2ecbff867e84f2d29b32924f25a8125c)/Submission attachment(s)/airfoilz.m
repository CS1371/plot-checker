function coefficients = airfoilz(angleVec1,liftVec,angleVec2)
poly = polyfit(angleVec1,liftVec,2);%I use poly fit to find a 2nd degree polynomial that fits the data
newAngles = [min(angleVec1):max(angleVec1)];%I then create a vector of angles from the min of the angles to the max in steps of 1 and as integer values
newLift = polyval(poly,newAngles);% I calculate the new lifts based upon the new angles of attack that i just found
figure(1);
plot(newAngles,newLift,'k');% I then plot the new data
hold on;
plot(angleVec1,liftVec,'b*');% I also plot the old data
coefficients = interp1(newAngles,newLift,angleVec2,'spline');% I use spline interpolation to calculate the coefficients at the specified angles
coefficients = round(coefficients,3);
end