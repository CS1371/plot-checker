function molecule(lengthVec, angleVec, hexVec)
xold = 0; %My code works off of a polar system with a shifted center for each point
yold = 0; %So i initialize the x and y value vectors
for i =1:length(lengthVec)
    xnew = xold(i) + (lengthVec(i) * cos(((sum(angleVec(1:i)) .* pi)/180))); %In this loop i calculate the new points using polar coordinates and convert to x and y and store them
    ynew = yold(i) + (lengthVec(i) * sin(((sum(angleVec(1:i)) .* pi)/180))); %I use my new calculate points as the new center of the polar coordinates
    xold = [xold xnew]; %I store the x and y values in seperate vectors
    yold = [yold ynew];
end
figure(1);
plot(xold, yold,'k'); %I create a figure and plot the values, fixing the axis and turning them off
hold on;
axis equal;
axis off;
pointArr = [xold; yold]; %Here i concatenate the vectors into an array to use the helper function
[benzeneCenters , radii] = findCenter(pointArr); %Here i use the helper funtion to find the center and radii of the benzene rings
if ~isempty(hexVec) %I use this if statement, because if there are no benzene rings at all, it is useless to continue to run the code
    for n = 1:length(hexVec) %hexVec should equal the length of the output of the helper function, so either could be used, but i used hexVec because it only had one row, so i did not have to worry about there being more rows than columns
        if hexVec(n)
            theta = linspace(0,2.*pi); %I use linspace to create 100 values between 0 and 2pi and then plot the circle, using the benzene centers as the center of the polar coordinates
            x = benzeneCenters(1,n) + (0.65 .* radii(n) .* cos(theta));
            y = benzeneCenters(2,n) + (0.65 .* radii(n) .*sin(theta));
            plot(x,y,'b');
        end
    end
end
end
