function lift=airfoilz(angle, coef, det)
clf
figure(2)
plot(angle,coef,'b*')
hold on;

mypoly=polyfit(angle,coef,2)
xvals=linspace(min(angle),max(angle))
myvals=polyval(mypoly,xvals)
plot(xvals,myvals,'k')

mindet=min(det)
maxdet=max(det)
bleh=[]
test=interp1(xvals,myvals,det,'spline')
new=0
for i=1:length(det)
    if det(i) < mindet | det(i) > maxdet
        new=interp1(xvals, myvals, det,'spline')
    elseif det(i)>= mindet & det(i) <= maxdet
        new=interp1(xvals, myvals,det,'spline','extrap')
    end
    bleh=[bleh new]
end
lift=round(new,3)
end