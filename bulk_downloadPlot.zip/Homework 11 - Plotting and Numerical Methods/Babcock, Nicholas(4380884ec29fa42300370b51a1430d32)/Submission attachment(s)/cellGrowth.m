function blah= cellGrowth(ct, time)
clf;
figure(1)
clf;
x=time;
y=ct;
plot(x,y,'r.')
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
xrange=max(x)-min(x);
yrange=max(y)-min(y);
axis([(min(x)-xrange.*0.05) (max(x)+xrange.*0.05) (min(y)-yrange.*0.05) (max(y)+yrange.*0.05)]);
hold on;
ones=(linspace(1,1,length(x)));
plot(x,max(y).*ones,'m--')
hold on;
means=mean(y);
plot(x,means.*ones,'b-.')
end