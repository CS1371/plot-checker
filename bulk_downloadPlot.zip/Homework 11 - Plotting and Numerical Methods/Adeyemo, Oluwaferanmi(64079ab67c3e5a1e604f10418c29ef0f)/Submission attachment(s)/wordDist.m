function [level] = wordDist(stuff)
fh = fopen(stuff);%open the file
line = fgetl(fh);
letters = [];
read = false;
 
 while ischar(line)
     mask = (line >='a' & line <= 'z' | line >= 'A' & line <= 'Z'| line == ' ');% Just want letters and space
     line = line(mask);
     [word, remain] = strtok(line);
     while ~isempty(remain)%go inside each line and read it now
         if strcmpi(word,'technology') == 1 %find technology
             read = true;
         end
         num = length(word);
         letters = [letters num];
         [word, remain] = strtok(remain);
     end
     line = fgetl(fh);
 end
 
all = length(letters);
mask2 = letters <= 13;
need = sum(mask2);
gotem = (all==need);
if read == true | gotem == true
    level = sprintf('We''re at Georgia Tech, we can read that!');
else
    level = sprintf('We''re at Georgia Tech, we can''t read that :(')
end
 
xvalues = min(letters):1:max(letters)
yvalues = [];
crucial = letters;
for i = xvalues %count the amount of occurences
    mask3 = (crucial == i);
    howMany = sum(mask3);
    yvalues = [yvalues howMany];
    crucial(crucial == i) = [];
end
 
bar(xvalues,yvalues)%create all my labels
xlabel('Length of Word');
ylabel('Number of Occurrences');
titleName = stuff(1:end-4);
title(sprintf('Can we read %s?',titleName));
end
        
    