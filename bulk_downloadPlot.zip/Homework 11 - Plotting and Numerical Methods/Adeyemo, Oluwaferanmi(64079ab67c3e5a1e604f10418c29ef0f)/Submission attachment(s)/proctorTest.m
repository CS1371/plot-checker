function [string, area]=proctorTest(points, percentile)
[num txt raw]= xlsread(points)%i need to read the excel files first
unitx=raw{1,1}(19:end-1) %Get the unit out for x
unity=raw{1,2}(18:end-1)% I want to get the unit out for y
x=num(:,1) %all x values needed
y=num(:,2)%all y values needed
derivativex=x(1:end-1) + (diff(x)./2) %the derivative with x perspectiveb
derivativey=diff(y)./diff(x) %the dreivative with y perspective
maxa=spline(derivativey,derivativex,0)
maxa2=spline(x,y,maxa)
string=sprintf('%0.3f %s, %0.3f %s', maxa,unitx, maxa2,unity)

least=(percentile ./100) .* maxa2
y=y-least
mask=y>=0%calculation of area
y=y(mask)
x=x(mask)
area=round(trapz(x,y),3)






end