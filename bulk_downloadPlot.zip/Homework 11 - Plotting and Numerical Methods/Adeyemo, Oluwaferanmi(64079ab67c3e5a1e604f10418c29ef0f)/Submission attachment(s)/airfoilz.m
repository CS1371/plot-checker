function[angle]=airfoilz(wing, force, deter)
a=wing % x value 
b=force %y value 
need=polyfit(a, b, 2)
newxs=linspace(min(a), max(a))
newys=polyval(need,newxs)
hold on
graph=plot(newxs,newys, 'k')
original=plot(a,b, 'b*')
hold off
angle=round(interp1(newxs,newys,deter,'spline'),3)
end

