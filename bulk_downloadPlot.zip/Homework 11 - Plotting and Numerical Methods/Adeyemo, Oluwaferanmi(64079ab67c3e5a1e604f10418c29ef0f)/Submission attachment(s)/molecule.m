function molecule(len,angles,curves)
nvalues = [];
cangle = cumsum(angles);
org = 0;
org2 = [0;0];
for i = 1:length(len)  ;
    
    a = cosd(cangle(i));
    b = sind(cangle(i));
    %lines = cumsum(lines)
    add = [a, -b; b, a] * [len(i);0];
    newpoint = org2 + add;
    nvalues = [nvalues newpoint];
    org = len(i);
    org2 = newpoint % rewriting over the origin ;
end

nvalues = [[0;0] nvalues] ;
xs = nvalues(1,:);
ys = nvalues(2,:);
plot(xs,ys,'k-')
hold on


[centers , hexrad] = findCenter(nvalues) 
centers = centers(:,curves);
centersx = centers(1,:);
centersy = centers(2,:);
hexrad = hexrad(curves); 

for j = 1:length(centersx);
    rad = 0.65*hexrad(j);
    vec = linspace(0,2*pi) ;
    newxs = rad*cos(vec)+centersx(j);
    newys = rad*sin(vec)+centersy(j);
    plot(newxs,newys,'b');
end

end





