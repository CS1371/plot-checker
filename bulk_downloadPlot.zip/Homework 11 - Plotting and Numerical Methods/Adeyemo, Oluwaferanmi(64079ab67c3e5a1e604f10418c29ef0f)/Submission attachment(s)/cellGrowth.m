 function cellGrowth(counts, time)
 a=counts %y 
 b=time %x
 avg=mean(a) %mean population size
 maximum= max(a) %maximum population size 
 need= length(a) %i need to know how long to make this vector 
 need2=avg .*(ones(1, need)) %Constant line for the avg
 need3=maximum .*(ones(1,need)) %Constant line for the maximum
 hold on
 plot(b,a, 'r.') %Plotting  the actual values part done
 plot(b,need2, 'b-.')
 plot(b, need3, 'm--')
 hold off
 axis([ -0.05 .*max(b), (0.05.*max(b))+ max(b), -0.05 .*max(a), (0.05 .*max(a))+max(a)])
 axis square
 title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
 end
 