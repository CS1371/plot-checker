function cellGrowth(cc,time)
    tmin = min(time) - 0.05*range(time);
    tmax = max(time) + 0.05*range(time);
    ccmin = min(cc) - 0.05*range(cc);
    ccmax = max(cc) + 0.05*range(cc);
    men = ones(1,length(time)).*mean(cc);
    mx = ones(1,length(time)).*max(cc);
    hold all
    plot(time,cc,'r.') 
    plot(time,men,'b-.')
    plot(time,mx,'m--')
    title('Cell Growth vs Time')
    xlabel('Time')
    ylabel('# Cells')
    axis([tmin tmax ccmin ccmax])
    axis square; 
end