function out = wordDist(file)
    global words
    global count
    global outt
    outt = '';
    words = [];
    count = [];
    fh = fopen(file);
    line = '';
    while ischar(line)
        line = fgetl(fh);
        analyze(line);
    end
    [words,ind] = sort(words);
    count = count(ind);
    bar(words,count)
    tight = sprintf('Can we read %s?',file(1:end-4));
    title(tight)
    xlabel('Length of Word')
    ylabel('Number of Occurrences')
    if isempty(outt) && all(words < 13)
        out = 'We''re at Georgia Tech, we can read that!';
    elseif ~isempty(outt)
        out = outt;
    else
        out = 'We''re at Georgia Tech, we can''t read that :(';
    end
end

function analyze(line)
global words
global count
global outt
    while line > 0
        [word,line] = strtok(line,' :;,.!?"');
        word = anaword(word);
        len = length(word);
        if any(words == len)
            count(words==len) = count(words==len)+1;
        elseif len > 0
            words = [words len];
            count = [count 1];
        end
        if strcmpi(word,'technology')
            outt = 'We''re at Georgia Tech, we can read that!';
        end
    end
end

function wordout = anaword(word)
    c = 1;
    while c <= length(word)
        if word(c) > 64 && word(c) < 91
        elseif word(c) > 96 && word(c) < 123
        else
            if c == 1
                word = word(2:end);
                c = c-1;
            elseif c == length(word)
                word = word(1:end-1);
            else
                word = [word(1:c-1) word(c+1:end)];
                c = c-1;
            end
        end
        c = c+1;
    end
    wordout = word;
end