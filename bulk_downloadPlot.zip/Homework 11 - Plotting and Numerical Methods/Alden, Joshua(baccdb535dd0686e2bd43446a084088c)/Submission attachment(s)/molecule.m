function molecule(lens,angles,hexane)
    x = [0];
    y = [0];
    angle = 0;
    for c = 1:length(lens)
       angle = mod(angles(c)+angle,360);
       roted = rot(angle);
       x = [x (roted(1,:)+x(c))];
       y = [y (roted(2,:)+y(c))];
       
       plot(x,y,'k')
    end
    [centers, rad] = findCenter([x;y]);
    hold all
    for c = 1:length(hexane)
        if hexane(c)
            tta = linspace(0,2*pi,100);
            cx = 0.65.*rad(c).*cos(tta)+centers(1,c);
            cy = 0.65.*rad(c).*sin(tta)+centers(2,c);
            plot(cx,cy,'b')
        end
    end
end

function roted = rot(angle)
    roted = [cosd(angle) -sind(angle); sind(angle) cosd(angle)] * [5;0];
end