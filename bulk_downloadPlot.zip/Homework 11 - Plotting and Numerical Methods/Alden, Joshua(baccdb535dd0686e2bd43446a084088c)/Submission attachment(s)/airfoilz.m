function liftSc = airfoilz(attack,liftC,angles)
    p = polyfit(attack,liftC,2);
    xax = min(attack):1:max(attack);
    fit = polyval(p,xax);
    hold all
    plot(xax,fit,'k')
    plot(attack,liftC,'b*')
    liftSc = round(interp1(xax,fit,angles,'spline'),3);
end