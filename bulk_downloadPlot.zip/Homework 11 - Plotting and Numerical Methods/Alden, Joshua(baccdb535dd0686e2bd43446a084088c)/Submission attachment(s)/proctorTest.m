function [opwaf,area] = proctorTest(file,perc)
    [num, txt, ~] = xlsread(file);
    num = num';
    
    %This method fits a second degree polynomial to the data to iterpolate
    %for the max.
    %{
    coeff = polyfit(num(1,:),num(2,:),2); %creates a quadradic to model the data
    %x = linspace(min(num(1,:)),max(num(1,:)),100);
    x = num(1,:);
    y = polyval(coeff,x); %finds the y values of the quadratic that match the x values
    dy = diff(y)./diff(x); %solves for the slope of y
    dx = (x(2:end)+x(1:end-1))/2; %finds the midpoints of x
%}
    

    y = num(2,:);
    x = num(1,:);
    dy = diff(y)./diff(x); %differential of mduw
    dx = (x(2:end)+x(1:end-1))/2; %finds the midpoints of x
    mc = spline(dy,dx,0); % interpolates to find where dy = 0
    mduw = spline(x,y,mc); % interpolates to find the max value is

    [~,rest] = strtok(txt{1,1},'()');
    [mcUnits,~] = strtok(rest,'()');
    [~,rest] = strtok(txt{1,2},'()');
    [mduwUnits,~] = strtok(rest,'()');
    opwaf = sprintf('%0.3f %s, %0.3f %s',round(mc,3),mcUnits,round(mduw,3),mduwUnits);
    
    topVal = mduw .* (perc./100);
    area = round(trapz(num(1,:),num(2,:) - topVal),3);
end