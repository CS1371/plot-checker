function[coefficient]= airfoilz(angles,coeffs, detAngles)
plot(angles, coeffs,'b*')
hold on
diff= range(angles);
p= polyfit(angles, coeffs, 2);
x=linspace(min(angles),max(angles),diff+1);
y=polyval(p,x);
plot(x,y,'k-')
coefficient= interp1(x, y, detAngles, 'spline');
coefficient= round(coefficient,3);
end