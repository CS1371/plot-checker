function cellGrowth(cell, time)
x= range(cell);
y= range(time);
axis([min(time)-(y*.05) max(time)+(y*.05) min(cell)-(x*.05) max(cell)+(x*.05)])
zeroVec= zeros(1, length(cell));
zeroVec(zeroVec==0)= mean(cell);
zeroVec2= zeros(1, length(cell));
zeroVec2(zeroVec2==0)= max(cell);
hold on
plot(time, cell,'r.')
hold on
plot(time,zeroVec,'b-.')
hold on
plot(time,zeroVec2,'m--')
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end