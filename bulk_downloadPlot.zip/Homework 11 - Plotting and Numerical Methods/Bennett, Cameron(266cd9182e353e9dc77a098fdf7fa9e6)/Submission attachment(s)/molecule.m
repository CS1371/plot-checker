function molecule(lengths, angles, hexane)
summed= cumsum(angles);
xvec=[0];
yvec=[0];
x=0;
y=0;
for i= 1:length(lengths)
    angle= summed(i);
    changex= lengths(i)*cosd(angle);
    changey= lengths(i)*sind(angle);
    newx= xvec(end)+changex;
    xvec=[xvec newx];
    newy= yvec(end)+changey;
    yvec=[yvec newy];
end
plot(xvec,yvec,'k')
hold on
arr1=vertcat(xvec,yvec);
[centerLocs, hexSizes]=findCenter(arr1);
[rows, cols]=size(hexane);
for j= 1:cols
    if hexane(1,j)==1
    centerPos= centerLocs(:,j);
    rad= hexSizes(j)        ;
    circlerad= rad*.65;
    theta= linspace(0,360);
    x2=circlerad*cosd(theta);
    y2=circlerad*sind(theta);
    plot(x2+centerPos(1),y2+centerPos(2),'b');
    end
end
axis square
axis off
end