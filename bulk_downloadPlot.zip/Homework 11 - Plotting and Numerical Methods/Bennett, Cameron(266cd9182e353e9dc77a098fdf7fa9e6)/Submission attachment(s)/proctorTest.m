function[string, area]= proctorTest(file, percentile)
[num txt raw]= xlsread(file);
[rows, cols]= size(raw);
moisture=[];
dry=[];
cell1= raw{1,1};
place1= find(cell1=='(');
place2= find(cell1==')');
unit1= cell1(place1+1:place2-1);
cell2= raw{1,2};
place3= find(cell2=='(');
place4= find(cell2==')');
unit2= cell2(place3+1:place4-1);
for i=2:rows
    new= raw{i,1};
    moisture= [moisture new];
end
for j=2:rows
    new2= raw{j,2};
    dry= [dry new2];
end
deriv1= diff(dry)./ diff(moisture);
xchange= diff(moisture)/2;
newx= moisture(1:end-1)+xchange;
loc= interp1(deriv1, newx, 0, 'spline');
loc2= interp1(moisture, dry, loc, 'spline');
string=sprintf('%0.3f %s, %0.3f %s',loc, unit1, loc2, unit2);
percentile= percentile/100;
val=loc2*percentile;
newY=dry-val;
mask= newY >=0;
area= trapz(moisture(mask), newY(mask));
area= round(area,3);
end