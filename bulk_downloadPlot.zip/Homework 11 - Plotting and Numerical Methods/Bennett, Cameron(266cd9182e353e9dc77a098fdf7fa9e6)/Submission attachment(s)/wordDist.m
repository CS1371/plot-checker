function [phrase] = wordDist (file)
fh= fopen(file);
line= fgetl(fh);
a=0;
B=0;
lengths=[];
lineNum=1;
while ischar(line)
    rest=line;
    rest(rest < ' ')='';
    rest(rest <= '@' & rest > ' ') = '';
    rest(rest >= '[' & rest <= '`') = '';
    rest(rest > 'z')='';
    while ~isempty(rest)
    [token,rest]=strtok(rest);
    token= lower(token);
    if strcmp(token, 'technology')
        a=1;
    end
    B = length(token);
    lengths= [lengths, B];
    end
    line= fgetl(fh);
end
string= file(1:end-4);
title(sprintf('Can we read %s?', string))
hold on
xlabel('Length of Word')
hold on
ylabel('Number of Occurrences')
hold on
counts=[]
for i= 1: max(lengths)
    count= sum(lengths(lengths== i));
    count= count/i;
    counts= [counts, count];
end
if a== 1
    phrase= 'We''re at Georgia Tech, we can read that!';
else
    if max(lengths) > 13
        phrase= 'We''re at Georgia Tech, we can''t read that :(';
    else
        phrase= 'We''re at Georgia Tech, we can read that!';
    end
end
hold on
bar((1:max(lengths)),counts)
fclose(fh)
end