%Checked
function cof = airfoilz(attks, liftcofs, dangs)

% %Script Functionality 
% clear
% clc
% close all 
% attks = [0 5 8 9 10 11 14];
% liftcofs = [0 .5 .8 .9 1 1.1 .8];
% dangs = 13;

%Find xs for plotting 
mask = abs(attks)>=1 | attks == 0; 
xs = attks(mask);
xmin = min(xs); 
xmax = max(xs); 

%Find second degree polynomial to fit data and plot 
eq = polyfit(attks, liftcofs, 2) ;
ys = polyval(eq , xmin:xmax);
plot(xmin:xmax,ys, 'k-');
hold on 
plot(attks, liftcofs , 'b*');

%Interpolate 
cof = round(spline(xmin:xmax, ys, dangs),3);
end