function molecule( lengths, angles, rings) 

% %Script Functionality 
% clear
% close all 
% clc 
% load('studentMolecules.mat');
% lengths =  mol1Lengths;  
% angles  =  mol1Angles; 
% rings   = mol1Rings;

x = [0]; 
y = [0];

angle=[];
for i=1:length(angles)
 
    angle = [angle sum(angles(1:i))];
    
end


for i = 1:length(lengths)
    
    xpoint = x(i)+length(i);
    ypoint = y(i);
 
        [addx addy] = rotate(xpoint , ypoint, angle(i) , lengths(i) );
    xpoint = x(i) +addx; 
    ypoint = y(i) +addy;
    x = [x ; xpoint];
    y = [y ; ypoint];
    
end

plot(x,y , 'k-')
axis square
axis off
hold on 

%Plot Circles
centers = findCenter([x';y']); 
row1 = centers(1,:);
row2 = centers(2,:); 
row1 = row1(rings);
row2 = row2(rings); 
centers = [row1 ; row2]; 
rings
[r c] = size(centers) 
cx = [];
cy = [];
for i=1:c
    theta = linspace(0,2*pi,100); 
    r = .65 * .5* (2*lengths(1) * cosd((angles(1)/2)) + lengths(1));
    xh = r.*cos(theta)+centers(1,i);
    yh = r.*sin(theta)+centers(2,i);
    cx = [cx xh]; 
    cy = [cy yh];
end
 plot(cx,cy,'b-');
end

function [rx ry] = rotate(x ,y , theta , length )


    rx = cosd(theta)*length;
    ry = sind(theta)*length; 
    

end

