%Checked
function [optimal, area] = proctorTest(filename, percentile) 

% %Script Functionality 
% clear
% clc
% close all 
% filename = 'standardOne.xlsx';
% percentile = 90; 

% Find moisture at max dry 
[num txt raw] = xlsread(filename); 
x = num(:,1);
y = num(:,2); 

ys = diff(y) ./ diff(x) ;
xs = [];
for i = 1:length(x)-1 
    xs = [xs ,(x(i)+x(i+1))/2];
end
ys = ys' ;
derive = spline(ys, xs, 0);

%Find corresponding dry unit weight 
maxdry = spline(x, y, derive);

%Find units for dry unit weight 
word = raw{1,2}; 
paren1 = strfind(word, '('); 
paren2 = strfind(word, ')');
dryunits = word(paren1+1 : paren2-1);

%Find units for moisture  
word = raw{1,1}; 
paren1 = strfind(word, '('); 
paren2 = strfind(word, ')');
moistunits = word(paren1+1 : paren2-1);

%Find integral 
above = (percentile / 100)*maxdry;
eq = polyfit(x,y,2) ;
eq(3) = eq(3)-above;
yint = y-above;
area = trapz(x,yint);

%Format and Output 
derive = round(derive, 3); 
maxdry = round(maxdry,3);
area= round(area,3);

optimal = sprintf('%.03f %s, %.03f %s' , derive , moistunits , maxdry , dryunits);

end