%checked
function cellGrowth(cells, time)
% 
% %Script Functionality 
% clear
% clc
% close all
% load('cellData.mat');
% cells = cell1;
% time = time1;


%Do calculations 
avg_pop = mean(cells)
max_pop = max(cells); 

%Plot 
 plot(time,cells,'r.');
hold on 
avgy = zeros(1, length(cells)) + avg_pop;
maxy = zeros(1 , length(cells)) + max_pop;
plot(time, avgy,'b-.');
plot(time, maxy, 'm--'); 

%Plot Format 
% p = .05*length(counts);
minx = min(cells)-(.05.*min(cells));
maxx = max(cells)+(.05.*max(cells));
miny = min(time)-(.05.*min(time));
maxy = max(time)+(.05.*max(time));
axis([miny,maxy,minx,maxx])
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
axis square;


 end