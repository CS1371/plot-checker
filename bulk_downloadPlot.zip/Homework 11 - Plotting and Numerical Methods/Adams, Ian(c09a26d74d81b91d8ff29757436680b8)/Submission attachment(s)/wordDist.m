%Checked 
function iseasy = wordDist(filename)

% %Script Functionality 
% clear
% clc
% close all 
% filename = 'crimePunishment.txt'; 

fh = fopen(filename); 
line = fgetl(fh);
%  line = 'The iridescent bubbles were beautiful.  But they were the falsest thing';
wordls = []; 
hastech = false;
while ischar(line) 
    
    if length(line)~=0
        %Take out extraneous characters and standardize spaces
        mask = line>='A' & line<='z' | line==' '; 
        line = line(mask); 
        if line(1)~=' '
           line = [' ' line]; 
        end

        if line(end) ~=' '
           line = [line ' ']; 
        end

        spaces = line==' '; 

        mask = [];
        for i=1:length(spaces)-1 
            if spaces(i) && spaces(i+1) 
                mask = [mask true];
            else 
                mask = [mask false];
            end
        end
        line = line(~mask); 

        if line(end) ~=' '
           line = [line ' ']; 
        end

        %Find space spots and number of words
        spaces = line==' '; 
        numwords = sum(spaces) -1; 
        spaces = strfind(line , ' '); 

        %Get each word and record its length

        for i=1:numwords

            word = line(spaces(i)+1 : spaces(i+1)-1);
            L = length(word) ;
            wordls = [wordls L];

            if isequal(lower(word) , 'technology')
                hastech = true; 
            end
        end 
    end
    
    line = fgetl(fh) ;
end 

fclose(fh) ;

%Count occurances 
rawdata = [];
while length(wordls)~=0 
    
    occurance = wordls(1); 
    mask = wordls==occurance;  
    count = sum(mask); 
    wordls(mask) = []; 
    
    row = [occurance count]; 
    rawdata = [rawdata ; row]; 
    
end 

%Process Data 
[sorted spots] = sort(rawdata(:,1)); 
data = sorted; 
rest = rawdata(:,2);
data = [data rest(spots)];

x=data(:,1);

mask1 = [];
for i=1:length(x)-1
    mask1 = [mask1 x(i+1)-(x(i)+1)];
end
% inserts = find(mask1~=0);
y = data(:,2);
for i=1:length(mask1)
    for j =1:mask1(i)
       if j~=0 
          y = [y(1:i) ; 0 ; y(i+1:end)]; 
       end
    end
end
    
x = 1:max(x); 
x
y

bar(x,y)
xlabel('Length of Word');
ylabel('Number of Occurences'); 
title(['Can we read ' , filename(1:end-4) , '?'])

%Can we read
mask = x>13;
bigword = any(mask);

if ~bigword || hastech 
    iseasy = 'We''re at Georgia Tech, we can read that!';
else 
    iseasy = 'We''re at Georgia Tech, we can''t read that :(';
end 
end