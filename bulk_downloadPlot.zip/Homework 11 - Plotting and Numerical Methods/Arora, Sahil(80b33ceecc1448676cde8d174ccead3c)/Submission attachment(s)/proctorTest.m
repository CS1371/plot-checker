function [string,area] = proctorTest(xlsfile,percentile)
[num,txt,~] = xlsread(xlsfile);
derivWt = diff(num(:,2))./diff(num(:,1));
derivMos = [];
for i = 1:length(num(:,1))-1
    derivMos = [derivMos mean([num(i,1),num(i+1)])];
end
maxMos = interp1(derivWt,derivMos,0,'spline');
maxWt = interp1(num(:,1),num(:,2),maxMos,'spline');
mosunit = txt{1}(19:end-1);   
wtunit = txt{2}(18:end-1);
string = sprintf('%0.3f %s, %0.3f %s',round(maxMos,3),mosunit,round(maxWt,3),wtunit);

level = maxWt*percentile/100;
blank = ones(1,length(num));
integral = num(:,2)'-(level*blank);
integral = integral(integral>0);
xvalues = num(:,1);
xvalues = xvalues(integral>0);
area = round(trapz(xvalues,integral),3);
end