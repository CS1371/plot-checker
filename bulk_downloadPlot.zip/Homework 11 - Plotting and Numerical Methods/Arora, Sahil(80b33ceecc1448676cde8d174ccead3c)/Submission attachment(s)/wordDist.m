function level = wordDist(txtfile)
fh1 = fopen(txtfile,'r');
line = fgetl(fh1);
lengthvec = [];
ab = 0;
level = 'We''re at Georgia Tech, we can read that!';
while ischar(line)
    line(~ismember(line,['A':'Z' 'a':'z' ' ']))=[];
    while ~isempty(line)
        [word,line] = strtok(line);
        lengthvec = [lengthvec length(word)];
        if length(word)>13
            level = 'We''re at Georgia Tech, we can''t read that :(';
        elseif strcmpi(word,'technology')
            ab = 1;
        end
    end
    line = fgetl(fh1);
end
if ab==1
    level = 'We''re at Georgia Tech, we can read that!';
end
fclose(fh1);
tbl = tabulate(lengthvec);
lengths = tbl(:,1);
freqs = tbl(:,2);
figure
bar(lengths,freqs);
xlabel('Length of Word')
ylabel('Number of Occurences')
title(sprintf('Can we read %s?',txtfile(1:end-4)))
end