function molecule(lengths,angles,hexane)
xvec = zeros(1,length(lengths)+1);
yvec = zeros(1,length(lengths)+1);
for i = 1:length(lengths)
     xvec(i+1) = xvec(i) + lengths(i).*cosd(sum(angles(1:i)));
     yvec(i+1) = yvec(i) + lengths(i).*sind(sum(angles(1:i)));
end
array = [xvec; yvec];
figure
plot(xvec,yvec,'k-')
hold on
[centers,sizes] = findCenter(array);
centersx = centers(1,hexane);
centersy = centers(2,hexane);
r = sizes(hexane);
for i=1:length(centersx)
    theta = linspace(0,2.*pi,100);
    x = r(i)*cos(theta)*.65+centersx(i);
    y = r(i)*sin(theta)*.65+centersy(i);
    plot(x,y,'b')
end
axis square
axis off
end