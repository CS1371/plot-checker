function liftco = airfoilz(anglevec,liftvec,unsolved)
range = min(anglevec):max(anglevec);
fit = polyfit(anglevec,liftvec,2);
value = polyval(fit,range);
figure
plot(range,value,'k');
hold on
plot(anglevec,liftvec,'b*');
liftco = round(interp1(range,value,unsolved,'spline'),3);
end