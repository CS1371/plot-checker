function cellGrowth(cellvec,timevec)
xrange = max(timevec)-min(timevec);
yrange = max(cellvec)-min(cellvec);
blank = ones(1,length(timevec));
figure
axis([min(timevec)-(xrange*0.05),max(timevec)+(xrange*0.05),min(cellvec)-(yrange*0.05),max(cellvec)+(yrange*0.05)]);
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
hold on
plot(timevec,cellvec,'r.')
plot(timevec,mean(cellvec)*blank,'b-.')
plot(timevec,max(cellvec)*blank,'m--')
axis square
end