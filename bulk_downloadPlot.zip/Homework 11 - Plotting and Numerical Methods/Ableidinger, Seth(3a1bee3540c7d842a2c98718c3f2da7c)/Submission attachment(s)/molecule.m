function molecule(lengths, angles, rings)
    points = [0;0]; %points in x y coordinate system, starts with (0,0)
    xold = 0;
    yold = 0;
    theta = 0;
    hold on;
    for i = 1:length(lengths)
        theta = theta + angles(i);          %adds up theta throughout       
        xnew = xold + lengths(i).*cosd(theta);    %calculates x value using polar coordinates
        ynew = yold + lengths(i).*sind(theta);    %calculates z value using polar coordinates
        plot([xold,xnew],[yold,ynew],'k-');
        points = [points, [xnew ; ynew]];         %concatentates points
        xold = xnew;
        yold = ynew;
    end
          
    [centerLocations, hexagonSizes] = findCenter(points);   %uses findCenter helper function to find center locations and sizes
    centerLocations = centerLocations(:,rings==true);       %uses only centerLocations and hexagonSizes specified by rings logical input
    hexagonSizes = hexagonSizes(rings==true);
    for j = 1:length(hexagonSizes)
        angles = linspace(0,2.*pi);     %100 steps between 0 and 2pi
        r = 0.65.*hexagonSizes(j);      %radius of circle is 65% of the hexagon size
        x2 = centerLocations(1,j) + r.*cos(angles);  %calcualtes x and y points using polar coordinates and center location
        y2 = centerLocations(2,j) + r.*sin(angles);
        plot(x2,y2,'b-');      %plots points     
    end
    hold off;
    axis square;
    axis off;
end
