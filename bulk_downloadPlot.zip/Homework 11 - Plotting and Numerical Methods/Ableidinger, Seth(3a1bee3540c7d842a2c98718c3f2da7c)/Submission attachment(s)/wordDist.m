function strOut = wordDist(fileName)
    fh = fopen(fileName);
    line = fgetl(fh);       %open file and get first line
    wordLengths = [];       %starts vector for word lengths
    techno = false;         %start assuming the word technology does not exist
    shortWords = true;      %start assuming all words are shorter than 13 characters
    while ischar(line)
        line = line((line>='a' & line<='z') | (line>='A' & line<='Z') | line==' ');     %gets rid of extraneous characters
        [word rest] = strtok(line);     %gets first word
        while ~isempty(word)
            wordLengths = [wordLengths length(word)];   %concatentates the length of each word
            [word rest] = strtok(rest);                 %gets rest of words in line
            if strcmp(lower(word),'technology')
                techno = true;      %sets techno to true if the word is technology
            end
            if length(word)>13
                shortWords = false; %sets shortWords to false if the word is longer than 13 characters
            end
        end
        line = fgetl(fh);       %gets new lines
    end
    
    wordLengths = sort(wordLengths);    %sorts word lengths
    sums = [];
    for i = 1:wordLengths(end)
        sums = [sums length(wordLengths(wordLengths==i))];  %tallys up total number of words for each length
    end
    
    if techno==true | shortWords==true
        strOut = 'We''re at Georgia Tech, we can read that!';   %if the word technology exists or all words are short, we can read that
    else
        strOut = 'We''re at Georgia Tech, we can''t read that :(';
    end
    bar(sums);  %creates bar graph and labels it
    xlabel('Length of Word');
    ylabel('Number of Occurrences');
    graphTitle = sprintf('Can we read %s?',fileName(1:end-4));
    title(graphTitle);
    fclose(fh);
end