function coes = airfoilz (attackAngles,coefficients,angles)
    [attackMin,~] = min(attackAngles);  %minimum value of attack angles
    [attackMax,~] = max(attackAngles);  %maximum value of attack angles
    xPoly = attackMin:attackMax;        %x values for plotting the fit line
    fit = polyfit(attackAngles,coefficients,2); %2nd degree polynomial fit line
    fitVal = polyval(fit,attackAngles);         %points evaluated from fit line
    yPoly = polyval(fit,xPoly);                 %y points for plotting the fit line
    coes = round(interp1(attackAngles,fitVal,angles,'spline'),3);   %output values
    plot(attackAngles,coefficients,'b*',xPoly,yPoly,'k-');          %plot
end