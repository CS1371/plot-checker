function [optimal, area] = proctorTest(fileName,percentile)
    [num txt raw] = xlsread(fileName);  %read excel file
    x = num(:,1);   %x values
    y = num(:,2);   %y values
    dx = diff(x);   %dx values
    dy = diff(y);   %dy values
    dydx = dy./dx;  %dydx values
    xmid = x(1:end-1) + dx./2;  %finds x mid points as stated by the problem
    maxDryPercent = spline(dydx,xmid,0);            %returns max dry percent
    maxDry = interp1(x,y,maxDryPercent,'spline');   % uses max dry percent to find max dry value
    lineVal = maxDry.*percentile./100;              %value of the line
    yNew = y-lineVal;                               %offsets graph down by the y value of the line
    xNew = x(yNew>0);                               %uses only x values above zero
    yNew = yNew(yNew>0);                            %uses only y values above zero
    area = trapz(xNew,yNew);                        %finds area of all values above zero
    
    maxDry = round(maxDry,3);                   %rounds all output values to three decimal places
    maxDryPercent = round(maxDryPercent,3);
    area = round(area,3);
    
    contentUnits = txt{1};      %pulls left heading
    weightUnits = txt{2};
    para1 = [strfind(contentUnits,'('),strfind(contentUnits,')')];  %locations of ( and )
    contentUnits = contentUnits(para1(1)+1:para1(2)-1);             %units of the content
    para2 = [strfind(weightUnits,'('), strfind(weightUnits,')')];   %locations of ( and )
    weightUnits = weightUnits(para2(1)+1:para2(2)-1);               %units of the weight
    
    optimal = sprintf('%0.3f %s, %0.3f %s', maxDryPercent,contentUnits,maxDry,weightUnits); %answer
    
end
    