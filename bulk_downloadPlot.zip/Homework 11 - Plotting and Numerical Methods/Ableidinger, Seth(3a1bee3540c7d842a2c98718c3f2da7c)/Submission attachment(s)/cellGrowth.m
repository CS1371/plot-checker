function cellGrowth (cellCounts,timePoints)
    [ymaxi,~] = max(cellCounts);    %returns max and min values for x and y axes
    [ymini,~] = min(cellCounts);
    [xmaxi,~] = max(timePoints);
    [xmini,~] = min(timePoints);
    ymaxi2 = zeros(1,length(cellCounts))+ymaxi;     %creates a vector of the ymaxi values the same length as timePoints and cellCounts
    avg = mean(cellCounts);     %average
    avg = zeros(1,length(cellCounts))+avg;          %creates a vector of the average values the same length as timePoints and cellCounts
    plot(timePoints,cellCounts,'r.',timePoints,avg,'b-.',timePoints,ymaxi2,'m--');  %plots cellCounts,average, and max value 
    xlabel('Time');                 %labels axes and title
    ylabel('# Cells');
    title('Cell Growth vs Time');
    xdiff = (xmaxi-xmini).*0.05;    %difference at each end of the x-axis
    ydiff = (ymaxi-ymini).*0.05;    %difference at each end of the y-axis
    limits = [xmini-xdiff xmaxi+xdiff ymini-ydiff ymaxi+ydiff]; %axes limits
    axis(limits);   %sets axes limits
    axis square;
end