function [level] = wordDist(filetxt)

file = fopen(filetxt);
linea = fgetl(file);

lengthv = [];
canread = false;
while ischar(linea)
    while ~isempty(linea)
        if strcmpi(linea,'technology')
            canread = true;
        end
        mask = linea >= 'a' & linea <= 'z' | linea >= 'A' & linea <= 'Z' | linea==' ';
        linea(~mask) = [];
        [word,rest] = strtok(linea); 
        n = length(word);
        lengthv = [lengthv, n];
        rest = rest(2:end);
        linea = rest;
    end
    linea = fgetl(file);
end
sortlength = sort(lengthv);
sortlength(end+1) = 0;
maxle = max(sortlength);
timesvec = [];
co = 0;
for i = 1:maxle
    j = 1;
    while isequal(i,sortlength(j))
        co = co + 1;
        j = j+1;
    end
    sortlength(1:co) = [];
    timesvec = [timesvec co];
    co = 0;  
end

if maxle <= 13
    canread = true;
end

if canread==true
    level = 'We''re at Georgia Tech, we can read that!';
else
    level = 'We''re at Georgia Tech, we can''t read that :(';
end

lengthv = 1:maxle;
bar(lengthv,timesvec)

name = filetxt(1:end-4);
title(sprintf('Can we read %s?',name));
xlabel('Length of Word');
ylabel('Number of Occurrences');

end