function [str,a] = proctorTest(xl,pct)
    [num,txt,raw] = xlsread(xl);
    subplot(1,1,1);
    hold on;
    yup = num(:,1)';
    ok = num(:,2)';
    plot(yup,ok);
    index1 = strfind(txt{1},'(');
    mu = txt{1}(index1+1:end-1);
    index2 = strfind(txt{2},'(');
    du = txt{2}(index2+1:end-1);
    dy = diff(ok);
    dx = diff(yup);
    deriv = dy ./ dx;
    derivX = yup(1:end-1) + .5 .* dx;
    max1 = spline(deriv, derivX, 0);
    max2 = spline(yup,ok,max1);
    
    str = sprintf('%0.3f %s, %0.3f %s',max1,mu,max2,du);
    
    limit = max2 .* (pct/100);
    ok = ok - limit;
    pos = ok >= 0;
    a = round(trapz(yup(pos),ok(pos)),3);
end