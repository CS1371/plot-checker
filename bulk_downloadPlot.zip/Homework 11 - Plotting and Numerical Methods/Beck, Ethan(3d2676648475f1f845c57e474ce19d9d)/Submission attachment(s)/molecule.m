function molecule(l, ang, r)

pt = [0;0];
ptf = [0;0];

hold on
new = cumsum(ang);
for i = 1:length(l)
    pt = [l(i);0];
    rotmat = [cosd(new(i)), -sind(new(i)); sind(new(i)), cosd(new(i))];
    pt = rotmat*pt;
    pt = pt + ptf;
    ptf = pt;
    pt = [pt,ptf];
end

x = pt(1,:);
y = pt(2,:);
plot(x,y,'k');
axis off
axis equal

the = linspace(0,2*pi);
[cen, hex] = findCenter(pt);
cen = cen(:,r);

[~,col] = size(cen);

for i = 1:col
    xx = .65*hex(i)*cos(the);
    yy = .65*hex(i)*sin(the);
    xx = cen(1,i) + xx;
    yy = cen(2,i) + yy;
    
    plot(xx,yy,'b');
end
