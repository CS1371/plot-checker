function cellGrowth (cell, tiempo)
    subplot(1,1,1);
    hold on
    plot(tiempo, cell, 'r.');
    average = mean(cell);
    a = linspace(min(tiempo), max(tiempo), average);
    plot(tiempo, average, 'b.');
    maxi = max(cell);
    plot(tiempo, maxi, 'm.');
    axis square;
    title('Cell Growth vs Time');
    xlabel('Time');
    ylabel('# Cells');
end