function[liftPerAng] = airfoilz(angles,coef,test)
high = max(angles);
low = min(angles);
p = polyfit([angles], [coef], 2);
n = linspace(low, high, length(angles));
x = polyval(p,n);
line = plot([angles], [coef], 'b*',  n, x, 'k');
liftPerAng = round(interp1(n, x, test, 'spline'),3);
end 