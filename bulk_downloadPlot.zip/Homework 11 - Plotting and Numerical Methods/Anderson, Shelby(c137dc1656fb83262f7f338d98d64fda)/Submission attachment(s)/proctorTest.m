function [ str, A ] = proctorTest( filename, perc )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
[number text raw] = xlsread(filename)
xs = cell2mat(raw(2:end,1))
ys = cell2mat(raw(2:end,2))
derivative = diff(ys)./diff(xs)
vec = []
for i =1:length(xs) -1
    vec = [vec (xs(i) + xs(i+1))./2]
end
[~, un] = strtok(text{2}, '(')
maximum = (interp1(derivative, vec, 0, 'Spline'))
maximumy = (interp1(xs, ys, maximum, 'Spline'))
perc = perc .* maximumy ./ 100
y2 = ys - perc
mask = y2 >= 0
A = round(trapz(xs(mask), y2(mask)),3)
maximumy = round(maximumy, 3)
maximum = round(interp1(derivative, vec, 0, 'Spline'), 3)
str = sprintf('%0.3f %%, %0.3f %s', maximum, maximumy, un(2:end-1))

end

