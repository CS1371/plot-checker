function molecule(vec, angles, rings)
p = [0; 0];
for i = 1:length(vec)
    p = [p [p(1, i) + vec(i).*cosd(angles(i)); p(2, i) + vec(i).*sind(angles(i))]];
    if i ~= length(vec)
        angles(i + 1) = angles(i +1) + angles(i);
    end
end
    plot(p(1,:), p(2,:), 'k');
    axis square
    axis off
    hold on 
    [centers, r] = findCenter(p);
    [~, C] = size(rings);
    for j = 1:C
        if rings(j) == true
            [x, y] = circle(centers(1, j), centers(2, j), r(j));
            plot(x, y, 'b');
        end
    end
end

function [x, y] = circle(xcenter,ycenter,r)
r = 0.65.*r;
theta = linspace(0, 2.*pi, 100);
x = r * cos(theta) + xcenter;
y = r * sin(theta) + ycenter;
end
