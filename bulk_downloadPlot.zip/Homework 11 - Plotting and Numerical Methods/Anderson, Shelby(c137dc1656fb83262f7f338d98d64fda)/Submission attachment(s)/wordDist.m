function [ out ] = wordDist( filename )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
fh1 = fopen(filename, 'r');
line = fgetl(fh1);
q = 0;
vector = [];
while ischar(line)
    mask = (line>= 65 & line <= 90) | (line >= 97 & line <= 122) | line == 32;
    new = line(mask)
    [first rest] = strtok(new);
    c = 0;
    while length(rest) > 0
        if c ==0
            value = length(first);
            if strcmpi(first, 'technology')
                q=q+1;
            end
            vector = [vector value];
        end
        c = c +1;
        [first rest] = strtok(rest);
        if strcmpi(first,'technology')
            q = q + 1;
        end
        value = length(first);
        vector = [vector value];
    end
    line = fgetl(fh1);
end
maximum = max(vector)
if (maximum<=13)
    out = 'We''re at Georgia Tech, we can read that!';
elseif q < 0
    out = 'We''re at Georgia Tech, we can read that!';
else
    out = 'We''re at Georgia Tech, we can''t read that :(';
end
newvector = ones(1,max(vector));
xvector = [];
for x=1:max(vector)
    xvector = [xvector x];
    mask1 = vector==x;
    yvector = vector(mask1);
    newvector(x) = length(yvector);
end
bar(xvector,newvector);
hold on;
[tok1 rest1] = strtok(filename, '.');
tit1 = sprintf('Can we read %s, tok1');
title(tit1);
xlabel('Length of Word');
ylabel('Number of Occurences');

end

