function [ out ] = airfoilz( attack, lift, value )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
fit = polyfit(attack,lift,2);
v2 = polyval(fit, attack);
angle = min(attack):max(attack);
reval = spline(attack,v2,min(attack):max(attack));
plot(angle, reval, 'k')
hold on 
plot(attack, lift, 'b*')
hold off
out = round(interp1(attack, v2, value, 'spline'),3);

end

