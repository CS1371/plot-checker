function [ ] = cellGrowth( counts, points )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
meaned = mean(counts);
[maxCounts, ~] = max(counts);
[minCounts, ~] = min(counts);
[maxPoints, ~] = max(points);
[minPoints, ~] = min(points);
plot(points,counts,'r.');
hold on
plot(points,meaned.*ones(1,length(points)),'b-.')
plot(points,maxCounts.*ones(1,length(points)),'m--')
hold off
axis square
axis([(.95*minPoints), (1.05*maxPoints) , (.95*minCounts), (1.05*maxCounts)])
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')

end

