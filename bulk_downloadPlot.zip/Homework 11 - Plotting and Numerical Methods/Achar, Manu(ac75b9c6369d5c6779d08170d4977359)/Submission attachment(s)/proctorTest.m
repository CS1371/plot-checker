function [str, area] = proctorTest(xls, per)
    [num, txt, ~] = xlsread(xls);
    deriWat = diff(num(:, 2)./num(:,1));
    deriDry = [];
    for i = 1:length(deriWat)
        
    end
    
    unitWat = txt{1}(19:end-1);
    unitDry = txt{2}(18:end-1);
    fmt = '%s %s, %s %s';
    str = sprintf(fmt, maxWat, unitWat, maxDry, unitDry);
    

end