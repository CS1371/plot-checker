function [str] = wordDist(file)
    doc = fopen(file);
    line = fgetl(doc);
    lengthVec = [];
    str = 'We''re at Georgia Tech, we can read that!';
    while ischar(line)
        while ~isempty(line)
            line(~ismember(line, (['A':'Z' 'a':'z']))) = ' ';
            [word, line] = strtok(line);
            wordSize = length(word);
            lengthVec = [lengthVec wordSize];
            if wordSize > 13
                str = 'We''re at Georgia Tech, we can''t read that :(';
                if strcmp(word, 'technology')
                    str = 'We''re at Georgia Tech, we can read that!';
                end
            end
            
        end
        line = fgetl(doc);
    end

    tbl = tabulate(lengthVec);
    x = tbl(:, 1);
    y = tbl(:, 2);
    bar(x, y);

end