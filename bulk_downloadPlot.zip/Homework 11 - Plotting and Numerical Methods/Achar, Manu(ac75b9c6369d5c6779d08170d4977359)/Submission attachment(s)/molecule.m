function molecule(segment,angle,rings)
xstart = 0;
ystart = 0;
theta = 0;
mol = [0;0];
for i = 1:length(segment)
    theta = theta + angle(i);
    rotation = [cosd(theta),-sind(theta);sind(theta),cosd(theta)];
    point = [xstart+segment(i);ystart] - [xstart;ystart];
    newpoint = (rotation*point) + [xstart;ystart];
    xline = [xstart,newpoint(1)];
    yline = [ystart,newpoint(2)];
    plot(xline,yline,'-k');
    xstart = newpoint(1);
    ystart = newpoint(2);
    mol = [mol newpoint];
    hold on;
end
[center,radius] = findCenter(mol);
circx = center(1,:);
circy = center(2,:);
circx = circx(rings);
circy = circy(rings);
radius = radius(rings);

for j = 1:length(radius)
    circrad = radius(j)*0.65;
    angle = linspace(0,2*pi);
    circx2 = circrad*cos(angle);
    circy2 = circrad*sin(angle);
    plot(circx(j)+circx2,circy(j)+circy2,'-b');
end    
axis equal;
axis off;
hold off;
end