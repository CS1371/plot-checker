function cellGrowth(cell, time)
    maxCell = max(cell);
    maxCellPlot = [];
    maxCellPlot(1:length(time)) = maxCell;
    meanCell = sum(cell)/length(cell);
    meanCellPlot = [];
    meanCellPlot(1:length(time)) = meanCell;
    cellPlotMin = min(cell) - (min(cell) * .05);
    cellPlotMax = max(cell) + (max(cell) * .05);
    timePlotMin = min(time) - (min(time) * .05);
    timePlotMax = max(time) + (max(time) * .05);
    plot(time, cell, 'r.');
    hold on;
    plot(time, meanCellPlot, 'b-.');
    plot(time, maxCellPlot, 'm--');    
    axis([timePlotMin timePlotMax cellPlotMin cellPlotMax])
    axis square
    title('Cell Growth vs Time');
    xlabel('Time');
    ylabel('# Cells');

end