function liftcoeff = airfoilz(attack,lift,angles)
    [min1,~] = min(attack);
    [max1,~] = max(attack);
    polyval = polyfit(attack,lift,2);
    parabola = [];
    for i = min1:max1
        liftval = polyval(1)*(i)^2 + polyval(2)*(i) + polyval(3);
        parabola = [parabola liftval];
    end
    integers = [min1:1:max1];
    plot(attack,lift,'b*');
    hold on;
    plot(integers,parabola,'k-');
    hold off;
    liftcoeff = round(interp1(integers,parabola,angles,'spline'),3);
end