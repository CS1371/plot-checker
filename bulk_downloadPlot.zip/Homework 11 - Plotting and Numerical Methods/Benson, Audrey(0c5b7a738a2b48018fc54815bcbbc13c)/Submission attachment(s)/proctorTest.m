function [str,area] = proctorTest(excel,percentsp)

[nums,~,raw] = xlsread(excel); %reads the excel sheet

% gets the moisture and dry percentage values
moisture = nums(:,1);
dryweight = nums(:,2);

% gets the midpoint values
x = (diff(moisture) ./ 2) + moisture(1:end-1);

% gets the derivative of the data and finds the x value for where the y
% value is zero (which gets the max value of the original graph)
derivY = diff(dryweight) ./ diff(moisture) ;
moisturecont = spline(derivY,x,0);

% finds the corresponding dry values
dryweightper = spline(moisture,dryweight,moisturecont);

% finds the minimum y value that must be graphed above
percent = dryweightper - ((percentsp ./ 100) .* dryweightper);
percent = dryweightper - percent;

% finds where the dryweight values are more than the min percent and
% subtracts the percent in order to bring it down to the x-axis
yvals = dryweight(dryweight >= percent) - percent;
% finds the corresponding moisture values 
xvals = moisture(dryweight >= percent);
% gets the integral of the graph
area = trapz(xvals,yvals);

% gets the unit for moisture
moistunit = raw{1,1};
moistmask = find(moistunit == '('); 
moistmask1 = find(moistunit == ')');
moistunit = moistunit(moistmask+1:moistmask1-1);

% gets the unit for dry unit weight
dryunit = raw{1,2};
drymask = find(dryunit == '('); 
drymask1 = find(dryunit == ')');
dryunit = dryunit(drymask+1:drymask1-1);

% outputs the max values and their units
str = sprintf('%0.3f %s, %0.3f %s',round(moisturecont,3),moistunit,round(dryweightper,3),dryunit);

end