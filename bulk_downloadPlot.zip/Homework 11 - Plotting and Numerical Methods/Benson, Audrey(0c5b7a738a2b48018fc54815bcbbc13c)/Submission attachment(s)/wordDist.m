function out = wordDist(file)

% opens file and grabs the first line
fh = fopen(file,'r');
line = fgetl(fh);

wordcountt = [];
techcount = 0;
while ischar(line) % counts length of each word in each line and adds it to a word countt vec
    wordcount = [];
    % takes out all chars that aren't a letter or a space
    line = line(line >= 65 & line <= 90 | line >= 97 & line <= 122 | line == 32);
    [tok,str] = strtok(line); % gets the first word and counts length and 
    wordcount = [wordcount, length(tok)];% . . adds it to wordcount vec
    if strcmpi(tok,'technology') % checks to see if it is 'technology'
        techcount = techcount + 1;%. . if it is techcount gets a +1
    end
    while ~isempty(str)
        [tok,str] = strtok(str); % gets each word and counts length
        wordcount = [wordcount, length(tok)];%. . and adds this to wordcount vec
        if strcmpi(tok,'technology')
            techcount = techcount + 1;
        end
    end
    wordcountt = [wordcountt, wordcount]; % adds to giant vec
    line = fgetl(fh); % gets next line
end

vec = ones(1,max(wordcountt)); 
for i = 1:max(wordcountt) % adds the number of word counts up and puts in in the vec
   mask = i == wordcountt;% . . for each word length
   vec(i) = sum(mask);
end

bar(vec) % makes bar graph, titles it and labels axis
titlee = file(1:end-4);
title(sprintf('Can we read %s?',titlee))
xlabel('Length of Word')
ylabel('Number of Occurences')

% out is 'can read it' if the max word length is 13 or less
if max(wordcountt) <= 13
    out = sprintf('We''re at Georgia Tech, we can read that!');
end

% out is 'can't read' if max word length is over 13
if max(wordcountt) > 13
    out = sprintf('We''re at Georgia Tech, we can''t read that :(');
    if techcount > 0
        % . . but if technology is found in the text out is 'can read'
        out = sprintf('We''re at Georgia Tech, we can read that!');
    end
end

end