function molecule(lengths,angles,whichring)

% gets the cumulative sum for each angle
angle = cumsum(angles);

xcoor = [];
ycoor = [];
for i = 1:length(lengths) 
    if i == 1
        xcoor = 0; % starts at the origin
        ycoor = 0;
    end
    x = xcoor(i) + (lengths(i) .* cosd(angle(i))); % gets x coordinate
    y = ycoor(i) + (lengths(i) .* sind(angle(i))); % gets y coordinate
    xcoor = [xcoor x]; % makes vec of x coordinates
    ycoor = [ycoor y]; % makes vec of y coordinates
end

hold on 
plot(xcoor,ycoor,'k') % plots the molecule
axis square

newmat = [xcoor; ycoor]; % correct format for 'findCenter'
[cent,rad] = findCenter(newmat); % finds the coordinates of the benzene circles
cent = cent(:,whichring); % gets the benzene circle coordinates needed
xcent = cent(1,:); % splits the coordinates up into x and y
ycent = cent(2,:);
rad = rad(whichring) * .65; % gets the radii needed and makes it 65 percent 

theta = linspace(0,2.*pi,100); 

hold on

x2coor = [];
y2coor = [];
for j = 1:length(rad)
    x = xcent(j) + (rad(j) .* cos(theta)); % plots a circle inside of each ring
    y = ycent(j) + (rad(j) .* sin(theta));
    plot(x,y,'b')
end

hold off
axis off

end