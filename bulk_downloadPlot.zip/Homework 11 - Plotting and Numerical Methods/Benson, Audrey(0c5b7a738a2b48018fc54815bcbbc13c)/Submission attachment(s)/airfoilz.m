function out = airfoilz(attack,lift,angle)

% reassigns variables
x = attack;
y = lift;

hold on

% original plot
figure(1)
plot(x,y,'b*')

% gets 100 values between the max and min values
maxx = max(attack);
minn = min(attack);
xvals = minn:1:maxx;

poly = polyfit(x,y,2); % finds 2nd order polynomial coefficients
polyy = polyval(poly,xvals); % plugs the new xvals into that polynomial
plot(xvals,polyy,'k') % plots the polynomial

% finds a value for the angle and rounds it
out = roundn(spline(xvals,polyy,angle),-3);

hold off

end