function cellGrowth(cell, time)

% range of x-axis
minx = min(time);
maxx = max(time);
diffx = (maxx - minx) .* .05;
newminx = minx - diffx;
newmaxx = maxx + diffx;

% range of y-axis
miny = min(cell);
maxy = max(cell);
diffy = (maxy - miny) .* .05;
newminy = miny - diffy;
newmaxy = maxy + diffy;

figure(1)
hold on

% cell count vs time data
y = cell;
x = time;
plot(x,y,'r.')

% mean population size
ymean = mean(cell);
[r,c] = size(x);
ymean = ymean .* ones(r,c);
plot(x,ymean,'b-.')

% max population size
maxy = maxy .* ones(r,c);
plot(x,maxy,'m--')

% label stuff
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
axis square
axis([newminx newmaxx newminy newmaxy]) 

hold off

end
