function cellGrowth(y,x)

hold on
plot(x,y,'.r');
avglin=zeros(1,length(x));
maxlin=zeros(1,length(x));
avg=mean(y);
maxgr=max(y);
mingr=min(y);
avglin(1:end)=avg;
maxlin(1:end)=maxgr;
plot(x,avglin,'-.b');
plot(x,maxlin,'--m');
maxtim=max(x);
mintim=min(x);

axis([mintim-(maxtim*0.05),maxtim+(maxtim*0.05),mingr-(maxgr*0.05),maxgr+(maxgr*0.05)]);
axis('square');
xlabel('Time');
ylabel('# Cells');
title('Cell Growth vs Time');
end