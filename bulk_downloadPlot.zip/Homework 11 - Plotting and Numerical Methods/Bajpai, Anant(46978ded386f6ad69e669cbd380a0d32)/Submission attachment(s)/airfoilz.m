function out= airfoilz(aa,lc,coe)
hold on;
plot(aa,lc,'*b');
coeff=polyfit(aa,lc,2);
xi=linspace(min(aa),max(aa));
yi=polyval(coeff,xi);
plot(xi,yi,'k');


out=round(interp1(xi,yi,coe,'spline'),3);

end
