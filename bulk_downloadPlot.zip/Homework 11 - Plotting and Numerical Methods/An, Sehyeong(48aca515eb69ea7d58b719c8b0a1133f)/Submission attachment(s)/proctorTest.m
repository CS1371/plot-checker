function [str, area] = proctorTest(data, pct)
% The function gets the maximum dry unit weight and moisture content and
% the area bigger than the given percentile and beneath the curve

[num,txt,~] = xlsread(data);
x = num(:,1)'; 
y = num(:,2)';
% finds the derivY vector by taking derivative
derivY = diff(y)./diff(x); 

% creates the derivX vector by finding the midpoint of two consecutive
% terms
derivX = [];
for i = 1:length(x)-1
    mid = [x(i) x(i+1)];
    mP = mean(mid);
    derivX = [derivX mP]; 
end

% finds the new y value when x value equals to 0
maxy = spline(derivY, derivX, 0);
% finds the new x value when y value equals to maxx
maxx = spline(x,y,maxy);

% finds the string unit that was used in the excel file
[~, unit1] = strtok(txt(1,1), '(');
[~, unit2] = strtok(txt(1,2), '(');
unit1 = unit1{1}(2:end-1); % gets rid of the parenthesis
unit2 = unit2{1}(2:end-1);
str = sprintf('%0.3f %s, %0.3f %s',maxy,unit1,maxx,unit2); % puts in the string

% finds the area above the percenile and below the curve
deltay = y - maxx * pct/100; 
ind = find(deltay > 0); % finds the index of where deltay is bigger than 0
area = round(trapz(x(ind),deltay(ind)),3); % finds the area by trapezoidal
% approximation
end