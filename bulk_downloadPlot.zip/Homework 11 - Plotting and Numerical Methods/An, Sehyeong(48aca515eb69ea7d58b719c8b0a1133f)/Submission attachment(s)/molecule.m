function molecule(molL, molA, molR)
% The function draws the molecules by plotting

% initializes the variables
x = 0; 
y = 0;
ptX = [];
ptY = [];
i = 1; % initializes counting variable
j = 1; % initializes counting variable

% plots the line and forms the molecule structure
while i <= length(molA) 
    th = sum(molA(1:i)); % updates the angle
    rotmat = [cosd(th) -sind(th);sind(th) cosd(th)]; % makes a rotation matrix
    rotpt = rotmat * [molL(i);0]; % gets the points after rotation
    x = rotpt(1) + x; % updates x point by adding the new value to previous value
    y = rotpt(2) + y; % updates y point by adding the new value to previous value
    ptX = [ptX x]; % store all the x points
    ptY = [ptY y]; % store all the y points
    i = i + 1; % increment the counting variable
end
plot([0 ptX],[0 ptY],'k-'); % plot the points from the origin
hold on;

% draws the circle in the corresponding ring
pts = [ptX;ptY];
if any(molR == 1)
    idx = find(molR == 1); % find where to put the circle
    [ctr, r] = findCenter(pts);
    ctr = ctr(:,idx);
    r = r(idx)*0.65;
    th2 = linspace(0,360,100);
    while j <= length(idx)
        cx = r(j).*cosd(th2)+ctr(1,j); % gets the x point of circle
        cy = r(j).*sind(th2)+ctr(2,j); % gets the y point of circle
        j = j+1; % increment the counting variable
        plot(cx,cy,'b'); % plot circles in corresponding rings
    end
    axis square;
    axis off;
end