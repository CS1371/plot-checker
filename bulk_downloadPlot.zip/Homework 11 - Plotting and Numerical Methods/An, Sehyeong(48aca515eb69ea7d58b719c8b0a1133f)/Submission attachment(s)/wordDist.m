function str = wordDist(fn)
% The function determines whether the text is at our reading level and
% displays the frequency of words of different lengths
fh = fopen(fn); % opens the file
line = fgetl(fh); % gets the line
lngvec = []; % creates empty vector to initialize
while ischar(line) 
    line = lower(line); % lowers the whole line in order to find the
    % 'technology' no matter what case it's in
    line = line(line >= 'a' & line <= 'z' | line == ' '); % gets rid of all
    % the extraneous characters other than aplphabets and spaces
    while ~isempty(line)
        [word, line] = strtok(line, ' '); % gets each word in line by using
        % strtok
        match = strcmp(word, 'technology'); % see if any of the word matches
        % 'technology'
        mylng = length(word); % gets the length of each word
        lngvec = [lngvec mylng]; % creates a lngvec by putting all the word lengths
        lngvec(lngvec == 0) = []; % when it equals to 0, removes it from lngvec
        if mylng <= 13 | match == 1 % if all words are less than or equal to 13 or
            % matches the 'technology'
            str = sprintf('We''re at Georgia Tech, we can read that!'); % prints the statement
        end
        if mylng > 13 | match == 0 % if any of the word is longer than 13 or 
            % 'technology' does not exist in txt file
            str = sprintf('We''re at Georgia Tech, we can''t read that :('); % prints the statement
        end
    end
    line = fgetl(fh); % gets the next line
end
fclose(fh); % close the file
x = min(lngvec):max(lngvec); % set x-axis range
y = zeros(1, length(x)); % create zero vector
for i = 1:length(x)
    freq = sum(x(i) == lngvec); % finds the occurrance of the length of word in lngvec
    y(i) = freq; % puts into correct index of y
end
bar(x,y); % draws the bar graph
titletxt = sprintf('Can we read %s?', fn(1:end-4)); % new title txt
title(titletxt); % labels title
xlabel('Length of Word'); % labels x-axis
ylabel('Number of Occurrences'); % labels y-axis
end