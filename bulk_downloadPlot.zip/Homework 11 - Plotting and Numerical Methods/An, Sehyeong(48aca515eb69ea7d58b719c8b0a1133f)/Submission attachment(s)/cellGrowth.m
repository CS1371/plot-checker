function cellGrowth(cell,time)
% The function graphs the growth of cells over time.

% plots the cell count vs time in read points
plot(time,cell,'r.');

% sets the range of both axis to be |5%| of the maximum and minimum values
mint = min(time)*-1.05;
maxt = max(time)*1.05;
minc = min(cell)*-1.05;
maxc = max(cell)*1.05;
axis([mint maxt minc maxc]);

hold on; % use it to graph more than one plot on the same figure

mpop = zeros(1, length(time)); % since the plot() takes two vectors...
% of the same length, makes a zero vector to mask the value onto

% finds the mean population size and plot it in blue dashdot
meanp = mean(cell);
mpop(1:end) = meanp; % makes it the same length vector
plot(time, mpop, 'b-.');

% finds the maximum population size and plot it in magenta dashes
maxp = max(cell);
mpop(1:end) = maxp; % makes it the same length vector
plot(time, mpop, 'm--');

axis square; 
title('Cell Growth vs Time'); % label the graph
xlabel('Time'); % label the x-axis
ylabel('# Cells'); % label the y-axis
end