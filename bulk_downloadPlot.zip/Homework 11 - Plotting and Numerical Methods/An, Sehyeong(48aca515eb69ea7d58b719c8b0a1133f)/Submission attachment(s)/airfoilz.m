function lift = airfoilz(att, lcoe, alcoe)
% The function graphs the best fit curve of 2nd degree polynomial of input
% data and computes the lift coefficients that corresponds to given angles.

    % plots the origianl data
    plot(att, lcoe, 'b*');
    
    % find the best 2nd degree polynomial fit to data and plot it
    coe = polyfit(att, lcoe, 2);
    newatt = min(att):max(att); % creates a vector of new att values that lies
    % within the best fit line
    newlcoe = polyval(coe, newatt); % creates a vector of new lcoe values that 
    % lies within the best fit line
    hold on; % call it to plot two or more graphs on the same figure
    plot(newatt, newlcoe, 'k-'); % plot the best fit curve of 2nd degree polynomial
    
    % computes the lift coefficients that correspond to given angles
    lift = interp1(newatt, newlcoe, alcoe, 'spline');
    lift = round(lift, 3); % round the answer to the nearest thousandth
end