function [optWater, finalArea]= proctorTest(data, percent)

    [num,txt,raw]=xlsread(data);
    
    unit1=raw{1,1};
    unit2=raw{1,2};
    [tok1,unit1]=strtok(unit1,'(');
    munit1=unit1=='('|unit1==')';
    unit1(munit1)='';
    [tok2,unit2]=strtok(unit2,'(');
    munit2=unit2=='('|unit2==')';
    unit2(munit2)='';
    %finds the units
    
    xValues=transpose(num(:,1));
    yValues=transpose(num(:,2));
    deriv= diff(yValues)./diff(xValues);
    %finds the derivative
    
    newXVec=[];
    
        for x=1:length(xValues)-1
            
            newX=(xValues(x)+xValues(x+1))./2;
            newXVec=[newXVec, newX];
            
        end
        
     maxX=spline(deriv,newXVec, 0);
     maxY=spline(xValues, yValues, maxX);
     %finds the maximum values
     
     percent=percent./100;
     line=maxY.*percent;
     newYValues=yValues-line;
     Cmask=newYValues>=0;
     newYValues=newYValues(Cmask);
     newXValues=xValues(Cmask);
     area=trapz(newXValues, newYValues);  
     finalArea=round(area,3);
     %calculates area under the curve from line up
     
     maxX=round(maxX,3);
     maxY=round(maxY,3);
     optWater=sprintf('%0.3f %s, %0.3f %s',maxX, unit1,maxY, unit2);
     %outputs the string with the max values and their corresponding values

end
