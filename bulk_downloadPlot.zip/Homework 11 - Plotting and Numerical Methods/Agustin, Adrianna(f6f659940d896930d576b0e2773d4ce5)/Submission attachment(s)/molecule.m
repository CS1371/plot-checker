function []=molecule(lengths, angles, rings)

    plotAngles=cumsum(angles);
    xVec=[0];
    yVec=[0];
 
        while any(plotAngles)>360
            mask=plotAngles>360;
            plotAngles(mask)=plotAngles(mask)-360;
            %adjusts the angles that are greater than 360
        end
        plotAngles=plotAngles./180.*pi;
        for i=1:length(lengths)
            %finds the coordinates for the lines
            r=lengths(i);
            plotAngles2=plotAngles(i);
            x=r.*cos(plotAngles2)+xVec(end);
            y=r.*sin(plotAngles2)+yVec(end);
            xVec=[xVec,x];
            yVec=[yVec,y];
        end
    %plots the hexane lines
    hold on
    plot(xVec, yVec, 'k')
    axis equal
    axis off
        
    allPoints=[xVec;yVec];
    [centerLocations, hexagonSizes] = findCenter(allPoints);
    circleLengthVec=[];   
    
        for a=1:length(hexagonSizes)
            circleSize=hexagonSizes(a).*0.65;
            circleLengthVec=[circleLengthVec,circleSize];
        end
        
       
        
        for b=1:length(rings)
            if isequal(rings(b), true);
                
                theta=linspace(0, 2.*pi);
                r=circleLengthVec(b);
                x=r.*cos(theta)+centerLocations(1,b);
                y=r.*sin(theta)+centerLocations(2,b);
                plot(x,y,'b');
            end
        end
     hold off      
    
end
