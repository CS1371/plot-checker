function []=cellGrowth(cells, time)

     subplot(1,1,1);   
     hold on;
     plot(time, cells, 'r.')
     %plots the values for the cell growth over time
     meaner=mean(cells);
     meaner=meaner.*(ones(length(cells)));
     plot(time, meaner, 'b-.')
     %plots the average time for each cell growth
     maxer=max(cells);
     maxer=maxer.*(ones(length(cells)));
     plot(time,maxer, 'm--')
     %plots the maximum time for each cell growth
     xlabel('Time');
     ylabel('# Cells');
     title('Cell Growth vs Time');
     %names the axis and the title
     axis square
     minTime=min(time);
     minTime=minTime-(0.05.*minTime);
     maxTime=max(time);
     maxTime=maxTime+(maxTime.*0.05);
     minCell=min(cells);
     minCell=minCell-(minCell.*0.05);
     maxCell=max(cells);
     maxCell=maxCell+(maxCell.*0.05);
     axis([minTime, maxTime, minCell, maxCell]);
     %fixes the axis sizes
     hold off
end