function [angleCoeff]=airfoilz(attack, liftCoeff, angles)

        hold on 
        minVal=min(attack);
        maxVal=max(attack);
        newAttack=(minVal:1:maxVal);
% lines 4-6 create a new vector of attack angles
        c=polyfit(attack,liftCoeff,2);
        newY=polyval(c,newAttack);
%line 11 plots the original data
        plot(attack, liftCoeff, 'b*');
        angleCoeff=interp1(newAttack,newY, angles, 'spline');
        angleCoeff=round(angleCoeff,3);
        plot(newAttack,newY,'k');
        hold off
    
    
end