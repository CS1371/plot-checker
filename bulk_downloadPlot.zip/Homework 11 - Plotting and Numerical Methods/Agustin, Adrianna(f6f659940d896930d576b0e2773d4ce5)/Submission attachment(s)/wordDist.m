function [readingLevel]=wordDist(textfile)

    fh=fopen(textfile,'r');
    line=fgetl(fh);
    %eliminates extraneous letters
    extra=(line<='z'&line>='a')|(line<='Z'&line>='A')|line==' ';
    line=line(extra);
    tech=[];
    techVec=[]; %vector of true or false if the word 'technology' is present
    wordVec=[]; %vector with the amount of words that are less than 13 letters
    lengthVec=[];%vector with the length of words and their occurrences
    
        while line~=-1
            
            for x=1:((length(strfind(line,' ')))+1)
                    %checks if the word 'technology' appears    
                    if sum(strfind(line,'technology'))>=1
                        tech=1;
                    else
                        tech=0;
                    end
                techVec=[techVec,tech];
                %finds the amount of words that are 13 letters or less
                [word,line]=strtok(line, ' ');
                line=line(2:end);
                wordCheck=13>=(length(word));
                wordVec=[wordVec, wordCheck];
                %indicates how many words have less than 13 letters
                lengthVec=[lengthVec, length(word)];
                %indicates the lengths of each word
            
            end
            line=fgetl(fh);
            %eliminates extraneous letters
            extra=(line<='z'&line>='a')|(line<='Z'&line>='A')|line==' ';
            line=line(extra);
        end
        fclose(fh);
        zeroCheck=lengthVec==0;
        lengthVec(zeroCheck)='';
        %outputs the reading level statement
        if sum(techVec)>=1 | all(lengthVec<=13)
           
            readingLevel='We''re at Georgia Tech, we can read that!';
        else
            
            readingLevel='We''re at Georgia Tech, we can''t read that :(';
        end

    %creates a vector with the x values
    maxLength=max(lengthVec);
    %creates a vector for the y values
    occurences=[];
    maxLengthVec=1:maxLength;
    
        for x=1:maxLength
            
            checker=strfind(lengthVec,maxLengthVec(x));
            occurences=[occurences, length(checker)];
            
        end
        
    %lines 65 through 72 plot the info    
    hold on
    file=textfile(1:end-4);
    name=sprintf('Can we read %s?',file);
    title(name);
    ylabel('Number of Occurrences');
    xlabel('Length of Word');    
    bar(occurences);
    hold off 

end
