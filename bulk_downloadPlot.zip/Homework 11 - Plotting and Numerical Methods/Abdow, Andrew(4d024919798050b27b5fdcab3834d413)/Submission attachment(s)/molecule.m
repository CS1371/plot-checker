function [] = molecule(lengths,angles,rings)
a=1;
points = [0,0];
hold on;
axis off;
axis square;
axis equal;
i=1;
while(i<=length(lengths))
    a = sum(angles(1:i));
    x=lengths(i).*cosd(sum(angles(1:i)));
    y=lengths(i).*sind(sum(angles(1:i)));
    b = sum(points(:,1));
    x1 = x + points(i,1);
    y1 = y + points(i,2);
    points = [points;x1,y1];
    i=i+1;
    x = transpose(points(:,1));
    y = transpose(points(:,2));
    plot(x,y,'k-');
end
x = transpose(points(:,1));
y = transpose(points(:,2));
plot(x,y,'k-');
[r,c] = size(points);
hex = [];
rpts = [];
i=1;
while(i<=r-6)
    a = round(points(i,1),3);
    b = round(points(i+6,1),3);
    c = round(points(i,2),3);
    d = round(points(i+6,2),3);
    e = isequal(c,d);
    if(a == b) & (c == d)
        hex = [hex;transpose(points(i:i+6,1))];
        hex = [hex;transpose(points(i:i+6,2))];
        rpts = [rpts,lengths(i)];
    end
    i=i+1;
end
%i=1;
%[r,c] = size(hex);
%centers = [];
%while(i<=r)
    %a = hex(i,1);
    %b = hex(i,2);
    %c = hex(i,3);
    %d = hex(i,4);
    %e = hex(i,5);
    %f = hex(i,6);
   % g = hex(i+1,1);
    %h = hex(i+1,2);
    %k = hex(i+1,3);
    %l = hex(i+1,4);
   % m = hex(i+1,5);
    %n = hex(i+1,6);
%    centers = [centers,findCenter(hex(i:i+1,:))];
%    i=i+2;
%end

centers = findCenter(transpose(points));
[r,c] = size(centers);
i=1;
%while(i<=c)
%    j=i+1;
%    while(j<c)
%        a=round(centers(:,i),3);
%        b=round(centers(:,j),3);
%        if(a==b)
%            centers(:,j) = [];
%        end
%        j=j+1;
%    end
%    i=i+1;
%end

th = linspace(0,2.*pi,100);
i=1;
while(i<=length(rings))
    if(rings(i))
        r = .65.*rpts(i);
        x = r.*cos(th);
        y = r.*sin(th);
        x1 = x + centers(1,i);
        y1 = y + centers(2,i);
        plot(x1,y1,'b-');
        
    end
    i=i+1;
end
hold off
end  