function [opm,area] = proctorTest(data,percent)
[num,txt,~] = xlsread(data);
moisture = transpose(num(1:end,1));
dryweight = transpose(num(1:end,2));
plot(moisture,dryweight);
dydx = diff(dryweight)./diff(moisture);
mids = [];
i=1;
while(i<length(moisture))
    midpoint =( moisture(i) + moisture(i+1))./2;
    mids = [mids, midpoint];
    i=i+1;
end
xmax = interp1(dydx,mids,0,'spline');
ymax = interp1(moisture,dryweight,xmax,'spline');
[~,rest] = strtok(txt{1},'(');
a = rest == '(' | rest == ')';
moistureunits = rest(~a);
[~,rest] = strtok(txt{2},'(');
a = rest == '(' | rest == ')';
dryunits = rest(~a);
opm = sprintf('%0.3f %s, %0.3f %s',xmax,moistureunits,ymax,dryunits);
tolerance = (percent.*.01).*ymax;
a = dryweight>=tolerance;
xa = moisture(a);
ya = dryweight(a) - tolerance;
area = round(trapz(xa,ya),3);