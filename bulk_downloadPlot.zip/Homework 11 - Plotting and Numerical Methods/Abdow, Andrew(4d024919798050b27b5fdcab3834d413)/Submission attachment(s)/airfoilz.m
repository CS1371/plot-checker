function out = airfoilz(aoa,lift,angles)

hold on;
subplot(1,1,1);
plot(aoa,lift,'b*');
p2 = polyfit(aoa,lift,2);

yfit = [];
i=1;
p1 = aoa(i):aoa(end);
while(i<=length(p1))
    a = (p2(1).*(p1(i).^2))+(p2(2).*p1(i))+p2(3);
    yfit = [yfit, a];
    i=i+1;
end
plot(p1,yfit,'k-');
p3 = interp1(p1,yfit,angles,'spline');
out = round(p3,3);
hold off;
end