function [] = cellGrowth(counts,points)
a=counts;
b=points;
subplot(1,1,1);

hold on;
axis square;
range = points(end)-points(1);
r = .05.*range;
xmin = points(1)-r;
xmax = points(end)+r;
range = counts(end)-counts(1);
r = .05.*range;
ymin = counts(1)-r;
ymax = counts(end)+r;

plot(points,counts,'r.');
avg = zeros(1,length(counts)) + mean(counts);

plot(points,avg,'b-.');
maxs = zeros(1,length(counts)) + max(counts);
plot(points,maxs,'m--');
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');





axis([xmin,xmax,ymin,ymax]);