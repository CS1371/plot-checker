function level = wordDist(str)
fh = fopen(str,'r');
line = lower(fgetl(fh));
l=0;
tech = false;
occurrences = zeros(1,100);
while(ischar(line))
    line = lower(line);
    line = [' ',line,' '];
    i=1;
    b = ~((line>='a' & line<='z') | line == ' ');
    line(b)=[];
    if(~(all(line==' ')))
        while(line(i)==' ')
            i=i+1;
        end
    end
    while(~(all(line==' ')))
        word = [];
        while(line(i)~=' ')
            word = [word,line(i)];
            i=i+1;
        end
        if(strcmpi('technology',word))
            tech = true;
        end
        if(l(end)~=length(word))
            l = [l,length(word)];
        end
        word = [' ',word,' '];
        occurrences(length(word)-2) = (occurrences(length(word)-2)) + length(strfind(line,word));
        a = strfind(line,word);
        j=1;
        while(j<=length(a))
            line(a(j)+1:a(j)+length(word)-1) = [];
            a=a-(length(word)-1);
            j=j+1;
        end
        %line = [' ',line];
        i=1;
        if(~(all(line==' ')))
            while(line(i)==' ')
                i=i+1;
            end
        end
    end
    line = fgetl(fh);
end
a=occurrences(end:-1:1);
while(a(1)==0)
    a(1)=[];
end
occurrences = occurrences(1:length(a));
bar(1:length(occurrences),occurrences);
title(['Can we read ',str(1:end-4),'?']);
xlabel('Length of Word');
ylabel('Number of Occurrences');

if(length(occurrences)<=13 | tech)
    level = 'We''re at Georgia Tech, we can read that!';
else
    level = 'We''re at Georgia Tech, we can''t read that :(';
end
fclose(fh);
end

