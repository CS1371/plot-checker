function [str abc] = proctorTest(raw,perc)
[num txt raw] = xlsread(raw);
moist = cell2mat(raw(2:end,1)); 
dry = cell2mat(raw(2:end,2));
[a wtrunit] = strtok(raw(1,1),'(');
wtrunit = cell2mat(wtrunit);
wtrunit(wtrunit=='(' | wtrunit == ')') = [];
[a dunit] = strtok(raw(1,2),'(');
dunit = cell2mat(dunit);
dunit(dunit=='(' | dunit == ')') = [];
%max dry unit weight %corresponding water content
deriv = diff(dry)./diff(moist); %numerically differentiate date
%diff, half diff, add half diff to all but last number
midpnt = (diff(moist)./2) + moist(1:end-1);
mx = interp1(deriv,midpnt,0,'spline'); %find zero using spline 
wtrcnt = round(mx.*1000)./1000;
duw = round(1000.*interp1(moist,dry,mx,'spline'))./1000;
% '<moisture content> <units>, <max dry unit weight> <units>
str = sprintf('%0.3f %s, %0.3f %s',wtrcnt,wtrunit,duw,dunit);
%find value of perc percentile
val = (perc./100) .* duw;
dry = dry - val;
abc = trapz(moist,dry);
end