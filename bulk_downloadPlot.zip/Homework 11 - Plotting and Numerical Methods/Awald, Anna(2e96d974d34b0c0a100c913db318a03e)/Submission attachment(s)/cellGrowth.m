function cellGrowth(count,time) %y,x
pts = length(time); %get number of points
ave = mean(count); %get average count
ave = ones(pts).*ave; %create vector of ave the length of points
mx = max(count); %get max
mx = ones(pts).*mx; %create vector of max the length of points
%plot growth - red points, mean population size - blue dashdot, max population size - magenta dash
plot(time,count,'r.',time,ave,'b-.',time,mx,'m--');
%axes range +-5
xr = max(time)-min(time); %time range
yr = max(count)-min(count); %count range
%add/subtract 5% of range from max and mins
xmn = min(time) - (.05 .* xr); 
xmx = max(time) + (.05 .* xr);
ymn = min(count) - (.05 .* yr);
ymx = max(count) + (.05 .* yr);
axis([xmn xmx ymn ymx]); 
%square axis
axis('square');
%title 'Cell Growth vs Time'
title('Cell Growth vs Time');
%Label the xaxis 'Time'
xlabel('Time');
%Label the yaxis '# Cells'
ylabel('# Cells');
end