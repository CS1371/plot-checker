function molecule(lnth,angle,ring)
lines = length(lnth);
angle = deg2rad(angle);
angle = [0 angle];
xi = 0;
yi = 0;
%loop for each line
for n = 1:lines
    theta1 = angle(n); %previous angle
    theta2 = angle(n+1); %rotated angle
    %get x value
    x = lnth(n).*cos(theta1);
    %get y value
    y = lnth(n).*sin(theta1);
    [pnt] = [cos(theta2), -sin(theta2);sin(theta2), cos(theta2)]*[x;y];
    xf = pnt(1);
    yf = pnt(2);
    %draw line
    xf = xi + xf;
    yf = yi +yf;
    line([xi xf],[yi yf]);
    xi = xf;
    yi = yf;
end
end