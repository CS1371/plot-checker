function [out] = wordDist(txt)
%open txt file
fh = fopen(txt);
line = fgetl(fh);
totnums = []; %initialize cell array for lengths of each word
%loop to read line by line
while ischar(line)
    line = lower(line); %make the entire line lower case
    tech = strfind(line,'technology'); %look for the word technology
    if length(tech)>0 %if technology found 
        read = true; %set to true
    end
    chrs = line < 'A' & line ~= 32| line > 'Z' & line < 'a' | line > 'z'; %index position of anything not a letter or space
    line(chrs) = []; %replace extrenuous characters with spaces
    words = strsplit(line); %split words at spaces into array
    nums = cellfun(@length,words); %get the length of each word
    totnums = [totnums nums]; %concatenate the vector of word lengths for each line together
    line = fgets(fh); %get next line
end
fclose(fh); %close txt file
if read == true %if 'technology' is found 
    out = 'We''re at Georgia Tech, we can read that!'; %set output to read
else
    if any(totnums > 13) %if any word is greater than 13 letters
            out = 'We are at Georgia Tech, we can''t read that :(';  %output can't read
        else %if all woulds less than 13 letters
            out = 'We''re at Georgia Tech, we can read that!'; %output can read
        end
end
%bar graph
x = unique(totnums); %find all the word lengths used
y = hist(totnums,x); %count the occurances of each word length
bar(x,y); %create a bar graph
xlabel('Length of Word'); %label x axis
ylabel('Number of Occurrences'); %label y axis
tit = txt(1:end-4); %get the name of the txt file minus the '.txt'
tit = sprintf('Can we read %s?',tit); %print the title 
title(tit); %label the title
end