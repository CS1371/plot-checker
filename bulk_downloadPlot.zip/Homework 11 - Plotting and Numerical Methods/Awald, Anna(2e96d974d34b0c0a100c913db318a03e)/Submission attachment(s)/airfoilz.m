function [lift] = airfoilz(attack,coef,angle)
rg = linspace(min(attack),max(attack)); %vector of integers within range of angle of attack
fit = polyfit(attack,coef,2); %fit the angle of attack vs lift coef data to 2nd poly
fit = polyval(fit,rg); %evaluate the 2nd fit at the integer vector (rg)
plot(attack,coef,'b*',rg,fit,'k'); %plot the data and the poly fit
lift = interp1(rg,fit,angle,'spline'); %get the value(s) specified by angle as a function of the poly fit
lift = round(lift.*1000)./1000; %round to the nearest thousandth
end