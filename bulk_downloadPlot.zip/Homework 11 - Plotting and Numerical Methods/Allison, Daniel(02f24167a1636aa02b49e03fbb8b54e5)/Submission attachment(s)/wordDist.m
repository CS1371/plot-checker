function strf = wordDist(str)
fh = fopen(str);
book = str(1:end-4);
line = fgetl(fh);
arr = [1:20;zeros(1,20)];
while ischar(line)
    mask = line((line >= 'a' & line <= 'z') | (line >= 'A' & line <= 'Z') | line == ' ');
    line = lower(mask);
    test = strfind(line,'technology');
    if ~isempty(test)
        strf = 'We''re at Georgia Tech, we can read that!';
        break
    end
    while ~isempty(line)
        [word , line] = strtok(line);
        l = length(word);
        arr(2,l) = arr(2,l)+1;
    end
    line = fgetl(fh);
    if any(arr(2,14:20)~=0)
    strf = 'We''re at Georgia Tech, we can''t read that :(';
    else strf = 'We''re at Georgia Tech, we can read that!';
    end
end
mask2 = arr(2,:) ~= 0;
arr = arr(:,mask2);
bar(arr(2,:))
title(sprintf('Can We Read %s?' , book))
xlabel('Length of Word')
ylabel('Number of Occurrences')
end