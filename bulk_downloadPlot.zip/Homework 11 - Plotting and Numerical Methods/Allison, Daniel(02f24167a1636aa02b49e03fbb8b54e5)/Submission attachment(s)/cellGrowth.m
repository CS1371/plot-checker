function cellGrowth(cells , times)
hold on
plot(times,cells,'r.')
ave = mean(cells);
top = max(cells);
avevec = ave*ones(1,length(times));
topvec = top*ones(1,length(times));
plot(times,avevec,'b-.')
plot(times,topvec,'m--')
xvar = (max(times)-min(times))*.05;
yvar = (max(cells)-min(cells))*.05;
xmin = min(times)-xvar;
xmax = max(times)+xvar;
ymin = min(cells)-yvar;
ymax = max(cells)+yvar;
axis([xmin xmax ymin ymax])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end