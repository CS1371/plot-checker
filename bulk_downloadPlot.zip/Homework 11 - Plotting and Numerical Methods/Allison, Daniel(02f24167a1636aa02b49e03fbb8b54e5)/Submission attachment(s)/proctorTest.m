function [str , area] = proctorTest(excel,percent)
[~,~,raw] = xlsread(excel);
x = cell2mat(raw(2:end,1))';
y = cell2mat(raw(2:end,2))';
derivy = diff(y)./diff(x);
derivx = x(1:end-1) +.5*diff(x);
mc = raw{1,1};
mc = mc(18:end);
mc(mc =='(' | mc == ')') = '';
duw = raw{1,2};
duw = duw(17:end);
duw(duw =='(' | duw == ')') = '';
maxx = interp1(derivy , derivx , 0 , 'spline');
maxy = interp1(x , y , maxx , 'spline');
str = sprintf('%0.3f %s, %0.3f %s' , maxx , mc , maxy , duw);
shifty = y -(percent*maxy./100);
shifty(shifty < 0) = 0;
area = trapz(x,shifty);
end