function molecule(lengths,angles,rings)
hold on
arr = [0,0];
angle = 0;
angles = angles*pi/180;
for i = 1:length(lengths)
    angle = angle+angles(i);
    arr = [arr;lengths(i)*cos(angle)+arr(i,1),lengths(i)*sin(angle)+arr(i,2)];
    plot(arr(:,1),arr(:,2),'k-')
end
[centers , sizes] = findCenter(arr');
centers = centers(:,rings);
sizes = .65 * sizes(rings);
theta = linspace(0,2*pi);
for i = 1:length(sizes)
plot(sizes(i) .* cos(theta) + centers(1,i) , sizes(i) .* sin(theta) + centers(2,i) , 'b.');
end
axis square
axis off
end