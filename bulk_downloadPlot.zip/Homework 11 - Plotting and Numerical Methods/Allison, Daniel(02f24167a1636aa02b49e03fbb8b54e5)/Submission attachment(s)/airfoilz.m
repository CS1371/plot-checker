function lift = airfoilz(angles,liftcs,deters)
hold on
plot(angles,liftcs,'b*')
line = polyval(polyfit(angles,liftcs,2),min(angles):max(angles));
plot(min(angles):max(angles),line,'k-')
lift = round(interp1(min(angles):max(angles),line,deters,'spline'),3);
end