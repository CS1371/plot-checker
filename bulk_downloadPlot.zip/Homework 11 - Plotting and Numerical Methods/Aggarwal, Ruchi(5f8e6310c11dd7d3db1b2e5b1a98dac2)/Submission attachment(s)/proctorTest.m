function [optimal, area] = proctorTest(fileName, maxDWU)
[nums,txt,raw] = xlsread(fileName)

%--------finds the unit names--------
unit1 = txt{1}
unit2 = txt{2}
oneone = strfind(unit1, '(')
twoone = strfind(unit1, ')')
onetwo = strfind(unit2, '(')
twotwo = strfind(unit2, ')')
moist_units = unit1(oneone+1:twoone-1)
dry_units = unit2(onetwo+1:twotwo-1)
%^^^^^^^^^finds the unit names^^^^^^^^


moist_nums = nums(1:end/2) %creates a vector of all of the moist values
dry_nums = nums(end/2+1:end) %creates a vector of all of the dry values

 %finds the derivative of the y
moist_deriv = []
for i = 1:length(moist_nums) %finds the midpoint values of x
    if moist_nums(i) ~= moist_nums(end)
    moist_derivi = ((moist_nums(i+1) - moist_nums(i))/ 2) + moist_nums(i);
    moist_deriv = [moist_deriv moist_derivi] 
    end
end
dry_deriv = diff(dry_nums) ./ moist_deriv

newthing = dry_deriv./ moist_deriv

mypoly = polyfit(moist_nums(1:end-1), newthing, 2)
yvals = polyval(mypoly, [0])

[m, i] = max(dry_nums)
q = moist_nums(i)

optimal = sprintf('%d %s, %d %s', round(q,3), moist_units, round(m,3), dry_units)
area = (q+m)/2


end