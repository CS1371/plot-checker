function cellGrowth (cellCounts, timePoints)
plot(timePoints, cellCounts, 'r.'); %Plot the cell count (y�axis) vs time data (x�axis) in red points
hold on; %to make all the graphs lay on top of each other
M = ones(1, length(timePoints)); %makes a vecor of ones the same size as the x
mea = mean(cellCounts); %finds the mean value
plot(timePoints, mea*M, 'b-.'); %plots the mean value against the x axis
ma = max(cellCounts); %finds the biggest number
plot(timePoints, ma*M, 'm--'); %plots the max value against the x axis
axis square; %makes the axis square
title('Cell Growth vs Time'); %changes title
xlabel('Time'); %changes x axis label
ylabel('# Cells'); %changes y axis label
axis tight; %adds the 5% margin of error
hold off; %turns the holding off
end