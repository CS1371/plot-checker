function coeff = airfoilz (angs, liftCoef, angs2)
hold on;
plot(angs, liftCoef, 'b*'); %graphs original data
newangs = (min(angs): 1: max(angs)); %makes a new vector of integers
newys = interp1(angs, liftCoef, newangs); %finds the new y values for those integers
newPolyCoefs = polyfit(angs, liftCoef, 2); %finds the line of fit from OLD values
yvals = polyval(newPolyCoefs, newangs); %finds the new ys with NEW values for x off of the line of fit
plot(newangs, yvals, 'k-'); %plots the new xs and new ys 
ysfornewangs = polyval(newPolyCoefs, angs2); %finds the specific attack angle coefficients
coeff = round(ysfornewangs, 3); %rounds all of those numbers to 3 decimal points and outputs
end