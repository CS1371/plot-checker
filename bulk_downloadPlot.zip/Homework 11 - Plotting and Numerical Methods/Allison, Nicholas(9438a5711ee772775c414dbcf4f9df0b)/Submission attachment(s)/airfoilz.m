function result = airfoilz(angles,lifts,angles2)
    maxA = max(angles);
    minA = min(angles);
    newAngles = (minA:maxA);
    figure(1);
    plot(angles,lifts,'b*');
    hold on;
    coeff = polyfit(angles,lifts,2);
    x = newAngles;
    y = polyval(coeff,x);
    plot(x,y,'k');
    newy = spline(x,y,angles2)
    result = (round(newy*1000))/1000;
    
end