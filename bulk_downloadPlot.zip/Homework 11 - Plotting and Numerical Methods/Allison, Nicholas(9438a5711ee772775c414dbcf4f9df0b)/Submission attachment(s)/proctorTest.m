function [resultstr, resultd] = proctorTest(name, numb)
    [num,txt,raw] = xlsread(name);
    x = num(:,1)';
    y = num(:,2)';
    diffx = diff(x);
    dy = [diff(y)./diff(x)];
    for i = 1: length(x)-1;
        dx(i) = (x(i) + x(i+1))/2;
    end;
    newx = interp1(dy,dx,0,'spline');
    
    newy = interp1(x,y,newx,'spline');
    
    unit1 = raw{1,1};
    [derp,unit1] = strtok(unit1,'(');
    unit1 = unit1(2:end-1);
    unit2 = raw{1,2};
    [derp,unit2] = strtok(unit2,'(');
    unit2 = unit2(2:end-1);
    
    newy = interp1(x,y,newx,'spline');
    
    number = newy*numb/100;
    
    adjustedY = y - number;
    
    finaly = adjustedY(adjustedY > 0);
    finalx = x(adjustedY > 0);
    
    derp = trapz(finalx,finaly);
    
    resultstr = sprintf('%0.3f %s, %0.3f %s',newx, unit1, newy, unit2);
    resultd = derp;
end