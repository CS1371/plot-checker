function [] = cellGrowth(cells,times)
    figure(1);
    plot(times,cells,'r.');
    hold on;
    meanY = mean(cells);
    means = meanY * ones(1,length(cells));;
    plot(times,means,'b-.');
    maxx = max(times);
    minx = min(times);
    miny = min(cells);
    maxy = max(cells);
    maxes = maxy * ones(1,length(cells));;
    plot(times,maxes,'m--');
    difx = maxx-minx;
    dify = maxy-miny;
    diffx = difx*0.05;
    diffy = dify*0.05;
    axis([(minx - diffx) (maxx+diffx) (miny-diffy) (maxy+diffy)]);
    xlabel('Time');
    ylabel('# Cells');
    title('Cell Growth vs Time');
    axis square;
end