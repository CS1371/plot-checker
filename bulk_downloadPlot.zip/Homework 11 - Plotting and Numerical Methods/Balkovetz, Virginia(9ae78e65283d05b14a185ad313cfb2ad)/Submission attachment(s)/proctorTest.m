function [str,area] = proctorTest(excel,percent)

[num text raw] = xlsread(excel);

moisturecontent = raw(2:end,1);
dryunitweight = raw(2:end,2);

% x = moisturecontent
% y = dryunitweight

moisturecontent = cell2mat(moisturecontent);
dryunitweight = cell2mat(dryunitweight);

moisturecontent = reshape(moisturecontent,1,[]);
dryunitweight = reshape(dryunitweight,1,[]);

% dyoverdx = diff(dryunitweight)./diff(moisturecontent);
% 
% coe = polyfit(moisturecontent,dryunitweight,2);
% drtv = coe(1:end - 1) .* [length(coe) - 1 : -1 : 1];
% 
% xval = -drtv(2)/drtv(1)
% 
% flat = spline(moisturecontent,dryunitweight,xval)

dyoverdx = diff(dryunitweight)./diff(moisturecontent);
diffX = moisturecontent(2:end) - moisturecontent(1:end-1);
diffX = diffX./2 + moisturecontent(1:end-1);

percentmoisture = spline(dyoverdx,diffX,0); %%%%%%%%%%%%

dryweightvalue = spline(moisturecontent,dryunitweight,percentmoisture); %%%%%%%%%%%%

%   %   %   %   %   %   %   %   %   %   %   %   %   % 

lowery = percent/100*dryweightvalue;
uppery = dryweightvalue;

coe = polyfit(moisturecontent,dryunitweight,2);
int = coe./(length(coe):-1:1);

eqtn = [coe(1:2), coe(3)-lowery];

r = roots(eqtn);

rmax = max(r);
rmin = min(r);

% un = eqtn(1);
% du = eqtn(2);
% tr = eqtn(3);

% xpoints = [rmin moisturecontent rmax];
% ypoints = [0 dryunitweight-lowery 0];

xpoints = [moisturecontent];
ypoints = [dryunitweight-lowery];

graphis = [xpoints ypoints];

b = dryweightvalue;
c = percentmoisture;

str = sprintf('%0.3f %%, %0.3f lb/ft^3',c,b); % '%0.3f'
area = trapz(xpoints,ypoints);

% upperlimitint = un*rmax^2 + du*rmax + tr
% lowerlimitint = un*rmin^2 + du*rmin + tr
% 
% integral = upperlimitint - lowerlimitint

end