function cellGrowth(cell,time)

plot(time,cell,'r.');

title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
axis square

hold on

lowerrange = min(time);
upperrange = max(time);

rangelength = upperrange - lowerrange;

cellentries = length(cell);
cellmax = max(cell);

cumSum = cumsum(cell);
cumSum = cumSum(end);

cellavg = cumSum ./ cellentries;

% % % % % % % % % % % % % plotting average line % % % % % % % % % % % %

xspacing = linspace(lowerrange,upperrange);

onez = ones(length(xspacing));
ys = onez*cellavg;

r = length(xspacing);
s = length(ys);

plot(xspacing,ys,'b-.')

hold on

ymin = min(cell) - 0.05*(max(cell)-min(cell));
ymax = max(cell) + 0.05*(max(cell)-min(cell));

xmin = min(time) - 0.05*(max(time)-min(time));
xmax = max(time) + 0.05*(max(time)-min(time));

axis([xmin xmax ymin ymax]);

% % % % % % % % % % % % % plotting max line % % % % % % %% % % % % % %

yz = onez*cellmax;

plot(xspacing,yz,'m--')
axis([xmin xmax ymin ymax]);

hold on

end