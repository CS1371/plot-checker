function [character] = wordDist(txt)

fh = fopen(txt,'r');
line = fgetl(fh);

lengthvector = [];
techVec = [];

while ischar(line)
    
    [word,rest] = strtok(line);
    
    while ~isempty(word)
        
        letters = word>='A' & word<='Z' | word>='a' & word<='z';
        
        lengthOfWord = sum(letters);
        
        lengthvector = [lengthvector lengthOfWord];
        [word,rest] = strtok(rest);
        
        technah = strcmpi(word,'technology');
        
        techVec = [techVec technah];
        techSum = sum(techVec);
        
    end
    
    line = fgetl(fh);
    
end

fclose(fh)

numVec = [];
totalNumVec = [];

while ~isempty(lengthvector)
   
    firstNum = lengthvector(1); 
    mask = lengthvector==firstNum; 
    totalNum = sum(mask);
    
    lengthvector(mask) = [];
    
    numVec = [numVec firstNum];
    totalNumVec = [totalNumVec totalNum];
    
end

[numVecSorted ind] = sort(numVec);
totalNumVecSorted = totalNumVec(ind);

bar(numVecSorted,totalNumVecSorted)
title(sprintf('Can we read %s?',txt(1:end-4)))
xlabel('Length of Word')
ylabel('Number of Occurences')

if numVecSorted(end)>=14
    if techSum>=1
        character = sprintf('We''re at Georgia Tech, we can read that!');
    else
        character = sprintf('We''re at Georgia Tech, we can''t read that :(');
    end
else
    character = sprintf('We''re at Georgia Tech, we can read that!');
end

char = character;

end