function liftco = airfoilz(allangles,liftcoeffs,unknownangles)

plot(allangles,liftcoeffs,'b*')
xlabel('x');
ylabel('y');
% axis square;

coe = polyfit(allangles,liftcoeffs,2);
newx = linspace(min(allangles),max(allangles));
newy = polyval(coe,newx);

hold on

plot(newx,newy,'k-')

hold off

liftco = interp1(newx,newy,unknownangles,'spline');
liftco = round(liftco,3);

end