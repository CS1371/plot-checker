function [] = cellGrowth(cell,time)

figure(3);%
hold on;%

x1 = time;%
y1 = cell;%
plot(x1,y1,'r.');%

avg = mean(y1);%
y2 = zeros(1,length(y1)) + avg;%
plot(x1,y2,'b-.');%

big = max(y1);%
y3 = zeros(1,length(y1)) + big;%
plot(x1,y3,'m--');%

yAxisMin = min(y1) - 0.05.*max(y1)%
yAxisMax = max(y1) + 0.05.*max(y1)%
xAxisMin = min(x1) - 0.05.*max(x1)%
xAxisMax = max(x1) + 0.05.*max(x1)%

axis([xAxisMin xAxisMax yAxisMin yAxisMax])%
axis square%

xlabel('Time')%
ylabel('# Cells')%
title('Cell Growth vs Time')%
end