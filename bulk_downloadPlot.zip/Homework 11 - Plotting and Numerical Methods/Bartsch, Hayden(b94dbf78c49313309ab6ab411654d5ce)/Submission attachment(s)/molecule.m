function [] = molecule(mL,mA,mR)
mA = cumsum(mA);%

x = 0;%
y = 0;%

for i = 1:length(mL)
ang = mA(i);%
vec = [mL(i)*cosd(ang)+x(i);mL(i)*sind(ang)+y(i)];%
x = [x vec(1)];%
y = [y vec(2)];%
end

figure(1);%
plot(x,y,'k');%
hold on;%

[cntr,radi] = findCenter([x;y]);%
[r,~] = size(cntr);%
center = [];%
for k = 1:r
    mask = mR;%
    cntrA = cntr(k,:);%
    cntrA(~mask) = [];%
    center = [center;cntrA];%
end
cntr = center;%
[~,c] = size(cntr);%
for j = 1:c
    radia = radi(:,j)*0.65;%
    th = linspace(0,2*pi,100);%
    xc = radia*cos(th)+cntr(1,j);%
    yc = radia*sin(th)+cntr(2,j);%
    plot(xc,yc,'b');%
end
axis square;%
axis off;%
end