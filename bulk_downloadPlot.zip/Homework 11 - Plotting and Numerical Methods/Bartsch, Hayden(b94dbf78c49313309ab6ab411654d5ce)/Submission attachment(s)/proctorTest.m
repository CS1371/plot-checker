function [out1, area] = proctorTest (file,perc)
[num,txt,raw] = xlsread(file);%
mid = [];%

xU1 = strfind(txt{1},'(');%
xU2 = strfind(txt{1},')');%
xUnit = txt{1}([xU1+1:xU2-1]);%

yU1 = strfind(txt{2},'(');%
yU2 = strfind(txt{2},')');%
yUnit = txt{2}([yU1+1:yU2-1]);%

x = num(:,1)';%
y = num(:,2)';%

derivY = diff(y)./diff(x);%
for i = 1:length(x)-1
    midA = (x(i)+x(i+1))./2;%
    mid = [mid midA];%
end
derivX = mid;%

mc = interp1(derivY,derivX,0,'spline');%
duw = interp1(x,y,mc,'spline');%
out1 = sprintf('%0.3f %s, %0.3f %s',mc,xUnit,duw,yUnit);%

newY = (perc/100)*duw;%
newY = y - newY;%
mask = newY <= 0;%
x(mask) = [];%
newY(mask) = [];%

area = round(trapz(x,newY),3);%
end