function out = wordDist(file)
name = file(1:end-4);%
fid = fopen(file);%
count = [];%
vec = [];%
tech = 0;%
line = fgetl(fid);%
while ischar(line)
    line(~((line>='a'&line<='z')|(line>='A'&line<='Z')|(line==' ')))=[];%
    wordCount = length(line(line == ' '))+1;%
    for i = 1:wordCount
        [word line] = strtok(line,' ');%
        if strcmpi(word,'technology')
            tech = tech + 1;%
        end
        count = [count length(word)];%
    end
    line = fgetl(fid);%
end
if tech > 0 | all(count <= 13)
    out = 'We''re�at�Georgia�Tech,�we�can�read�that!';%
else
    out = 'We''re�at�Georgia�Tech,�we�can''t�read�that�:(';%
end
out(out==160) = ' ';%
minLength = min(count);%
maxLength = max(count);%
for j = minLength:maxLength
    num = 0;%
    if any(count == j)
        num = sum(count == j);%
    end
    vec = [vec num];%
end
figure(2);%
bar(vec(2:end));%
title(sprintf('Can we read %s?',name));%
xlabel('Length of Word');%
ylabel('Number of Occurrences');%
end