function out = airfoilz(x,y,ref)
figure(4);%
plot(x,y,'b*');%
hold on;%
p = polyfit(x,y,2);%
x1 = [min(x):max(x)];%
y1 = polyval(p,x1);%
plot(x1,y1,'k');%
out = round(interp1(x1,y1,ref,'spline'),3);%
end