function myFinalCoefficient = airfoilz(angles, coefficients, lift)
new_y = polyfit(angles, coefficients,2);
minAngle = min(angles);
maxAngle = max(angles);
angleRange = minAngle:maxAngle;
new_y = polyval(new_y, angleRange);
hold on
plot(angleRange, new_y, 'k')
plot(angles, coefficients, 'b*')
hold off
myFinalCoefficient = interp1(angleRange, new_y, lift, 'spline');
myFinalCoefficient = round(myFinalCoefficient,3);
end