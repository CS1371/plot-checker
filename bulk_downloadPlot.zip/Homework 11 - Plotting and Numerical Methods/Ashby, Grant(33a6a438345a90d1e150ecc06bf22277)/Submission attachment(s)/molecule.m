function molecule(segmentLength, whatsMyAngle, doTheyHaveANiceHole)
hold on
xvalues = [0];
yvalues = [0];
previousPoint = [0,0];
firstAngle = 0;
i = 1;
    while i <= length(segmentLength)
    myX = segmentLength(i) * cosd(firstAngle + whatsMyAngle(i)) + previousPoint(1);
    myY = segmentLength(i) * sind(firstAngle + whatsMyAngle(i)) + previousPoint(2);
    previousPoint = [myX, myY];
    xvalues = [xvalues, myX];
    yvalues = [yvalues, myY];
    firstAngle = firstAngle + whatsMyAngle(i);
    i = i +1;
    end
plot(xvalues, yvalues, 'k')
[theCentersFuckingLocation, circleLength]= findCenter([xvalues;yvalues]);
centersMask = theCentersFuckingLocation(:, doTheyHaveANiceHole);
circleLength = circleLength(doTheyHaveANiceHole) * 0.65;
j = 1;
centerXValuesStart = [];
centerYValuesStart = [];
centerXValues = [];
centerYValues = [];
angleTheta = linspace(0, 2 * pi);
    while j <= length(centersMask(1,:))
    centerXValuesStart = [centersMask(1, j)];
    centerYValuesStart = [centersMask(2, j)];
    centerXValues = [circleLength(j) .* cos(angleTheta) + centerXValuesStart];
    centerYValues = [circleLength(j) .* sin(angleTheta) + centerYValuesStart];
    j = j + 1;
    plot(centerXValues, centerYValues, 'b')
    end    
hold off
end

