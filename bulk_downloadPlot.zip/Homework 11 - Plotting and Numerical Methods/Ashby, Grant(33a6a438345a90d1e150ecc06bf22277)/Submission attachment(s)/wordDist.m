function amISmarterThanAFifthGrader = wordDist(myDankFile)
txt = fopen(myDankFile);
line = fgetl(txt);
lengthOfWords = [];
amISmarterThanAFifthGrader = [];
    while ischar(line)
    lengthOfSpaces = length(strfind(line, ' '));
        for i = 1:lengthOfSpaces
        line = lower(line);
          [myWord, line] = strtok(line, ' ');
          myMask = myWord >='a' & myWord <= 'z';
          myWord = myWord(myMask);
                if length(strfind(myWord, 'technology')) == 1
                amISmarterThanAFifthGrader = 'We''re at Georgia Tech, we can read that!';
                end
            lengthOfWords = [lengthOfWords, length(myWord)];
        end
     line = fgetl(txt);
    end 
fclose(txt);
 if any(lengthOfWords > 13) & length(strfind(amISmarterThanAFifthGrader,'We''re at Georgia Tech, we can read that!')) == 0 
 amISmarterThanAFifthGrader = 'We''re at Georgia Tech, we can''t read that :(';
 elseif all(lengthOfWords <= 13) & length(strfind(amISmarterThanAFifthGrader,'We''re at Georgia Tech, we can read that!')) == 0
 amISmarterThanAFifthGrader = 'We''re at Georgia Tech, we can read that!';  
 end
 newMask = lengthOfWords == 0;
 lengthOfWords(newMask) = [];
 minVal = min(lengthOfWords);
 maxVal = max(lengthOfWords);
 theVector = linspace(minVal, maxVal, maxVal);
 finalVector = zeros(length(theVector));
        for k = theVector
        myLogical = lengthOfWords == k;
        myLogical = sum(myLogical);
        finalVector(k) = myLogical;
        end
bar(theVector, finalVector);
xlabel('Length Of Word');
ylabel('Number Of Occurrences');
title(['Can We Read ', myDankFile(1:end-4), '?']);
end  