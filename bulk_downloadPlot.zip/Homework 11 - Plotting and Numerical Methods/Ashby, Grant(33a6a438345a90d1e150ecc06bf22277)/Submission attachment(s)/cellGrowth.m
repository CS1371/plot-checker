function cellGrowth(theyBeFuckin, damnTheyFast)
subplot(1,1,1)
hold on
plot(damnTheyFast, theyBeFuckin, 'r.')
[maxVal, indx] = max(theyBeFuckin);
maxValueVec(1:length(damnTheyFast)) = maxVal;
plot(damnTheyFast, maxValueVec, 'b-.')
[meanValue] = mean(theyBeFuckin);
meanValueVec(1:length(damnTheyFast)) = meanValue;
plot(damnTheyFast, meanValueVec, 'm--')
axis([min(damnTheyFast) * 0.95, max(damnTheyFast) * 1.05, min(theyBeFuckin) * 0.95, max(theyBeFuckin) * 1.05]);
axis square
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
hold off
end