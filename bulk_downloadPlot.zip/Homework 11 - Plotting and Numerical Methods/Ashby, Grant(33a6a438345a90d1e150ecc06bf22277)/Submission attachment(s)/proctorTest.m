function [whatsTheBest, area] = proctorTest(myFile, standardPercent)
[num, txt, raw] = xlsread(myFile);
moistureCol = raw(:,1);
dryWeightCol = raw(:, 2);
[~, mcUnits] = strtok(moistureCol{1,1}, '(');
[mcUnits, ~] = strtok(mcUnits(2:end), ')');
[~, dryWeightUnits] = strtok(dryWeightCol{1,1}, '(');
[dryWeightUnits, ~] = strtok(dryWeightUnits(2:end), ')');
xvalues = num(:, 1);
yvalues = num(:, 2);
slope = diff(yvalues) ./ diff(xvalues);
newXVal = [];
    for i = 1:length(xvalues)-1;
    newXVal(i) = (xvalues(i) + xvalues(i+1)) /2; 
    end
xValOfYMax = interp1(slope, newXVal, 0, 'spline');
yMax = interp1(xvalues, yvalues, xValOfYMax, 'spline');
yMax = round(yMax,3);
percentYVal = yMax * standardPercent / 100;
yvalues = yvalues - percentYVal;
area = cumtrapz(yvalues);
thisIsMyMask = area < 0;
area(thisIsMyMask) = [];
whatsTheBest = sprintf('%0.3f %s, %0.3f %s', xValOfYMax, mcUnits, yMax, dryWeightUnits);
end