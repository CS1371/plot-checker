function cellGrowth(cellCounts, timePoints);
%Find population mean and make it into a vector
meanPop = mean(cellCounts);
meanPop = ones(1,length(cellCounts)) .* meanPop;

%Find population max and make it into a vector
maxPop = max(cellCounts);
maxPop = ones(1,length(cellCounts)) .* maxPop;

%find x axis bounds
maxX = max(timePoints);
minX = min(timePoints);
xDiff = (maxX - minX) * .05;
maxX = maxX + xDiff;
minX = minX - xDiff;

%find y axis bounds
maxY = max(cellCounts);
minY = min(cellCounts);
yDiff = (maxY - minY) * .05;
maxY = maxY + yDiff;
minY = minY - yDiff;


hold on
plot(timePoints, cellCounts, 'r.');
plot(timePoints, meanPop, 'b-.');
plot(timePoints, maxPop, 'm--');


axis([minX maxX minY maxY]);
axis square;
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
box on
hold off
end