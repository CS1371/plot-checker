function [strOut, area] = proctorTest(fileName, percentile)

%Extract Data

%Find Units
[num, ~, raw] = xlsread(fileName);
%Find units in col 1 row 1
moistUnits = raw{1, 1};
[~, moistUnits] = strtok(moistUnits, '(');
[moistUnits, ~] = strtok(moistUnits, '()');
%Find units in col 2 row 2
dryUnits = raw{1, 2};
[~, dryUnits] = strtok(dryUnits, '(');
[dryUnits, ~] = strtok(dryUnits, '()');

%Get num vecs
moistVec = num(:,1);
dryVec = num(:,2);

%Find max x value and print string
dydx = diff(dryVec) ./ diff(moistVec);
xMid = moistVec(1:end-1) + (diff(moistVec)./2);
moistMax = interp1(dydx, xMid, 0, 'spline');
dryMax = interp1(moistVec, dryVec, moistMax, 'spline');

strOut = sprintf('%0.3f %s, %0.3f %s', moistMax,moistUnits,dryMax,dryUnits); 

%Use percentile to find bottom line for integration
percentile = percentile/100;
percentile = dryMax * percentile;
%Create mask to only have values above the percentile
mask = dryVec >= percentile;
dryVec = dryVec(mask);
moistVec = moistVec(mask);
%subtract the percentile from the dryVec(y) to only get the area between
%the curve and the line
dryVec = dryVec-percentile;
%Find integral
area = round(trapz(moistVec, dryVec),3);