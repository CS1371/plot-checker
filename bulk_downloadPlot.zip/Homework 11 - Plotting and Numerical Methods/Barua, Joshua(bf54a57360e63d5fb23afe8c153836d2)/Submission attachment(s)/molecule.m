function molecule (r,theta,hex)
xVec = 0;
yVec = 0;
deg = theta(1);
xVec(2) = r(1)*cosd(deg);
yVec(2) = r(1)*sind(deg);

%Use polar coordinates, use the radiuses from the r vec, and continue
%adding the thetas to get a degree.
%Make sure to add the previous point's coordinates so if makes a peicewise
%graph

for i = 2:length(r)
    deg = deg + theta(i);
    xVec(i+1)=xVec(i)+(r(i)*cosd(deg));
    yVec(i+1)=yVec(i)+(r(i)*sind(deg));
end
%Create matrix for findCenter
findIn = [xVec;yVec];
[centerLocs,hexSizes] = findCenter(findIn);
hexSizes = .65.*hexSizes;
centerX = centerLocs(1,:);
centerX(~hex) = [];
centerY = centerLocs(2,:);
centerY(~hex) = [];
hexSizes(~hex) = [];
theta = linspace(0,2*pi);
%Plotting
hold on
axis equal
axis off
plot(xVec,yVec,'k')
for j = 1:length(centerX)
    plot(centerX(j)+hexSizes(j)*cos(theta), centerY(j)+hexSizes(j)*sin(theta), 'b')
end
hold off


end

