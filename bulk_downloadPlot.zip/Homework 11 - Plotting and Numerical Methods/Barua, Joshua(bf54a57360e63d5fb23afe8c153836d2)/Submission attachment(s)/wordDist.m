function strOut = wordDist (fileName)
fh = fopen(fileName);
%Truncate off file ext
fileName = fileName(1:end-4);
countVec = [];
%Set conditional variables
canRead = true;
tech = false;
line = fgetl(fh);

%Outer while loop loops through each line, deletes everything except
%letters and spaces.
while ischar(line)
    mask = line >= 'a' & line <= 'z' | line >= 'A' & line <= 'Z' | line == ' ';
    line = line(mask);
   %Inner while loop goes through each line, finds length, adds length to
   %length vec, then changes one of the conditional variables if its length
   %is greater than 13 or if it is 'technology'
    while ~isempty(line)
        [word line] = strtok(line);
        leng = length(word);
        if length(countVec) < leng
            countVec(leng) = 1;
        else
            countVec(leng) = countVec(leng) + 1;
        end
        if leng > 13
            canRead = false;
        end
        if strcmp(word, 'technology')
            tech = true;
        end
    end
    line = fgetl(fh);
end
if tech == true | canRead == true
    strOut = 'We''re at Georgia Tech, we can read that!';
else
    strOut = 'We''re at Georgia Tech, we can''t read that :(';
end

%Plot Graph
xAxis = [1:length(countVec)];
yAxis = countVec;
bar(xAxis, yAxis);
title(sprintf('Can we read %s?', fileName));
xlabel('Length of Word');
ylabel('Number of Occurrences');
end