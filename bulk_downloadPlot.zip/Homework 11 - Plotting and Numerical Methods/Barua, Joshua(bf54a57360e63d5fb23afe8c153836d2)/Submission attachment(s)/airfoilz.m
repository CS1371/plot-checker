function out = airfoilz(inAngles, inCoeffs, outAngles)
%Find polynomial coefficents
coeffs = polyfit(inAngles, inCoeffs, 2);
angleMin = min(inAngles);
angleMax = max(inAngles);
x = [angleMin:angleMax];
y = polyval(coeffs, x);
hold on
plot(x, y, 'k')
plot(inAngles, inCoeffs, 'b*')
box on
hold off

%Interpolate lift
out = round(interp1(x, y, outAngles, 'spline'), 3);