function molecule(lengthsVec, anglesVec, ringsVec)

spot1 = [0;0];
spotl = [0;0];

hold on

newAng = cumsum(anglesVec);

for i = 1:length(lengthsVec)
    newPoint = [lengthsVec(i); 0];
    matrix = [cosd(newAng(i)) -sind(newAng(i)); sind(newAng(i)) cosd(newAng(i))];
    newPoint = matrix * newPoint;
    newPoint = newPoint + spotl;
    spotl = newPoint;
    spot1 = [spot1, spotl];
end
    

    
    plot(spot1(1,:), spot1(2,:), 'k');
    
axis off
axis equal
    
    b = linspace(0,2*pi);
    [loc, sizes] = findCenter(spot1);
    loc = loc(:, ringsVec);
    
    [~, c] = size(loc);
    
    for i = 1:c
        x = 0.65.*sizes(i).*cos(b);
        y = 0.65.*sizes(i).*sin(b);
        x = loc(1, i) + x;
        y = loc(2, i) + y;
        plot(x,y,'b');
    end

end