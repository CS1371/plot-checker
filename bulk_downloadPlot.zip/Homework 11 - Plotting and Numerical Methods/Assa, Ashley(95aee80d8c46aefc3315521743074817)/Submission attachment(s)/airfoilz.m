function liftCoef = airfoilz(vecAngles, vecCoef, detAngles)

pol = polyfit(vecAngles, vecCoef, 2);
xVals = min(vecAngles):1:max(vecAngles);
polEval = polyval(pol, xVals);

plot(vecAngles, vecCoef, 'b*', xVals, polEval, 'k-');

liftCoef = interp1(xVals, polEval, detAngles, 'spline');
liftCoef = round(liftCoef, 3);

end