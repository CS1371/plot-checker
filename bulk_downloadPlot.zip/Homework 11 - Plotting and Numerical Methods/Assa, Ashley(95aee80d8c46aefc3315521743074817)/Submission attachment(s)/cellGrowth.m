function cellGrowth(cellCounts, times)

meanCellCount = mean(cellCounts);
maxCellCount = max(cellCounts);
meanVec = ones(1,length(times)).*meanCellCount;
maxVec = ones(1, length(times)).*maxCellCount;

addition = maxCellCount.*0.05;
yMax = maxCellCount + addition;
yMin = min(cellCounts) - addition;
addition2 = max(times).*0.05;
xMax = max(times) + addition2;
xMin = min(times) - addition2;

plot(times, cellCounts, 'r.');

hold on

plot(times, meanVec, 'b-.');

plot(times, maxVec, 'm--');

axis([xMin, xMax, yMin, yMax]);
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')

end