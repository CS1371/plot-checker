function string = wordDist(textFile)

fh = fopen(textFile, 'r');
line = fgetl(fh);

wordLengths = [];
techCheck = false;
while ischar(line)
    while ~isempty(line)
        if strcmpi(line, 'technology');
            techCheck = true;
        end
        mask1 = line>='a' & line<='z' | line>='A' & line<='Z' | line==' ';
        line(~mask1) = '';
        [word, rest] = strtok(line, ' ');
        num = length(word);
        wordLengths = [wordLengths num];
        rest = rest(2:end);
        line = rest;
    end
    line = fgetl(fh);
end

sorted = sort(wordLengths);
sorted(end+1) = 0;
highest = max(sorted);

numTimes = [];
count = 0;
for i = 1:max(sorted);
    j = 1;
    while isequal(i, sorted(j))
    count = count + 1;
    j = j + 1;
    end
    sorted(1:count) = [];
    numTimes = [numTimes, count];
    count = 0;
end

vec = 1:highest;
bar(vec, numTimes);
xlabel('Length of Words');
ylabel('Number of Occurances');
fileName = textFile(1:end-4);
title(sprintf('Can we read %s?', fileName));

if highest<=13
    techCheck = true;
end

if techCheck== true;
    string = 'We''re at Georgia Tech, we can read that!';
else
    string = 'We''re at Georgia Tech, we can''t read that:(';
end   

end