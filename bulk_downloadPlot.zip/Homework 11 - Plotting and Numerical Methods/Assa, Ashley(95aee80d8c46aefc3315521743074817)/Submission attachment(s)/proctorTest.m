function [string, area] = proctorTest(dataFile, percentile)

[num, raw, txt] = xlsread(dataFile);

moistureX = num(:, 1);
weightY = num(:, 2);
diffX = diff(moistureX);
diffY = diff(weightY);
derivative = diffY./diffX;
nums = [moistureX(1:end-1), moistureX(2:end)]';
midpoints = sum(nums)./2;

maxMoisture = spline(derivative, midpoints, 0);
maxWeight = spline(moistureX, weightY, maxMoisture);
maxMoisture2 = num2str(round(maxMoisture, 3));
maxWeight2 = num2str(round(maxWeight, 3));

moistHeader = char(raw(1,1));
moistNums = moistHeader(19:end-1);
weightHeader = char(raw(1,2));
weightNums = weightHeader(18:end-1);

string = [maxMoisture2, ' ', moistNums, ', ', maxWeight2, ' ', weightNums];

percents = maxWeight.*(percentile./100);
diffs = weightY - percents;
moistureX(diffs<0) = [];
diffs(diffs<0) = [];
area = trapz(moistureX, diffs);
area = round(area, 3);

end