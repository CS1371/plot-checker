function [ang]=airfoilz(att,lif,xi)
hold on
%finds the coefficients for a second degree polynomial
p=polyfit(att,lif,2);
%finds the domain of the x values
rang=[min(att),floor(min(att))+1:ceil(max(att))-1,max(att)];
y1=polyval(p,rang);
%plots the two
plot(rang,y1,'k');
plot(att,lif,'b*');
ang=round(interp1(rang,y1,xi,'spline'),3);
hold off
end