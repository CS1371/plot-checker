function [opt,dry]=proctorTest(file,DUW)
[num,txt,~]=xlsread(file);
open=strfind(txt, '(');
close=strfind(txt, ')');
%finds the units
wetUnit=txt{1}(open{1}+1:close{1}-1);
dryUnit=txt{2}(open{2}+1:close{2}-1);
y=num(:,2);
x=num(:,1);
%finds derivative
dif=diff(y)./diff(x);
wreck=diff(x);
for a=1:length(diff(x))
xi(a)=x(a)+wreck(a)/2; %#ok<AGROW>
end
x1=interp1(dif,xi, 0,'spline');
y1=interp1(x,y,x1,'spline');
%finds the limit above which to take the integral, and moves the section
%down to take proper integral
cut=y1*DUW/100;
mask=y>cut;
yInt=y(mask);
yInt=yInt-cut;
xInt=x(mask);
%finds integral
integral=trapz(xInt,yInt);
integral=round(integral,3);
x1=round(x1,3);
y1=round(y1,3);
opt=sprintf('%.3f %s, %.3f %s',x1,wetUnit,y1,dryUnit);
dry=integral;
end