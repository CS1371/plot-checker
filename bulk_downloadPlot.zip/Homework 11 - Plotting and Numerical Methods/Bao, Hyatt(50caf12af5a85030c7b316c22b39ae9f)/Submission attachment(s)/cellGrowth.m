function cellGrowth(cellC,timeP)
    hold on
    plot(timeP,cellC,'r.');
    %find cell growth average
    meani=mean(cellC);
    means=zeros(1,length(cellC));
    means(means==0)=meani;
    maxi=max(cellC);
    maxim=zeros(1,length(cellC));
    maxim(maxim==0)=maxi;
    %plots them
    plot(timeP,means,'b-.');
    plot(timeP,maxim,'m--');
    %finds the deviation of the x and y values
    deviX=(max(timeP)-min(timeP)).*0.05;
    deviY=(max(cellC)-min(cellC)).*0.05;
    %sets axis equal to specified deviation
    axis([(min(timeP)-deviX) (max(timeP)+deviX) (min(cellC)-deviY) (max(cellC)+deviY)]);
    title('Cell Growth vs Time');
    xlabel('Time');
    ylabel('# Cells');
    hold off
end