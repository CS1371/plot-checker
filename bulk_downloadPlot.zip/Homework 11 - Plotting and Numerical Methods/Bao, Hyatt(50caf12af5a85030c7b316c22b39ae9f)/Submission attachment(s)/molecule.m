function molecule(leng,angle,rings)
hold on
%finds the consecutive angles to rotate the lengths
theta=cumsum(angle);
%sets up array for containing x and y coordinates
x=zeros(1,length(theta)+1);
y=zeros(1,length(theta)+1);
%finds the new x and y coordinates from the new segment
for a=1:length(theta)
    x(a+1)=x(a)+leng(a)*cosd(theta(a));
    y(a+1)=y(a)+leng(a)*sind(theta(a));
end
%plots everything
plot(x,y,'k');
%sets axis to square so it is not squished
axis square
axis equal
%finds the center and radius of the hexagons

[cent, r]=findCenter([x;y]);
circR=0.65.*r;
t=linspace(0,2*pi,100);
%puts in the circles
for b=1:length(rings)
    if rings(b)==true
    x=circR(b).*cos(t)+cent(1,b);
    y=circR(b).*sin(t)+cent(2,b);
    plot(x,y,'b');
    end
end

axis off
hold off
end