function [level]=wordDist(file)
read=fopen(file,'r');
line1=fgets(read);
tech1=false;
counting=[];
tooLong=false;
%the while loop gradually pushes the entire text file into content, where
%it can be analyzed
content=[line1];
while ischar(line1)
    line1=fgets(read);
    content=[content line1 ' '];
end
    %lowers everything, and splits the text file into its individual words
    %to remove the special characters and count them.
    content=lower(content);
    a=strsplit(content);
    %removes the special characters in each word, and then counts them
    for b=1:length(a)
        wordTru=(double(a{b})>=double('a')&double(a{b})<=double('z'))|(double(a{b})>=double('A')&double(a{b})<=double('Z'));
        word=a{b}(wordTru);
        count=length(word);
        counting=[counting count];
    end
    %if too long, it sets too long to true
    if any(counting>13)
        tooLong=true;
    end
    %checks if technology is anywhere
    
    tech=strfind(content,'technology');
    if ~isempty(tech)
       tech1=true; 
    end
    %if too long and technology is not present, it is unreadable
    if tooLong==true&tech1==false
       level='We''re at Georgia Tech, we can''t read that :(';
       
    end
    %if otherwise, it is readable
    if tooLong==false|tech1==true
       level='We''re at Georgia Tech, we can read that!';
    end
    %checks occurrence of word lengths
    c=max(counting);
    for i=1:c
       d(i)=length(find(counting==i)); 
    end
    %outputs the bar graph
    bar(1:c,d);
    name=file(1:end-4);
    names=sprintf('Can we read %s?', name);
    xlabel('Length of Word');
    ylabel('Number of Occurrences');
    title(names);
    fclose(read);
end