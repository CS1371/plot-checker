function canWe = wordDist(file)
fh = fopen(file);
line = fgetl(fh);
tech = false;
wordVec = [];
file(end-3:end) = [];
% this sets things that I might need later
while ischar(line)
    lettersAndSpaces = line((line >= 'a' & line <= 'z') | line >= 'A' & line <= 'Z' | line == ' ');
    % this gets rid of the spaces and extra characters in the line
    for i = 1:length(strfind(lettersAndSpaces, ' ')) + 1
        [word, lettersAndSpaces] = strtok(lettersAndSpaces);
        if strcmpi(word, 'technology')
            tech = true; % if 'technology' is anywhere in the file, the answer is true
        end
        wordVec = [wordVec, length(word)];
        % this puts all the words into one character array
    end
    line = fgetl(fh);
end
fclose(fh);

biggest = max(wordVec);
allWords = zeros(1,biggest);
% this will store the y values of the bar graph

for i = 1:length(wordVec)
    ind = wordVec(i);
    if ind ~= 0
        allWords(ind) = allWords(ind) + 1;
        % this puts the y values in the bar graph
    end
end

bar(allWords)
title(sprintf('Can we read %s?', file));
xlabel('Length of Word');
ylabel('Number of Occurrences');
% this labels the axes

if tech % if it has the word 'technology'
    canWe = 'We''re at Georgia Tech, we can read that!';
elseif biggest <= 13 % if there is any word bigger than 13 words
    canWe = 'We''re at Georgia Tech, we can read that!';
else
    canWe = 'We''re at Georgia Tech, we can''t read that :(';
end
end