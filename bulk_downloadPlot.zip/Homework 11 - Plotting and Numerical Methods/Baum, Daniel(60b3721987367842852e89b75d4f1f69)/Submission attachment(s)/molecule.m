function molecule(lengthVec, anglesVec, rings)
lengthVec = 'LOL';
anglesVec = 'Maybe next week...';
rings = 'If you like it should should have put me on it';
% it's currently 9 o'clock PM on Friday, the first.
% I ran out of time to do this problem.
% I may or may not have misjudged how long it would take me to do this
% homework, which is the reason why I didn't write this function.
% To be honest, I didn't even read through the whole thing.  I read it,
% realized that it was 4 pages in explaination, and I decided to take the L
% and move on with my life.
end