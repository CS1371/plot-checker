function cellGrowth(cell, time)
plot(time, cell, 'r.');
hold on;
vals = ones(1,length(time));
plot(time, mean(cell) .* vals, 'b-.');
plot(time, max(cell) .* vals, 'm--');
% this plots everything that is wanted
val2 = (max(time) - min(time)) .* 0.05;
val3 = (max(cell) - min(cell)) .* 0.05 ;
axis([min(time) - val2, max(time) + val2, min(cell) - val3, max(cell) + val3]);
axis square;
% this sets the axes to the correct size, including the range, then sqaures it
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
% this labels the graph
end