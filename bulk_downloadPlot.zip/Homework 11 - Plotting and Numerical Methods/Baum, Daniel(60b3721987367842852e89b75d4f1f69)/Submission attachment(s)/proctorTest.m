function [content, area] = proctorTest(file, maxPercent)
[nums, txt, ~] = xlsread(file);
[~, moistureUnits] = strtok(txt{1}, '(');
moistureUnits(1) = [];
moistureUnits(end) = [];
[~, weightUnits] = strtok(txt{2}, '(');
weightUnits(1) = [];
weightUnits(end) = [];
% this defines the units end gets the numbers
x = nums(:, 1);
y = nums(:, 2);
% this determines the x values and the y values
slope = diff(y) ./ diff(x);
derivX = x(1:end-1) + diff(x) ./ 2;
xVal = interp1(slope, derivX, 0, 'spline');
yVal = interp1(x, y, xVal, 'spline');
% this determines the x value nd y value of the max
horz = yVal .* maxPercent .* 0.01;
newY = y - horz;
mask = newY > 0;
area = trapz(x(mask), newY(mask));
area = round(area, 3);
% this determines the area under the curve
content = sprintf('%0.3f %s, %0.3f %s', xVal, moistureUnits, yVal, weightUnits);
end