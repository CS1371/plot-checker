function lift = airfoilz(attack, coeffs, liftAngle)
vals = polyfit(attack, coeffs, 2);
% this gets the values
x = min(attack) : max(attack);
y = polyval(vals, x);
plot(x, y, 'k-')
hold on;
plot(attack, coeffs, 'b*');
% this plots the line of best fit to the second degree
lift = interp1(x, y, liftAngle, 'spline');
lift = round(lift, 3);
end