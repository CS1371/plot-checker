function [string, area] = proctorTest (excel, percent)
[num, ~, raw] = xlsread(excel); %reads the excel sheet
moistunits = raw{1,1}(19:end-1); %finds the units of the moisture content
dryunits = raw{1, 2}(18:end-1); %finds the units of the dry content
xmoistvals = num(:,1)'; %makes a vector of the moisture values
ydryvals = num(:,2)'; %makes a vector of the dry values
x = xmoistvals; %renames xmoistvals to x
y = ydryvals; %renames ymoistvals to y
dy = diff(y)./diff(x); %finds the y derivative
dx = x(1:end-1)+(diff(x)./2); %finds the midpoint between each x
moistcont = spline(dy,dx,0); %finds the moisture content for where the slope equals 0, rounded to 3 places
dryweight = spline(x,y,moistcont); %finds the ground's dry unit weight for the above value
string = sprintf('%0.3f %s, %0.3f %s', moistcont, moistunits, dryweight, dryunits);%prints the string output
bottom = dryweight*.01*percent; %finds the minimum acceptabe dryweight value
mask = y>bottom; %makes a mask of the values above the minimum value
area = round(trapz(x(mask),y(mask)-bottom),3); %finds the area
end