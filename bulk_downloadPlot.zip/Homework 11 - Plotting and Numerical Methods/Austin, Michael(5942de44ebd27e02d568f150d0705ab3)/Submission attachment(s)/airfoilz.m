function liftcoeffatangle = airfoilz(aoa, coeff, tbd)
figure(1);
hold on;
minx = min(aoa);
maxx = max(aoa);
intpoints = minx:1:maxx;
polycoeff = polyfit(aoa, coeff, 2);
polyfitted = polyval(polycoeff, intpoints);
plot(intpoints, polyfitted, 'k');
plot(aoa, coeff, 'b*');
liftcoeffatangle = round(spline(intpoints, polyfitted, tbd),3);
end