function molecule (lengths, angles, rings)
angsum = cumsum(angles); %adds the angles
zvec = zeros(1,length(lengths)); %makes a vec of zeros
xpoints = [0 zvec]; %concats with a 0 to make a vec starting with the origin
ypoints = [0 zvec]; %as above but for y
for i = 1:length(lengths) 
    [xchange, ychange] = helper(lengths(i), angsum(i)); %calls the helper for each 0
    xpoints(i+1) = xpoints(i)+xchange; %finds the x point after the origin
    ypoints(i+1) = ypoints(i)+ychange; %finds the y points after the origin
end
figure(1); %sets up for plotting
hold on;
plot(xpoints, ypoints, 'k'); %plots the x and y points in black
[arr, radii]= findCenter([xpoints;ypoints]); %finds the center of the rings

if ~isempty(rings)
mask = rings >= 1; %masks for where we have rings
arr = arr(:,mask); %removes the rings we don't want to plot
[~, c] = size(arr); %finds the number of columns remaining
pos = 1:length(mask); %finds the length of the mask
pos2 = mask .* pos; %multiplies the items in the mask by their position number to determine which rings to get
for  q = length(pos2):-1:1
    if pos2(q)==0
        pos2(q) = []; %removes the 0 values from the mask
    end
end 
    
if c > 0
   for j = 1:length(pos2)
    x1 = arr(1,j); % finds the x values of the array
    y1 = arr(2,j); %finds the y values
    radius = 0.65 .* radii(pos2(1,j)); %multiplies the radius by .65
    x = cos(linspace(0,2*pi))*radius + x1; %moves the circles created by the x found x values from the array
    y = sin(linspace(0,2*pi))*radius + y1; %and y
    plot(x,y,'b'); %plots it
   end
end
end
axis equal;
axis off;
end


function [xchange, ychange] = helper (length,d)
arr = [cosd(d), -sind(d); sind(d), cosd(d)]*[length;0]; %finds the change in x and y using the cumulative sum of angles to this point
xchange = arr(1,1);
ychange = arr(2,1);
end