function str = wordDist(textfile)
fh1 = fopen(textfile); %opens the file
line = fgetl(fh1); %gets the first line
canread = true; %assumes we can read it until proven otherwise
containtech = false; %assumes it doesn't contain 'technology' until proven otherwise
vec = zeros(1,100); %creates a zero vector from 1:100
while ischar(line)
   [str, rem] = strtok(line) ; %gets the first word of the screen
    while ~isempty(str)
        mask = (str>='a' & str<='z') | (str>='A' & str<='Z'); %makes a mask of only the letters
        str = str(mask); %removes the nonletters from the word
        if strcmpi(str, 'technology')
            containtech = true; %if the word technology is the word, sets containtech to true
        end
        if length(str) >13
            canread = false; %if there is a word of more than thirteen characters, sets canread to false
        end
        if length(str) >0
        vec(length(str)) = vec(length(str))+1; %if string isn't empty, adds one to that value in the zeros vector
        end
        [str, rem] = strtok(rem); %gets the next word
    end
    
    line = fgetl(fh1); %gets the next line
end
fclose(fh1); %closes the word file
if containtech == true %if it contains 'technology', we can read it
    canread = true;
end

if canread == true  %outputs a str based on if we can read it
    str = 'We''re at Georgia Tech, we can read that!';
else
    str = 'We''re at Georgia Tech, we can''t read that :(';
end
veclast = false;  
for r = 100:-1:1 %goes through the vec to remove 0 values from 100 down until it finds a nonzero value
    if ~veclast
        if vec(r) == 0
            vec(r) = [];
        else
            veclast = true;
        end
    end
end
figure(1) 
bar(vec); %plots vec using a bar graph
text = textfile(1:end-4); %removes.txt from the text file
title(sprintf('Can we read %s?',text)); %titles
xlabel('Length of Word'); %labels x axis
ylabel('Number of Occurrences'); %labels y axis

end