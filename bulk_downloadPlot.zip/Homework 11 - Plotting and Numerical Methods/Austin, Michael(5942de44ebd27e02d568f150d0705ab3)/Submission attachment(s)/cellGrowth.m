function cellGrowth (count, time)
figure(1)
hold on;
plot(time, count, 'r.');
leng = length(count);
countmean(1:leng) = mean(count);
countmax(1:leng) = max(count);
plot(time, countmean, 'b-.');
plot(time, countmax, 'm--');
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
fivepercentx = max(time)*.05;
fivepercenty = max(count)*.05;
x = time;
y = count;
axis([min(x)-fivepercentx, max(x)+fivepercentx, min(y)-fivepercenty, max(y)+fivepercenty]);
end