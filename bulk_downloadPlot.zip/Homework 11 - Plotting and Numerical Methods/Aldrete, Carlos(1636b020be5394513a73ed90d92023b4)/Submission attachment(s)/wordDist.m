function str = wordDist(file)
fh = fopen(file);
filename = file(1:end-4);
line = fgetl(fh);


tech = 1;
lengthvec = [];
while ischar(line)
    charline = line((line>= 'a' & line<= 'z')|line>='A' & line<= 'Z'| line == ' ');
    spaces = length(strfind(charline,' '));
    for i = 1:spaces + 1
        [tok,charline] = strtok(charline,' ');
        wlength = length(tok);
        if strcmpi(tok,'technology')
            tech = 2;
        end
        lengthvec = [lengthvec wlength];   
    end
    line = fgetl(fh);
end

[long, ~] = max(lengthvec);
totalvec = zeros(1,long);

for i = 1:length(lengthvec)
    index = lengthvec(i);
    if index ~= 0
        totalvec(index) = totalvec(index)+1;
    end
end

if tech == 2 || long <= 13
    str = 'We''re at Georgia Tech, we can read that!';
else
    str = 'We''re at Georgia Tech, we can''t read that :(';
end
bar(totalvec);
xlabel('Length of Word');
ylabel('Number of Occurrences');
title(sprintf('Can we read %s?',filename));

end