function cellGrowth(count,time)
figure(1);
hold on
plot(time,count,'r.') % first plot

timelength = length(time)
meanpop = mean(count)
maxpop = max(count)
meanvec = ones(1,timelength)
maxvec = ones(1,timelength)

meanvec(meanvec == 1) = meanpop
maxvec(maxvec == 1) = maxpop

plot(time,meanvec,'b-.') % mean plot
plot(time,maxvec,'m--') %max plot

maxtime = max(time)
mintime = min(time)
minpop = min(count)

axis([mintime-maxtime*0.05,maxtime+maxtime*0.05,minpop-maxpop*0.05,maxpop+maxpop*0.05])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end

