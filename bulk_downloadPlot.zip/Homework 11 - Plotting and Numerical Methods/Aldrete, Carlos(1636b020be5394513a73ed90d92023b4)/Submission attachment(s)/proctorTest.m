function [p,a] = proctorTest(file,percent)
[~,~,raw]= xlsread(file);
[rows,~] = size(raw);
% this finds the units
moistcol = raw{1,1} ;
drycol = raw{1,2};
moistindex = strfind(moistcol,'(');
dryindex = strfind(drycol,'(');
moistunit = moistcol(moistindex+1:end-1); %x-unit
dryunit = drycol(dryindex+1:end-1); %y-unit

moistvals = [];
dryvals = [];

for i = 1:2
    for j = 2:rows
        val = raw{j,i};
        if i == 1
            moistvals = [moistvals val]; %x vector
        else
            dryvals = [dryvals val]; % y vector
        end
    end
end

derivY = diff(dryvals); %one length less than dryvals
derivX = moistvals(1:end-1)+(diff(moistvals)/2);
derivY = derivY./diff(moistvals);
maxX = interp1(derivY,derivX,0,'spline'); % max dry unit weight
maxY = interp1(moistvals,dryvals,maxX,'spline');

p = sprintf('%0.3f %s, %0.3f %s',maxX,moistunit,maxY,dryunit);

line = maxY*(percent/100);
dryvals = dryvals - line;
area = trapz(moistvals,dryvals);

a = round(area,3);
end