function lift = airfoilz(attack,lift,angles)
coeffvec = polyfit(attack,lift,2);
amin = min(attack);
amax = max(attack);
newX = amin:amax;
newY = polyval(coeffvec,newX);

plot(newX,newY,'k-')
hold on
plot(attack,lift,'b*')

lift = interp1(newX,newY,angles,'spline');
lift = round(lift,3);
end