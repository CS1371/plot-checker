function molecule( in1, in2, in3)
% Inputs:- 1. (double) A vector containing the lengths of each consecutive line segment of the continuous molecule chain
         % 2. (double) A vector containing the counterclockwise angles between each consecutive line segment and its previous line segment of the continuous molecule chain
         % 3. (logical)A vector specifying which hexane rings to place circles within; will be an empty vector if molecule contains no hexane rings
         
% Plot Output:- 1. The plotted molecule

vec = [0];
% Creating a vector with an initial value of 0
vec1 = [0];
% Creating a vector with an initial value of 0
ang = cumsum(in2);
% Using cumsum to add each angle to the previous angle
for i = 1:length(in1); 
x = in1(i)*cosd(ang(i)) + vec(end); % calculating the x values with the rotated 
% angles and adding the last number of the xvector to allow the last value 
% of the vector to be the initial value for each point
y = in1(i)*sind(ang(i)) + vec1(end);
% % calculating the y values with the rotated angles and adding the 
%last number of the y vector to allow the last value of the vector to be the
% initial value for each point
vec = [vec x]; % Creating a vector of the calculated x values
vec1 = [vec1 y]; % Creating a vector of the calculated y values
end

plot(vec, vec1, 'k-')
% Plotting the x values and the y values as black line
hold on
axis equal
axis off


[L,S] = findCenter([vec;vec1]);
% obtaining the center location values and the hexagon Sizes (radii)
hello = S(in3);
% Obtaining the radii that need a circle within the hexagon
hello1 = L(:,in3);
% Obtaining the center location values that need a circle within the hexagon

th = linspace(0,360);
% Creating 100 placed vector through linspace

for ih3 = 1:length(hello)
    r = hello(ih3) .* .65;
     x2 = r * cosd(th) + hello1(1,ih3);
     y2 = r * sind(th) + hello1(2,ih3);
     plot(x2, y2, 'b')
end 

% Completing a for loop with the length of the x values (same length x and y)
%and  multiplying the radius of the hexagon by 65% to obtain the radius of the circle. 
% Within the loop we are calculating the yvalues and the xvalues and adding 
% the shift to take into account the accurate position of each x and y.
% Then it is plotting the values on the graph to get the circle.


end 