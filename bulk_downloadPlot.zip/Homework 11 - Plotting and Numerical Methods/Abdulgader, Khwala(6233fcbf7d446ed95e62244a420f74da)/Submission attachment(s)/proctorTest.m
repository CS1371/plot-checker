function [str, area] = proctorTest(name, per)
% Inputs:- 1. (char)?The name of an Excel file filled with Proctor Test data points
         % 2. (double) T?he ?percentile of Standard Proctor?, a percent of the maximum Dry Unit Weight
% Outputs:- 1. (char)?A string containing the optimal water content and maximum dry unit weight
          % 2. (double) T?he area beneath the curve above the percentile of Standard Proctor
          
[num txt raw] = xlsread(name);
% Reading through the file
[A,B] = strtok( txt{1,1}, '(');
% strtok to find the units for the maximum content 
[K, L] = strtok(txt{1,2} , '(');
% strtok to find the units for the maximum dry unit weight
Units1 = B(2:end-1);
% Removing the first and last character to obtain the correct units
Units2 = L(2:end-1);
% Removing the first and last character to obtain the correct units
P = diff(num(:,1)');
H = diff(num(:,2)');
U = H./P;
% Numerically differentiating the data

xv= num(:,1)';
% obtaining the x values
yv = num(:,2)';
% obtaining the y values
count = [];

J = length(xv);
% Finding the length of the x values
io = J -1;
% subtracting the length by 1
for i = 1:io
    in = xv(i) + xv(i+1);
    in1 = in./2;
    count = [ count in1];
end
% Using a for loop to obtain the midpoint of the x values and putting that
% into a vector
 v = spline(U, count, 0);
 % Using spline to obtain the moisture content
 yui = spline(xv,yv, v);
 % Using sline to obtain the max dry unit 
 GA = yui.* (per./100);
% multiplying the max dry unit by the percentile of standard proctor
 
 
 if any(GA <= yv) 
     kiy = yv - GA;
 end 
 % Completing an if statement to determine if there are any values that are
 % greater than than percentile multiplyed with the percentile of standard
 % proctor

ktap= find( kiy >= 0);
% finding the index of the values that are greater than zero
hey = kiy(ktap);
% obtaining the y values that are greater than 0
hi = xv(ktap);
% obtaining the x values that correspond to those y values
but = trapz(hi, hey);
% Completing the integral of those values to obtain the area beneath the
% curve but above the percentile of standard protocol
area = round(but,3);
% outputing the area value rounded to 3 decimals
str = sprintf(' %0.3f %s, %0.3f %s', v, Units1,yui, Units2); 
% outputing a string that contains the optimal water content and the
% maximum dry unit weight with the corresponding units
end