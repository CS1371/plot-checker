function cellGrowth(count,time)

% Inputs:- 1. (double)A vector of cell counts
         % 2. (double)A vector of time points
% Outputs:(none)

% Plot Outputs:- 1. A plot of cell growth vs time
hold off
hold on

plot(time,count, 'r.')
% A plot of the cell growth vs time
A = length(time);
% Finding the length of the vector to complete a for loop
T = [];
for i=1:A
    J = mean(count,2);
    T = [T J]; 
end
% Completing a for loop to obtain the mean vector
plot(time,T, 'b--')
% Plotting the collected data vs time in a blue color with dashed lines
Y = [];
for Z=1:A
    L = max(count);
    Y = [Y L] ;
end
% Doing another for loop to obtain the maximum vector
plot(time,Y, 'm--')
% Plotting the collected data vs time in a magenta color with dashed lines
Ti = min(time); 
Tl = max(time);
Tp = min(count);
Tk = max(count);
% Finding the maximum and miniumums of the count and time vector
label1 =  Ti - Tl.* .05 ;
label2 = Tl.* .05 + Tl ;
label3 = Tp - Tk.* .05 ;
label4 = Tk.* .05 + Tk;
% Using the maximum and minimums to calculate the axes range (plus or minus
% 5%)


axis([label1 label2 label3 label4])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
% labeling the axes and labeling the graph with a title and the correct
% axes labels

end 