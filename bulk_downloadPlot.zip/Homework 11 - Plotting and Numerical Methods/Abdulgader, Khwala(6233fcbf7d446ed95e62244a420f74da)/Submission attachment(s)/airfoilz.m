function [finalangle] = airfoilz(att, lift, ang)
% Inputs:- 1. (double) A vector of angles of attack (will always be integers)
         % 2. (double) A vector of lift coefficients
         % 3. (double) A vector of angles at which to determine the lift coefficient value
% Outputs:- 1. (double) Lift coefficient at the specified angle 

% Plot Outputs: 1. Lift coefficient as a function of the angle of attack

plot(att,lift, 'b*')
%plotting the angles of attack vs the lift coefficients with blue stars
coeff = polyfit(att,lift, 2); 
% Creating a 2nd degree polynomial with the angles of attack and lift
% coeffcients
K = length(att);
% Finding the length of the angles of attack
A = min(att):max(att);
% Creating a vector from the min angle of attack to the max angle of attack
Y = polyval(coeff, A);
% polynomial evaluation using the coeffcients obtained with the vector from
% the min to the max value (integers)


hold on
plot(A, Y, 'k-') 
% plotting the vectors of the min and max with the polynomial evaluation
% values with a black line
U = spline(A,Y, ang);
% Using spline to calculate the lift coeffcient at the specified angle (ang
% input)
finalangle= round(U,3);
% Rounding the final answer by 3
end