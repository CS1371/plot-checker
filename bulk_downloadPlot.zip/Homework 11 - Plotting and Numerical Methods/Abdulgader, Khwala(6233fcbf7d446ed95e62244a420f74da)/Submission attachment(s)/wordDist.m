function str = wordDist(in)
% Inputs:- 1. (char)A string containing the name of a text file (with .txt extension) 

% Outputs:- 1. (char)A string specifying if the text is at our reading level or not 

% Plot Output:-1. A histogram displaying the frequency of words of different l
fh1 = fopen(in, 'r');
% opening the text file 
fline = fgetl(fh1) ;
% Obtaining the first line of the read file
 
count = [];
while ischar(fline) 
 
    while ~isempty(fline)
% Determining if the line is not empty
        [A B] = strtok(fline, ' ');
        % Obtaining the each word of the line through strtok
        A = A((A >=  'A' & A <= 'Z') |(A >= 'a' & A <='z'));
        % Only obtaining the capital and lower case letters
        
        if strcmpi(A, 'technology')
            str = 'We''re at Georgia Tech, we can read that!';
           % Comparing the words with tecnology to output the corresponding
           % string
        elseif length(A) <= 13
                
                str = 'We''re at Georgia Tech, we can read that!';
                % Determining if the length of the words are greater than 13
                % and if so then outputing the corresponding string
        else 
                str = 'We''re at Georgia Tech, we can''t read that :(';
           
            % If the string is not the word technology or greater than 13
            % letters than it should output the corresponding string
        end
        
        Ki = length(A);
        % Determing the length of the word
        count = [count Ki];
        % Creating a vector of the length of the words
        fline = B ;
    end 
    fline = fgetl(fh1) ;
end
zi = count > 0; 
% Determining if the vector inputs are greater than zero
count = count(zi);
% outputing only the words that are greater than zero
xv = []; 
yv = [];

hey = min(count);
% Obtaining the min letter value
hello = max(count);
% obtaining the max letter value

for ih = hey:hello
    kr = count == ih;
    kr = count(kr);
    % indexing were the vector equals the count and the ih
    kr = length(kr);
    % obtaining the length of the vector
    if kr ~= 0 %just in case an i value isn't in the lengths
        xv = [xv ih];
        % creating a vector of y values with the letter count
        yv = [yv kr];
        % creating a vector with the number of occurances of the same
        % letter count
    end 
end 

figure(2)
bar(xv, yv)
% Creating a bar graph with the x and y values 
P = in(1:end-4);
% Obtaining the title of the graph
tip = sprintf('Can we read %s?', P);
% Creating a string of the graph title

title(tip)
xlabel('Length of Word')
ylabel('Number of Occurrences')
% Labeling the axes and the title 

fclose(fh1);
% Closing the text file 

end