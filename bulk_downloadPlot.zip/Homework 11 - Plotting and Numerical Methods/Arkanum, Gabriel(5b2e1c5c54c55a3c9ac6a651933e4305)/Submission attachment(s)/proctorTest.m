function [str, area] = proctorTest(file, percentile)

[nums txt raw] = xlsread(file); % read file
moistureValues = nums(:,1); % get the moisture values
unitWeightValues = nums(:,2); % get the unit weight values
xUnits = txt{1,1}(strfind(txt{1,1},'(')+1:strfind(txt{1,1},')')-1); % get the units for the moisture values
yUnits = txt{1,2}(strfind(txt{1,2},'(')+1:strfind(txt{1,2},')')-1); % get the units for the unit weights

x = [];
for i = 2:1:length(moistureValues) % find all the midpoints for the moisture values
    x(i-1) = (moistureValues(i) + moistureValues(i-1))/2;
end

x = x';
xDeriv = diff(moistureValues); 
yDeriv = diff(unitWeightValues);
dydx = yDeriv ./ xDeriv;

maxMoistureContent = interp1(dydx, x, 0, 'spline'); % find the maximum moisture content
maxUnitWeight = interp1(moistureValues, unitWeightValues, maxMoistureContent, 'spline'); % find the maximum unit weight

msg = '%0.3f %s, %0.3f %s';
str = sprintf(msg, maxMoistureContent, xUnits, maxUnitWeight, yUnits); % output the maximum string

weightPercentile = (percentile/100) * maxUnitWeight; % find the unit weight at the given percentile
adjustedWeights = unitWeightValues - weightPercentile; % adjust the weights according to the percentile so the
area = round(trapz(moistureValues, adjustedWeights),3); % find the area under the curve


end