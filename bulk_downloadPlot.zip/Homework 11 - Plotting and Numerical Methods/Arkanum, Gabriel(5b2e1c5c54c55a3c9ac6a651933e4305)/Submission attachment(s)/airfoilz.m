function liftCoeff = airfoilz(attackAngles, coefficients, angles)

polynomial = polyfit(attackAngles, coefficients, 2); % find the polynomial for the data
xValues = min(attackAngles):1:max(attackAngles); % determine the appropriate x values
polyPoints = polyval(polynomial, xValues); % get the actual points for the polynomial at each x
figure
hold on
plot(xValues, polyPoints, 'k-'); % plot the polynomial values
plot(attackAngles, coefficients, 'b*'); % plot the original data

liftCoeff = interp1(xValues,polyPoints,angles,'spline'); % determine lift coefficients for the angles provided
liftCoeff = round(liftCoeff,3); % round to thousandths

end