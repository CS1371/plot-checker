function readingLvl = wordDist(filename)

wordLengths = zeros(1,50); % create a vector of zeros to hold word counts, longest word in english is 45 letters
techFound = false; % flag for the word 'technology'

fid = fopen(filename, 'r'); % open the file
line = fgetl(fid);

while ischar(line)
    line = regexprep(line,'[^a-zA-Z ]',''); % keep only letters and spaces
    done = false;
    [word remain] = strtok(line); % perform the initialize strtok so the loop works correctly
    len = length(word);
    if len > 0 % make sure there actually is a word
        wordLengths(len) = wordLengths(len) + 1;
    end
    while done == false % checks to see if this flag is set
        [word remain] = strtok(remain); % get the word
        len = length(strtrim(word)); % find its length
        if len > 0 % make sure it has a length
            wordLengths(len) = wordLengths(len) + 1;
        end
        if strcmpi(word, 'technology') % check if the word is technology and flip the flag if it is
            techFound = true;
        end
        if isempty(remain) % if there is nothing in remain then flip the flag so that the loop can exit
            done = true;
        end
    end
    line = fgetl(fid);
end

maxInd = max(find(wordLengths~=0)); % find the last spot where there is a nonzero number
wordLengths = wordLengths(1:maxInd); % chop all the zeros off the end of the vector

if maxInd <= 13 || techFound % if there are no words longer than 13 or the word technology is found then we can read it
    readingLvl = sprintf('We''re at Georgia Tech, we can read that!');
else % if not, then we cant
    readingLvl = sprintf('We''re at Georgia Tech, we can''t read that :(');
end

bar(wordLengths); % create the bar graph
xlabel('Length of Word');
ylabel('Number of Occurrences');
fileTitle = filename(1:end-4);
title(['Can we read ' fileTitle '?']);

end