function molecule(segments, angles, rings)

x = zeros(1,length(segments) + 1); % create vector to hold the x values
y = zeros(1,length(segments) + 1); % create vector hold the y values
x(1) = 0; % set initial x and y to the origin
y(1) = 0;

for i = 2:1:length(x) % loop through and calculate each point need to plot the molecule
    sumAngles = sum(angles(1:i-1)); % find the sum of all the angles up to the current point, an easy way of making sure the line is oriented correctly
    xPoint = segments(i-1)*cosd(sumAngles); % find the x point
    yPoint = segments(i-1)*sind(sumAngles); % find the y point
    x(i) = x(i-1) + xPoint; % add to the previous point and put this new value in the next index 
    y(i) = y(i-1) + yPoint;
end

figure
hold on
plot(x,y,'k') % plot the x and y values for the molecule as black
axis square
axis off

allPoints = [x; y]; % create an array of both the x and y values
[centers, sizes] = findCenter(allPoints); % find the centers and the radii of each hexane ring

for i = 1:1:length(sizes) % this loop plots all the circles
    if rings(i) % if this ring should be plotted go ahead and plot it
        a = 0:(2*pi)/99:2*pi; % find all the angles (in radians) for the circle (100 values)
        xCircle = (sizes(i)*.65)*cos(a); % get the x
        yCircle = (sizes(i)*.65)*sin(a); % ...and y coordinates for each point on the circle
        plot(xCircle + centers(1,i),yCircle + centers(2,i),'b'); % plot the circle in blue
    end
end

end