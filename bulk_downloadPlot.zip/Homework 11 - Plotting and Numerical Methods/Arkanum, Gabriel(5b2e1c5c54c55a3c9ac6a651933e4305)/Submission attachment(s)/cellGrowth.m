function cellGrowth(cells, times)

cellsAvg = mean(cells); % get the mean population value
cellsMax = max(cells); % get the max population value

figure
hold on % allows multiple plots on top of each other
plot(times,cells,'r.',times,cellsAvg*ones(size(times)),'b-.',times,cellsMax*ones(size(times)),'m--'); % plot three lines; cell vs time, cell average vs time, cell max vs time

% determines the x axis values
xmin = min(times); 
xmax = max(times);
xrange = (xmax - xmin) *.05;
xmin = xmin - xrange;
xmax = xmax + xrange;

% determines the y axis values
ymin = min(cells);
ymax = max(cells);
yrange = (ymax - ymin) *.05;
ymin = ymin - yrange;
ymax = ymax + yrange;

title('Cell Growth vs Time'); % assign a title
axis square % make the plot square
axis([xmin xmax ymin ymax]) % define the axis ranges
xlabel('Time'); % label the x axis
ylabel('# Cells'); % label the y axis

end