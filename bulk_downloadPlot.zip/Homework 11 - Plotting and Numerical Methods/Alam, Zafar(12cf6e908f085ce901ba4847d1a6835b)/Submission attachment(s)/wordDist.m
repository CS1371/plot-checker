function [understandable] = wordDist(input)
fh = fopen(input);
line = fgetl(fh);
temp = 0;
r =0;
vec = []
while ischar(line)
    
    remaining = line;
    temp = line;
    while ~isempty(remaining)
        [word, remaining] = strtok(remaining);
        
     if ~isempty(word)   
        onlyletters = isletter(word);
        word = word(onlyletters);
       
         if length(word)>length(vec)
             vec(length(word))=0;
         end
         if(~isempty(word))
             vec(length(word))= vec(length(word))+1;
         end 
    end  
       
       if length(word)>14
            
            hi = word;
            r = 100
        end
        if strcmpi(word, 'technology')
            temp=100
        end
        
        
    end
    line = fgetl(fh);
    
end

if temp==100
    understandable = 'We''re at Georgia Tech, we can read that!';
elseif r == 100
    understandable = 'We''re at Georgia Tech, we can''t read that :(';
else
    understandable=  'We''re at Georgia Tech, we can read that!';
end
x = []
for a = 1:length(vec)
    x = [x a]
end
bar(1:length(vec),vec);
tit=  sprintf('Can we read %s?', input(1:end-4));
title(tit);
xlabel('Length of Word')
ylabel('Number of Occurrences')
end
