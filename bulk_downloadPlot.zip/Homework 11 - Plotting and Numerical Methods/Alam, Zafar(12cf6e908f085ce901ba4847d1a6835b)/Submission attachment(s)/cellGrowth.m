function cellGrowth(cellcountvec, ptsvec)

average = mean(cellcountvec)*ones(1,length(ptsvec));
big = max(cellcountvec)*ones(1,length(ptsvec));
minx = min(ptsvec)- (max(ptsvec)*0.05);
maxx = max(ptsvec)+ (max(ptsvec)*0.05);
miny = min(cellcountvec)- (max(cellcountvec)*0.05);
maxy = max(cellcountvec)+ (max(cellcountvec)*0.05);

figure(1);
plot(ptsvec, cellcountvec, 'r.');

hold on
plot(ptsvec, average, 'b-.');

hold on
plot(ptsvec, big, 'm--');

axis([minx, maxx, miny, maxy]);
axis square
title('Cell Growth vs Time');

xlabel('Time')
ylabel('# Cells')

end
