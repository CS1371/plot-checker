function liftcoeff = airfoilz(attackanglevec, coefflift, angletodetermine)

plot(attackanglevec, coefflift, 'b*');

hold on
coef = polyfit(attackanglevec, coefflift, 2);
a = [min(attackanglevec)];
b = min(attackanglevec);

for len = min(attackanglevec):max(attackanglevec)-1
    b = b+1;
    b = [a, b];
    
end 

yvalues = polyval(coef, b);
plot(b,yvalues, 'k-')
liftcoeff = round(polyval(coef, angletodetermine), 3);



end
