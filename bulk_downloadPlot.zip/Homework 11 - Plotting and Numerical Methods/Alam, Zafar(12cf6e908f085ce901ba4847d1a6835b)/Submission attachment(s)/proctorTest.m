function [optimalmax, area] = proctorTest(file, perc)
[num txt str] = xlsread(file);
[r,~] = size(num);
x = num(1:r);
y = num(r+1:end);

derivative = diff(y)./diff(x)
newx = []

for a =1:length(x)
    if a ==1
        prev = x(a)
    else
        newx = [newx mean([prev, x(a)])]
        prev = x(a)
    end
           
    
end

xbig = interp1(derivative, newx, 0, 'spline')
big = interp1(x,y, xbig, 'spline')

first = txt{1};
[~, rem] = strtok(first, '(');
thing = rem(2:end-1);

first =txt{2};
[~, rem] = strtok(first, '(');
thing2 = rem(2:end-1);

optimalmax= sprintf('%.03f %s, %.03f %s', xbig, thing, big, thing2)

ending  =big*perc*.01
y = y-ending
area = sum(trapz(x, y))


end
