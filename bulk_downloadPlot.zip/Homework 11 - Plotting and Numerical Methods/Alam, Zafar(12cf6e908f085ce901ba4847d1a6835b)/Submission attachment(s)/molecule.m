function [] = molecule(lengths, ccangles, hexanevec)

averageangle = 0
prev = [0;0]
points = [0;0]

hold on

for e = 1:length(lengths)
    averageangle = averageangle + ccangles(e)
    rotatematrix = [cosd(averageangle) - sind(averageangle); 
        sind(averageangle) cosd(averageangle)]
    
    line = [lengths(e);0]
    line = line*rotatematrix
    line = prev+line
    
    plot([prev(1), line(1)], [prev(2),line(2)], 'k')
    points= [points, line]
    prev = line
    
end

[middle, hexagon] = findCenter(points)

for e = 1:length(hexanevec)
    if hexanevec(e)
        theta = linspace(0, 2*pi)
        x = cos(theta)*0.65*hexagon(e)
        y = sin(theta)*0.65*hexagon(e)
        plot(middle(1,e)+x, middle(2,e)+y, 'b')
    end
end

axis equal
axis off

end