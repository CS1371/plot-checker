function molecule(lengths, angles, loc)
    pts = [0;0];
    last = [0;0];
    hold on
    new = cumsum(angles);
    for i = 1:length(lengths)
        pt = [lengths(i);0];
        rotation = [cosd(new(i)), -sind(new(i)); sind(new(i)), cosd(new(i))];
        pt = rotation*pt;
        pt = pt + last;
        last = pt;
        pts = [pts,last];
    end
    x = pts(1,:);
    y = pts(2,:);
    plot(x,y,'k');
    axis off
    axis equal
    vec = linspace(0,2*pi);
    [center, size] = findCenter(pts);
    center = center(:,loc);
    [~,col] = size(center);
    for i = 1:col
        xx = .65*size(i)*cos(vec);
        yy = .65*size(i)*sin(vec);
        xx = center(1,i) + xx;
        yy = center(2,i) + yy;
        plot(xx,yy,'b');
    end
end 