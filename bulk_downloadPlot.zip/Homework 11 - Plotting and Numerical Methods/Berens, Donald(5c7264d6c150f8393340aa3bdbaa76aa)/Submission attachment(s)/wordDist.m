function [level] = wordDist(txtName)
    fileID = fopen(txtName);
    line = fgetl(fileID);
    vecL = [];
    tech = false; 
    while ischar(line)
        while ~isempty(line)
            if strcmpi(line,'technology')
                tech = true; 
            end
            mask = line >= 'a' & line <= 'z' | line >= 'A' & line <= 'Z' | line==' ';
            line(~mask) = []; 
            [word,rest] = strtok(line); 
            num = length(word); 
            vecL = [vecL, num]; 
            rest = rest(2:end);
            line = rest;
        end
        line = fgetl(fileID);
    end
    sortLength = sort(vecL); 
    sortLength(end+1) = 0; 
    maxLength = max(sortLength);
    times = [];
    count = 0;
    for i = 1:maxLength
        j = 1;
        while isequal(i,sortLength(j))
            count = count + 1;
            j = j+1;
        end
        sortLength(1:count) = [];
        times = [times count];
        count = 0;  
    end
    if maxLength <= 13
        tech = true;
    end
    if tech==true
        level = 'We''re at Georgia Tech, we can read that!';
    else
        level = 'We''re at Georgia Tech, we can''t read that :(';
    end
    vecL = 1:maxLength; 
    bar(vecL,times)
    filename = txtName(1:end-4);
    title(sprintf('Can we read %s?',filename));
    xlabel('Length of Word');
    ylabel('Number of Occurrences');
end
