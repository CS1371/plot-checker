function cellGrowth (cells, time)
    subplot(1,1,1);
    hold on
    plot(time, cells, 'r.');
    avg = mean(cells);
    a = linspace(min(time), max(time), avg);
    plot(time, avg, 'b.');
    maximum = max(cells);
    plot(time, maximum, 'm.');
    axis square;
    title('Cell Growth vs Time');
    xlabel('Time');
    ylabel('# Cells');
end