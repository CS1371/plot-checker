function [specC] = airfoilz (anglesAtt, liftCoeff, anglesDet)
    subplot(1,1,1);
    hold on
    little = min(anglesAtt);
    big = max(anglesAtt);
    p = polyfit([anglesAtt], [liftCoeff], 2);
    l = linspace(little, big, length(anglesAtt));
    i = polyval (p,l);
    plot([anglesAtt], [liftCoeff], 'b*', l, i, 'k');
    specC = round(interp1(l, i, anglesDet, 'spline'),3); 
    hold off
end