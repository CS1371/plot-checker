function [optimal, area] = proctorTest(excel, pct)
    [num,txt,raw] = xlsread(excel);
    subplot(1,1,1);
    hold on;
    x = num(:,1)';
    y = num(:,2)';
    plot(x,y);
    ind1 = strfind(txt{1},'(');
    unit = txt{1}(ind1+1:end-1);
    ind2 = strfind(txt{2},'(');
    sah = txt{2}(ind2+1:end-1);
    dy = diff(y);
    dx = diff(x);
    deriv = dy ./ dx;
    derivX = x(1:end-1) + .5 .* dx;
    max1 = spline(deriv, derivX, 0);
    max2 = spline(x,y,max1);   
    optimal = sprintf('%0.3f %s, %0.3f %s',max1,unit,max2,sah);
    limit = max2 .* (pct/100);
    y = y - limit;
    pos = y >= 0;
    area = round(trapz(x(pos),y(pos)),3);
end