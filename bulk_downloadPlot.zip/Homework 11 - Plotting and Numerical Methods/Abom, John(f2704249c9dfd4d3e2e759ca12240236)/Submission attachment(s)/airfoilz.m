function lift = airfoilz(attack, coeff, ang)

    graph = polyfit(attack, coeff, 2);

    maX = max(attack); % find maximum of attack angles
    miX = min(attack); % find minimum of attack angles

    xinitial = linspace(miX,maX); % gather 100 evenly spaced numbers between min/max
    eq = polyval(graph, xinitial);

    plot(attack, coeff, 'b*');
    hold on;
    plot(xinitial, eq, 'k-');

    lift = interp1(xinitial, eq, ang,'spline','extrap');
    
    lift = round(lift, 3);

end

