function output = wordDist(fname)

    fh = fopen(fname,'r');
    lin = fgetl(fh);
    
    vector = [];
    count = 0;
    
    
    while ischar(lin)
        a = 0;
        
        jack = lin==32 | (lin>=97 & lin<=122) | (lin>= 65 & lin<=90) ;
        nLine = lin(jack);
        
        [token remain] = strtok(nLine);
        
        
        while length(remain) > 0
            counter = 0;
            
            if a == 0
                
                if strcmpi(token,'technology')
                    count = count + 1;
                end
                    value = length(token);
                    vector = [vector value];
            end
            
            a = a + 1;
            
            [token remain] = strtok(remain);
            
        if strcmpi(token,'technology')
                count = count + 1;
        end
        
        value = length(token);
        
        vector = [vector value];
        end
    
    lin = fgetl(fh);
end
    begin = 1;
    
    large = max(vector);
        if count>0

            output = 'We''re at Georgia Tech, we can read that!';
        elseif (large <= 13)

            output = 'We''re at Georgia Tech, we can read that!';
        else

            output = 'We''re at Georgia Tech, we can''t read that :(';
            begin = 2;
        end
        
    vecx = [];  
    vecnew = ones(1, max(vector));
    
    maxx = max(vector);
    
    for i = 1:maxx
        
        jack1 = vector == i;
        vecx = [vecx i];
        
        yvector = vector(jack1);
        vecnew(i) = length(yvector);
    end
    
    % Print the bar graph
    bar(vecx,vecnew);
    
    hold on;
    [token1, ~] = strtok(fname, '.');
    
    ylabel('Number of Occurences');
    titt = sprintf('Can we read %s?',token1);

    xlabel('Length of Word');
    
    title(titt);
end