function cellGrowth(cvec, tvec)

   
    avgvec = [];
    maxvec = [];
   
    for i = 1:length(tvec)
        avg = mean(cvec);
        avgvec = [avgvec, avg];
    end
    
    for x = 1:length(tvec)
        maxpop = max(cvec);
        maxvec = [maxvec, maxpop];
    end
    
    maY = max(cvec);
    miY = min(cvec);
    rY = (maY - miY);
    rY = rY * .05;
    
    ymax = maY+rY;
    ymin = miY-rY;
   
    maX = max(tvec);
    miX= min(tvec);
    rX = (maX - miX);
    rX = rX * .05;
    
    xmax = maX+rX;
    xmin = miX-rX;
  
    axis square;
    
    plot(tvec, cvec, 'r.')
    hold on;
    plot(tvec, avgvec, 'b-.')
    plot(tvec, maxvec, 'm--')
    
    axis([xmin xmax ymin ymax]);
    
    title('Cell Growth vs Time');
    ylabel('# Cells');
    xlabel('Time');
    
end



