function [string, trunc] = proctorTest(file, percent) % jack

    [num, txt, A] = xlsread(file);
    
    mc = A(:,1);
    du = A(:,2);
    
    % Find the Units in the excel file
    [~, remain] = strtok(mc{1},'(');
    remain(end) = [];
    remain(1) = [];
    
    mUnit = remain;

    [~, remain1] = strtok(du{1},'(');
    remain1(1) = [];
    remain1(end) = [];
    dUnit = remain1;
    
    
    dNum = num(:,2);
    mNum = num(:,1);
    diffDry = diff(dNum);
    vector = [];
    
    len = length(mNum)-1;
    
    % create vector of 
    for i = 1:len
        
        xuno = mNum(i);
        xdos = mNum(i+1);
        duffy = abs(xdos-xuno) ./ 2;
        midpoint = xuno + duffy;
        vector = [vector; midpoint];
        
    end
    
    diffMois = diff(mNum);
    dvY = diffDry ./ diffMois;
    
    graph = interp1(dvY,vector, 0,'spline','extrap');
    g2 = spline(mNum, dNum, graph);
    
    percent = percent ./ 100;
    l = g2 * percent;

    newD = dNum - l;
    % mask to see if the new dry unit is above zero
    jack = newD >= 0;
    
    newM = mNum(jack);
    newD = newD(jack);

    
    under = trapz(newM, newD);
    trunc = round(under, 3);
    
    % print final string
    string = sprintf('%0.3f %s, %0.3f %s', graph, mUnit, g2, dUnit);
    
end