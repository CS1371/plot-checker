function molecule(sideL, angles, ifCircle)
    point = [0,0];
    nPt = rotate([point(1)+sideL(1) point(2)],angles(1));
    x = [point(1),nPt(1)];
    y = [point(2),nPt(2)];
    j = [x;y];
    jangle = angles(1);
    plot(x,y,'k')
    hold on
    for n = 2:length(sideL)
        x = x(2);
        y = y(2);
        jangle = jangle + angles(n);
        nPt = rotate([point(1)+sideL(n) point(2)], jangle);
        x = [x, nPt(1)+x];
        y = [y, nPt(2)+y];
        j = [j [x(2);y(2)]]; 
        plot(x,y,'k')
    end
    [centers, radii] = findCenter(j);
    circNums = [centers(:,ifCircle); radii(:,ifCircle)];
    for t = 1:sum(ifCircle)
        theta = linspace(0,2*pi);
        y = (circNums(3,t).*sin(theta).*0.65) + circNums(2,t);
        x = (circNums(3,t).*cos(theta).*0.65) + circNums(1,t);
        plot(x,y,'b');
    end
    axis off
    axis square
end

function vec = rotate(point, angle)
    angle = deg2rad(angle);
    vec = [cos(angle) -sin(angle)
        sin(angle) cos(angle)] * point';
end