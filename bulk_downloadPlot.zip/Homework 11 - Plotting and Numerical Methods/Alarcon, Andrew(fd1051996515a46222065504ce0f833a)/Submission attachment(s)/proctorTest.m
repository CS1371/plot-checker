function [optWeight, geronimo] = proctorTest(dataPts, percStand)
    [dataSet,titles,~] = xlsread(dataPts);
    titles = titles(1,:);
    moistureCont = dataSet(:,1)';
    dryUW = dataSet(:,2)';
    dDryUW = diff(dryUW);
    dMoistureCont = diff(moistureCont);
    dDdM = dDryUW./dMoistureCont;
    shortX = moistureCont(1:end-1)+(dMoistureCont(1:end)/2);
    moistureLvl = interp1(dDdM,shortX,0,'spline');
    maxDryWeight = interp1(moistureCont,dryUW,moistureLvl,'spline');
    optWeight = sprintf('%0.3f %s, %0.3f %s',round(moistureLvl,3),titles{1}(19:end-1),round(maxDryWeight,3),titles{2}(18:end-1));
    bottomBound = (percStand./100).*maxDryWeight;
    fun = dryUW - bottomBound;
    geronimo = round(trapz(moistureCont(~(fun<0)),fun(~(fun<0))),3);
end