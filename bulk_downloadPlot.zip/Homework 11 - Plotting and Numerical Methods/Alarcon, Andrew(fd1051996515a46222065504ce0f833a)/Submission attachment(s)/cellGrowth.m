function cellGrowth(counts, timePts)
    plot(timePts, counts,'r.')
    hold on
    mean = (sum(counts)/length(counts)).*(ones(1,length(counts)));
    plot(timePts, mean,'b-.')
    maxi = max(counts);
    mini = min(counts);
    top = maxi.*(ones(1,length(counts)));
    plot(timePts, top,'m--')
    axis([timePts(1)-((timePts(end)-timePts(1))*0.05),...
        timePts(end)+((timePts(end)-timePts(1))*0.05),...
        mini-((maxi - mini)*0.05),maxi+((maxi-mini)*0.05)],'square')
    title('Cell Growth vs Time')
    xlabel('Time')
    ylabel('# Cells')
end