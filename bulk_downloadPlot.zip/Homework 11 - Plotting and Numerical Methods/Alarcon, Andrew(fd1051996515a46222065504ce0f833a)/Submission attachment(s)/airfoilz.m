function [Cl] = airfoilz(aoaVec, ClVec, anglVec)
    line = polyfit(aoaVec,ClVec,2);
    nums = min(aoaVec):max(aoaVec);
    lineVals = polyval(line,nums);
    plot(aoaVec,ClVec,'b*',nums,lineVals,'k') 
    Cl = round(interp1(nums,lineVals,anglVec,'spline'),3);
end