function [canRead] = wordDist(fileName)
    fh = fopen(fileName);
    line = fgetl(fh);
    counter = [0];
    techWord = false;
    while ischar(line)
        goodLine = line((lower(line)>='a' & lower(line)<='z')|line==' ');
        while ~isempty(goodLine)
            [word,goodLine] = strtok(goodLine);
            if length(word) > length(counter)
                counter(length(word)) = 0;
            end
            counter(length(word)) = counter(length(word)) + 1;
            if strcmp('technology',word)
               techWord = true; 
            end
        end
        line = fgetl(fh);
    end
    if (techWord||length(counter)<14)
        canRead = 'We''re at Georgia Tech, we can read that!';
    else
        canRead = 'We''re at Georgia Tech, we can''t read that :(';
    end
    bar(1:length(counter),counter)
    xlabel('Length of Word')
    ylabel('Number of Occurrences')
    title(['Can we read ' fileName(1:end-4) '?'])
    fclose(fh);
end