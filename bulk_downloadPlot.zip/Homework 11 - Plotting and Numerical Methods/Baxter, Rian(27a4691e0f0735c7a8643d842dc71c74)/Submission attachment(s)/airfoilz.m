function lift_coeff = airfoilz (angles,lift,tests)
min_angle = min(angles);
max_angle = max(angles);
draw_pts = min_angle:max_angle;

coeffs = polyfit(angles,lift,2);
calc_lift = polyval(coeffs,draw_pts);

figure(1)
hold on;

plot(angles,lift,'b*')
plot(draw_pts,calc_lift,'k-')

calc_vals = interp1(draw_pts,calc_lift,tests,'spline');
lift_coeff = round(calc_vals,3);
end