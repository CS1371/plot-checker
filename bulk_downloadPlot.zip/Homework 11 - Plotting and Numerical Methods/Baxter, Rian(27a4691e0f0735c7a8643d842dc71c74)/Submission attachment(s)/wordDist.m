function result = wordDist(file)
fh = fopen(file); %initializing variables
line = fgets(fh);
counts = [];
tech=false;
while line ~=-1
    [word,line] = strtok(line);
    while word~= -1
        word = word(word>='a'&word<='z' | word>='A'&word<='Z');
        if isempty(word)
            [word,line] = strtok(line);
            word = word(word>='a'&word<='z' | word>='A'&word<='Z');
        end
        l = length(word);
        if strcmpi(word,'technology')
            tech = true;
        end
        if l~= 0
            if length(counts)<l
                counts(l) = 1;
            else
                counts(l) = counts(l)+1;
            end
            [word,line] = strtok(line);
        end
    end %word by word
    line = fgets(fh);
end %line by line

if length(counts)<=13 %printing results
    result = 'We''re at Georgia Tech, we can read that!';
elseif tech
    result = 'We''re at Georgia Tech, we can read that!';
else
    result = 'We''re at Georgia Tech, we can''t read that :(';
end

figure(1)%make histogram
hold on
bar(counts)
xlabel('Length of Word')
ylabel('Number of Occurrences')
head = ['Can we read ' file(1:end-4) '?'];
title(head)

end