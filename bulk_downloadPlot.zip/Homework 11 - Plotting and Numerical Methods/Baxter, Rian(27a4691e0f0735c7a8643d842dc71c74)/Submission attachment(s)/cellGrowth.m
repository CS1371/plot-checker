function cellGrowth(counts,times)

avg = mean(counts);

x_min = min(times);
x_max = max(times);
x_range = x_max-x_min;
y_min = min(counts);
y_max = max(counts);
y_range = y_max-y_min;

figure(1)
hold on;
axis([x_min-(.05.*x_range),x_max+(.05.*x_range),y_min-(.05.*y_range),y_max+(.05.*y_range)])
axis square

blank = ones(1,length(times));
plot(times,counts,'r.')
plot(times,avg*blank,'b-.')
plot(times,y_max*blank,'m--')

title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')


end