function molecule(lengths,angles,circles)
[points] = findPoints(lengths,angles);
[locations,sizes] = findCenter([points]);

figure(2)
hold on;
axis square
axis off
plot(points(1,:),points(2,:),'k-')

plotCircles(locations,sizes,circles)

end

function [points] = findPoints(lengths,angles)
points = [0;0];
current_angle = 0;
for i = 1:length(lengths)
    current_angle = current_angle+angles(i);
    points(1,i+1) = points(1,i)+lengths(i).* cosd(current_angle);
    points(2,i+1) = points(2,i)+lengths(i).* sind(current_angle);
end
end

function plotCircles(locations,sizes,circles)
locations = [locations(1,(circles));locations(2,(circles))];
sizes = .65 .* sizes(1,(circles));
plot_angles = linspace(0,360);
points = [0;0];
for i = 1:size(locations,2)
    for j = 1:length(plot_angles)
        points(1,j) = locations(1,i)+sizes(i)*cosd(plot_angles(j));
        points(2,j) = locations(2,i)+sizes(i)*sind(plot_angles(j));
    end
    plot(points(1,:),points(2,:),'b')
end

end