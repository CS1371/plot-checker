function [str_out,area_out] = proctorTest(xls_file,pct_std_proct)
[num txt raw] = xlsread(xls_file);
x_data = num(:,1);
y_data = num(:,2);
x_diff = x_data(1:end-1)+.5.*diff(x_data);
deriv = diff(y_data)./diff(x_data);
[~,x_units] = strtok(raw(1,1),'(');
x_units = x_units{1}(x_units{1}~= '(' & x_units{1}~= ')');
[~,y_units] = strtok(raw(1,2),'(');
y_units = y_units{1}(y_units{1}~= '(' & y_units{1}~= ')');

loc = spline(deriv,x_diff,0);%find max location
max_val = interp1(x_data,y_data,loc,'spline');
loc= round(loc,3);

newbase = pct_std_proct*max_val/100; %raise baseline
new_y = y_data - newbase;
new_x = x_data(new_y>=0);
new_y = new_y(new_y>=0);

area_out = round(trapz(new_x,new_y),3); %integrate

str_out = sprintf('%0.3f %s, %0.3f %s', loc, x_units, round(max_val,3), y_units);

end