function cellGrowth(yVals, xVals)
x= xVals;
y= yVals;
stretcher= ones(1, length(xVals));
avg= stretcher .* mean(yVals);
most= stretcher .* max(yVals);

xc= (max(xVals)- min(xVals)) .* 0.05;
yc= (max(yVals)- min(yVals)) .* 0.05;

ymax= max(yVals) + yc;
ymin= min(yVals) - yc;
xmax= max(xVals) + xc;
xmin= min(xVals) - xc;

axis([xmin, xmax, ymin, ymax])
axis square
figure(1)
hold on
plot(x,y, 'r.')
plot(x,avg, 'b-.')
plot(x,most, 'm--')
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end
