function result= wordDist(file)
fh= fopen(file);
line= fgetl(fh);
techCount= 0;
counts= [];
 lVec= [];
while ischar(line)
    rest= line;
    while ~isempty(rest)
        [word, rest]= strtok(rest);
        word= lower(word);
        word= word(word >= 'a' & word <= 'z');
        if strcmp(word, 'technology');
            techCount= techCount + 1;
        elseif ~isempty(word)
            letters= length(word);
            check= letters== lVec;
            if any(check)
                counts(letters)= counts(letters) +1;
            else
                counts(letters)=1;
                lVec= [lVec letters];
            end
        end
    end
    line= fgetl(fh);
end

x= 1:length(counts);
bar(x, counts);

ending= find(file=='.');
newfile= file(1:(ending-1));
string= sprintf('Can we read %s?', newfile);
title(string)
xlabel('Length of Word')
ylabel('Number of Occurrences')
if length(counts) <= 13 | techCount >= 1
    result= sprintf('We''re at Georgia Tech, we can read that!');
else
    result= sprintf('We''re at Georgia Tech, we can''t read that :(');
end
fclose(fh);
end
