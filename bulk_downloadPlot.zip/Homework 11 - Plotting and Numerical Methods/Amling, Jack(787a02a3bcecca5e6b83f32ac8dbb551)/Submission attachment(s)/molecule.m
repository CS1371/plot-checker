function molecule(lengths, angles, logical)
hold on
axis square
axis equal
axis off
final= [0; 0];
vec= [0;0];
a2= 0;
for i= 1:length(lengths)
    long= lengths(i);
    angle= angles(i);
    a1= angle + a2;
    a2= a1;
    points = [long; 0];
    rotmat= [cosd(a1) -sind(a1) ; sind(a1) cosd(a1)];
    npoints= rotmat * points;
    vec= [vec, (final+npoints)];
    final= final + npoints;
end
[centers, sizes]= findCenter(vec);

for i= 1: length(logical)
    if logical(i)
        count=1;
        theta= linspace(0, (360), 100);
        x = (sizes(i))*cosd(theta) .* 0.65;
        y = (sizes(i))*sind(theta) .* 0.65;
        
        moveX= centers(1, i);
        moveY= centers(2, i);
        stretcher= ones(1, 100);
        x2= x + (moveX);
        y2= y + (moveY);
        xVec(count:(count.*100))= x2;
        yVec(count:(count.*100))= y2;
        plot(xVec, yVec, 'b');
        count= length(xVec) +1;
    end
end        
plot(vec(1,:), vec(2,:),'k')