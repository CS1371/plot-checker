function answers= airfoilz(angles, lifts, questions)
x= angles
y= lifts



x1= min(x):max(x)
y1= interp1(x,y, x1)
mypoly= polyfit(x, y, 2)
myvals= polyval(mypoly, x1)


figure(1)
hold on
plot(x,y, 'b*')
plot(x1, myvals, 'k')
answers= round(spline(x1, myvals, questions),3)
end