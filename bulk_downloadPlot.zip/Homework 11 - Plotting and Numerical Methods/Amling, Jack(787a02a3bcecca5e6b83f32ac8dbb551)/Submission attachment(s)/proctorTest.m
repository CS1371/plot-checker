function [str1, area] = proctorTest(file, SP)
[num, text, ~]= xlsread(file);
moist= num(:, 1)';
dry= num(:, 2)';
deriv= diff(dry) ./ diff(moist);

box= text{1,2};
[~, rest]= strtok(box, '(');
label= rest(rest ~= '(' & rest~= ')');

midpoints=(moist(1:end-1) + moist(2:end))/2;
point= spline(deriv, midpoints, 0);
most= spline(moist,dry, point);
max= round(most, 3);

str1= sprintf('%0.3f %%, %0.3f %s', point, max, label);

lowLimit= (SP ./ 100) .* most;

mask= dry >= lowLimit;
moist2= moist(mask);
dry2= dry(mask);

bad= trapz(moist2, dry2 - lowLimit);
area= round(bad, 3);
end
