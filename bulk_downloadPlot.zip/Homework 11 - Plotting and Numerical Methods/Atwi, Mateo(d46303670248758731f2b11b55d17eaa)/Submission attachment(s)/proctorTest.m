function [optimal, area] = proctorTest(fileName, duw)
[nums, strs, data] = xlsread(fileName)

unit1 = strs{1}
unit1 = unit1(find(unit1 == '(')+1:find(unit1 == ')')-1)
unit2 = strs{2}
unit2 = unit2(find(unit2 == '(')+1:find(unit2 == ')')-1)



difX = diff(nums(:,1))
difY = diff(nums(:,2))

derive = difY./difX

midpoints = (difX/2) + nums(1:end-1,1)

magic = interp1(derive, midpoints, 0, 'spline')

stupid = interp1(nums(:,1), nums(:,2), magic, 'spline')


optimal = sprintf('%0.3f %s, %0.3f %s', round(magic,3), unit1, round(stupid,3), unit2)


areaPoints = nums(:,2) - (duw /100 * stupid)

mask = find(areaPoints > 0)
area = trapz(nums(mask,1), areaPoints(mask))



end