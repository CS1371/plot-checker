
function cellGrowth(cellCounts, timePoints)
plot(timePoints, cellCounts, 'r.')
hold on
plot(timePoints, mean(cellCounts)*ones(1,length(timePoints)),'b-.')
plot(timePoints, max(cellCounts)*ones(1,length(timePoints)),'m--')
borderX = (max(timePoints) - min(timePoints))* .05;
borderY = (max(cellCounts) - min(cellCounts))* .05;
axis([min(timePoints)-borderX, max(timePoints)+borderX, min(cellCounts)-borderY, max(cellCounts)+borderY])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
hold off
end
