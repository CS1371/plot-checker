function level = wordDist(fileName)
file = fopen(fileName);
line = fgetl(file);
lc = [];
tExists = false;

while ischar(line)
    %remove anything that isn't a letter or a space
    mask = ((line >= 'a' & line <= 'z') | (line >= 'A' & line <= 'Z')) | line == ' ';
    line(~mask) = '';
    if length(strfind(line, 'technology')) > 0
        tExists = true;
    end
    %find the indicies of the spaces
    spaces = find(line == ' ');
    if length(spaces) > 0
        %first word
        wl = spaces(1) - 1;
        
        
        
        if wl <= length(lc) & wl > 0
            lc(wl) = lc(wl) + 1;
        elseif wl > 0
            lc(wl) = 1;
        end
        %last word
        wl = length(line) - spaces(end);
        
        if wl <= length(lc) & wl > 0
            lc(wl) = lc(wl) + 1;
        elseif wl > 0
            lc(wl) = 1;
        end
        
        %inbetween words
        wls = diff(spaces)-1;
        
        for i = wls
            if i <= length(lc) & i > 0
                lc(i) = lc(i) + 1;
            elseif i ~= 0
                lc(i) = 1;
            end
            if i == 13
                line
            end
        end
    else
        %if there's only one world
        wl = length(line);
        
        if wl <= length(lc) & wl > 0
            lc(wl) = lc(wl) + 1;
        elseif wl ~= 0
            lc(wl) = 1;
        end
        
        
    end
    
    line = fgetl(file);
end

bar(lc)
title(sprintf('Can we read %s?', fileName(1:end-4)))

xlabel('Length of Word')
ylabel('Number of Occurrences')

if length(lc) <= 13 | tExists
    level = 'We''re at Georgia Tech, we can read that!';
    
else
    level = 'We''re at Georgia Tech, we can''t read that :(';
end

end