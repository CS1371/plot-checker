function molecule(lengths, angle, circle)
hold on

%find hexagon sidelength
hexaSL = findRad(lengths, angle);


%current point
cp = [0; 0];
%total angle
ta = 0;

%all points
ap = cp;

for i = 1:length(lengths)
    ca = angle(i);
    ta = angle(i) + ta;
    %new point
    np = calcPoint(lengths(i), ta, cp);
    plot([cp(1) np(1)],[cp(2) np(2)], 'k');
    cp = np;
    ap = [ap, cp];
end
centers = findCenter(ap);
for i = find(circle)
    drawCircle(centers(1,i),centers(2,i), .65 * hexaSL(i));
end
axis square
axis off
hold off
end

function drawCircle(x,y,r)
ang=linspace(0,2*pi, 100); 
rx=r*cos(ang);
ry=r*sin(ang);
plot(x+rx,y+ry, 'b');
end

function newPoint = calcPoint(l, angle, cp)
newPoint = cp;
newPoint(1) = (cp(1) + (l * cosd(angle)));
newPoint(2) = (cp(2) + (l * sind(angle)));
end

function hexRad = findRad(lengths, angle)
hexRad = [];
if length(angle) > 6
    for i = 1:(length(angle)-4)
        if all(angle(i:i+4) == angle(i)) & any(angle(i) == [300, 60, -60, -300])
            hexRad = [hexRad lengths(i)];
        end
    end
end

end