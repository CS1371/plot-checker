function liftCoef = airfoilz(anglesOfAttack, coefs, angles)
fit = polyfit(anglesOfAttack, coefs, 2)
xi = min(anglesOfAttack):max(anglesOfAttack)

points = polyval(fit, xi)
plot(anglesOfAttack, coefs, 'b*')
hold on
plot(xi, points, 'k-')
%do more stuff

%var = interp1(


liftCoef = round(interp1(xi, points, angles, 'spline'),3)
end