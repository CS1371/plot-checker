function liftout = airfoilz(attackpath,coefficients,angles)
plot(attackpath,coefficients,'b*');
hold on;
 
xmin = min(attackpath);
xmax = max(attackpath);
 
xval = [xmin:xmax];
% calculate points at every interger x value between min and max
 
coeff = polyfit(attackpath,coefficients,2);
% fit 2nd degree polynomial to the data
yval = polyval(coeff,xval);
% creates graph with polyval, gets y-values 
plot(xval,yval,'k');
% plots the fit as black line
hold on;
 
liftout = interp1(xval,yval,angles,'spline');
% use spline interpolation on the polynomial fit to compute lift
% coefficients that correspond to the given angles
liftout = round(liftout,3);
% determine lift coefficients at particular angles of attack
end

