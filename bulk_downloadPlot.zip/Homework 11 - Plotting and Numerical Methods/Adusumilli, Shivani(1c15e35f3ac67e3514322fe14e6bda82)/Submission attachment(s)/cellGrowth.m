function cellGrowth(cellCount,timePoints)
x = [];
for i = 1:length(timePoints)
    time = timePoints(1,i);
    x = [x time];
end
% finds x points
y = [];
for j = 1:length(cellCount)
    cell = cellCount(1,j);
    y = [y cell];
end
% finds y points
plot(x,y,'r.'); % plots cell count (y-axis) vs time data(x-axis) points in red points
hold on;
 
meanY = mean(cellCount); % mean population size
meanY = ones(1,length(y)) .* meanY;
plot(x,meanY,'b-.'); % plots mean population size in blue dashdots, same x-values
hold on;
 
maxY = max(cellCount); % max population size
maxY = ones(1,length(y)) .* maxY;
plot(x,maxY,'m--'); % plots max population size in magenta dases, same x-values
hold on;
 
x_max = max(timePoints); 
x_min = min(timePoints);
x_minmin = x_min - (x_min * 0.05);
x_maxmax = x_max + (x_max * 0.05);
x_range = [x_minmin x_maxmax]; % x axes range from +/- 5% of max and min values
 
y_max = max(cellCount);
y_min = min(cellCount);
y_minmin = y_min - (y_min * 0.05);
y_maxmax = y_max + (y_max * 0.05);
y_range = [y_minmin y_maxmax]; % y axes range from +/- 5% of max and min values
 
xlim(x_range);
ylim(y_range);
% sets x and y ranges
 
axis square;
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
% labels graphs
end