function str = wordDist(text)
fh = fopen(text);
line = fgets(fh);
 
x = [];
sentence = [];
wordcount = [];
 
while ischar(line)
    line = line(line >= 'A' & line <= 'Z' | line >= 'a' & line <= 'z' | line == ' ');
    [word1 rest] = strtok(line, ' '); 
    lengthword1 = length(word1);
    x = lengthword1;
    % finds first word and length of first word
        while ~isempty(rest)
        [words rest] = strtok(rest, ' ');
        sentence = [sentence words];
        wordlength = length(words);
        x = [x wordlength];
        % creates vector of word lengths (from second word to last)
        end
    line = fgets(fh);
    wordcount = [wordcount x];
    % creates vector of word lengths for all words
end
 
lengthofword = 1:max(wordcount);
% finds the length of words (x axis)

wordCountReps = zeros(length(wordcount));
count = 0;
for i = 1:wordCountReps
    for j = 1:wordCountReps
        if wordCountReps(i) == wordCountReps(j)
            count = count + 1;
        end
    end
end
 
 
if  strfind(sentence, 'technology')
    str = sprintf('We''re at Georgia Tech, we can read that!');
elseif lengthofword <= 13
    str = sprintf('We''re at Georgia Tech, we can read that!');
else
    str = sprintf('We''re at Georgia Tech, we can''t read that :(');
end
 
bar(lengthofword);
% creates bar graph
xlabel('Length of Word');
ylabel('Number of Occurences');
file = text(1:end-4);
titlename = sprintf('Can we read %s?',file);
title(titlename);
% labels graph
end