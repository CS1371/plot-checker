function molecule(linelengths,angles,ring)
figure(1)
points = [linelengths; zeros(1,length(linelengths))];
xvals = 0;
yvals = 0;
a = 1;
while a <= length(angles) % use while loop to go through all points
    x = angles(a); % returns one double (degrees)
    rotA = [cosd(x) -sind(x);sind(x) cosd(x)]; % finds angles in radians and 
%     concatenates 
    points = rotA * points; % matrix multiplication to rotate points clockwise 
%     about origin
    xvals = [xvals xvals(a) + points(1,a)]; 
    yvals = [yvals yvals(a) + points(2,a)];
    x2 = [xvals(a) xvals(a+1)];
    y2 = [yvals(a) yvals(a+1)];
    plot(x2,y2,'k');
    hold on;
    a = a+1;
end
%   by the end of this while loop all the black lined structures are formed

[c, rad] = findCenter([xvals;yvals]); 
angles = linspace(0,2*pi,100); % create new angles for ring using linspace function
b = 1;
while b <= length(ring)
    if ring(b) == true 
        radius = rad(b).*0.65; 
        xcircle = c(1,b);
        ycircle = c(2,b);
        xcircle = xcircle + radius.*cos(angles); % x coordinates of the circle
        ycircle = ycircle + radius.*sin(angles); % y coordinates of the circle
        plot(xcircle,ycircle,'b');
        b = b + 1;
    else
        b = b + 1;
    end  
end
axis square;
axis off;
end

