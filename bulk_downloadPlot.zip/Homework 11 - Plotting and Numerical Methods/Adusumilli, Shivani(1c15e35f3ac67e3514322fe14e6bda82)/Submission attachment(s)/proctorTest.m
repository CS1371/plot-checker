function [stringout,area] = proctorTest(datafile, percent)
[num,text,~] = xlsread(datafile);
xaxis = text{1}; % return text in cell
units1 = strfind(xaxis,'('); % gives units of moisture content(x axis)
xaxis(1:units1) = [];
xaxis(end) = [];
yaxis = text{2};
units2 = strfind(yaxis,'('); % gives units of dry weight (y axis)
yaxis(1:units2) = [];
yaxis(end) = [];

xvals = num(:,1)';
yvals = num(:,2)';

deriv = diff(yvals)./diff(xvals);
x2 = diff(xvals)./2;
newxvals = xvals;
newxvals(end) = [];
newxvals = newxvals + x2;

maxX = interp1(deriv,newxvals,0,'spline'); % spline to find where derivative = 0
maxY = interp1(xvals,yvals,maxX,'spline'); % spline to find corresponding y vals
percentile = maxY.*(percent./100); % gets percentile line
curve = polyfit(xvals,yvals,2); 
curve(3) = curve(3) - percentile;

targetarea = yvals >= percentile; % bc must find area above percentile line
x3 = xvals(targetarea); % gives xvals of target area
shiftedyvals = yvals(targetarea);
shiftedyvals = shiftedyvals - percentile; % shift yvals down so that target area
% starts at x axis and makes it easier to get area below curve
area = round(trapz(x3,shiftedyvals), 3);
stringout = sprintf('%0.3f %s, %0.3f %s',maxX,xaxis,maxY,yaxis);
end