function cellGrowth(cellcount, time)
plot(time, cellcount, 'r.');
hold on
maxcount = max(cellcount);
avgcount = mean(cellcount);
maxpts = []; avgpts = [];
for i = 1:length(cellcount)
    maxpts = [maxpts maxcount];
    avgpts = [avgpts avgcount];
end

plot(time, maxpts, 'm--')
plot(time, avgpts, 'b-.')
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')

maxx = max(time)
minx = min(time)
xrange = maxx - minx
maxy = max(cellcount)
miny = min(cellcount)
yrange = maxy - miny
axis([minx - 0.05 * xrange, maxx + 0.05 * xrange, miny - 0.05 * yrange, maxy + 0.05 * yrange])
end