function [out] = airfoilz(attangles, lcoeffs, chosenangles)
plot(attangles, lcoeffs, 'b*')
hold on
minatt = min(attangles);
maxatt = max(attangles);
xvals = minatt:maxatt;

poly = polyfit(attangles, lcoeffs, 2)
yvals = polyval(poly, xvals)
plot(xvals, yvals, 'k')
out = interp1(xvals, yvals, chosenangles, 'spline')
out = round(out, 3);
end