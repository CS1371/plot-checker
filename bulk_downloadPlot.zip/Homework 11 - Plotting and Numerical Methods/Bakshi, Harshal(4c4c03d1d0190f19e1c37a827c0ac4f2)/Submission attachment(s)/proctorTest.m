function [optimal, area] = proctorTest(filename, percent)
[num txt raw] = xlsread(filename);
plot(num(:, 1), num(:, 2))
[~, xunit] = strtok(raw{1, 1}, '(')
xunit = xunit(2:end - 1);
[~, yunit] = strtok(raw{1, 2}, '(')
yunit = yunit(2:end - 1);
dryweight = num(:, 2);
moistcontent = num(:, 1);
%%
dy = diff(dryweight) ./ diff(moistcontent);
dx = [];


% finding midpts: 
for i = 1:length(moistcontent) - 1
    x = mean([moistcontent(i) moistcontent(i + 1)])
    dx = [dx x]
end
newx = interp1(dy, dx, 0, 'spline');
maxdryweight = interp1(moistcontent, dryweight, newx, 'spline');

yval = (percent .* maxdryweight) ./ 100;
dryweight = dryweight - yval;

mask = dryweight >= 0;
moistcontent = moistcontent(mask);
dryweight = dryweight(mask);



optimal = 0
area = 0
end