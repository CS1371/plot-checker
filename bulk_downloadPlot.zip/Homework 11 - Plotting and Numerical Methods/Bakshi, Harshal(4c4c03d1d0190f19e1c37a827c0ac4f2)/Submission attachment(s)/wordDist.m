function str = wordDist(filename)
trackvec = zeros(1, 30);
fh = fopen(filename);
line = fgetl(fh);
while ischar(line)
    line = lower(line);
    line = line((line == 32) | (line <= 'z' & line >= 'a'));
    spacenum = sum(line == 32);
    for i = 1:spacenum + 1
        [word, line] = strtok(line);
        if ~strcmp(word, '')
            wordlength = length(word);
            trackvec(wordlength) = trackvec(wordlength) + 1;
            [word, line] = strtok(line);
        else
            [word, line] = strtok(line);
        end
    end
    line = fgetl(fh);
end

fclose(fh);

while trackvec(end) == 0
    trackvec(end) = [];
end

fh = fopen(filename);
line = fgetl(fh);
techexists = false;
while ischar(line)
    if strcmp(lower(line), 'technology')
        techexists = true;
    else
        line = fgetl(fh);
    end
end
if length(trackvec) <= 13 & ~techexists
    str = ('We''re at Georgia Tech, we can read that!');
else
    str = ('We''re at Georgia Tech, we can''t read that :(');
end
bar(trackvec);
graphtitle = sprintf('Can we read %s?', filename(1:end - 4));
title(graphtitle);
xlabel('Length of Word');
ylabel('Number of Occurrences');
fclose(fh);
end