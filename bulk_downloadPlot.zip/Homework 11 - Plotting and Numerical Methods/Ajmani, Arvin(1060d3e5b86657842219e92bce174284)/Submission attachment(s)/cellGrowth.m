function cellGrowth(vcount,tpoint)
plot(tpoint,vcount,'r.')
y = mean(vcount)
yo = ones(size(vcount))
yo(1:end) = y
hold on
plot(tpoint,yo,'b-.')
hold on
y = max(vcount)
yo = ones(size(vcount))
yo(1:end) = y
plot(tpoint,yo,'m--')
xlni = min(tpoint) - (max(tpoint) - min(tpoint)).*.05
xlnf = max(vcount) - (max(tpoint)-min(tpoint)).*.05
ylni = min(vcount) - (max(vcount) - min(vcount)).*.05
ylnf = max(vcount) - (max(vcount)-min(vcount)).*.05
axis([-5 105 -50 1050])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end