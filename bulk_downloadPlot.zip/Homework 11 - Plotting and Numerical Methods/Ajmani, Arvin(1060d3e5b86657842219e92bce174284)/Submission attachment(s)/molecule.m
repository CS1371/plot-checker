function molecule(in1,in2,in3)
end