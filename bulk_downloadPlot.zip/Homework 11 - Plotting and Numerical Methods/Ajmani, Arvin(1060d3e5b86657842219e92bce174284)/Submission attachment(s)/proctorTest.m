function [stro,area] = proctorTest(xl,percent)
[nums,txt,raw] = xlsread(xl)
txt = cell2mat(txt)
uf1 = find(txt=='(')+1
uf11 = find(txt==')')-1
u1 = txt(uf1(1):uf11(1))
u2 = txt(uf1(2):uf11(2))
% maxwt = max(nums(:,2))
% fidx = find(nums(:,2)== maxwt)
% water = nums(fidx,1)
x = nums(:,1)
y = nums(:,2)
diff1 = diff(x)
diff2 = diff(y)
derivy = diff2./diff1
derivx = (x(1:end-1,:) + x(2:end,:)) / 2
wc = round(interp1(derivy,derivx,0,'spline'),3)
wt = interp1(x,y,wc,'spline')
wtr = round(interp1(x,y,wc,'spline'),3)
stro = sprintf('%0.3f %s, %0.3f %s',wc,u1,wtr,u2)
percent = percent/100
percent1 = percent.*wt
percenty = y - percent1

masky = find(percenty > 0)
y = percenty(masky)
x = x(masky)
area = trapz(x,y)
area = round(trapz(x,y),3)
end