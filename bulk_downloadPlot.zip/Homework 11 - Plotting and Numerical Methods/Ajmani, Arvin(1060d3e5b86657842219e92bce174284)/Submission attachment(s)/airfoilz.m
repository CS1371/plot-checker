function lcaoa = airfoilz(aoa,liftc,angl)
polyf = polyfit(aoa,liftc,2)
minaoa = min(aoa)
maxaoa = max(aoa)
int = minaoa:maxaoa
polyv = polyval(polyf,int)
plot(int,polyv,'k')
hold on
plot(aoa,liftc,'b*')

lcaoa = round(spline(int,polyv,angl),3)




end