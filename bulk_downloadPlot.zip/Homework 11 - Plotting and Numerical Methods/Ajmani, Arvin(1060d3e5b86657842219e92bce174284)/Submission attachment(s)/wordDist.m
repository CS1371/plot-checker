function rornaw = wordDist(name)
F = fopen(name,'r')
txts = fileread(name)

line = fgetl(F)
mask = line>=65 & line <=90 | line >=97 & line <=122 | line == ' '
line(~mask) = []
count = 0
wordlength = []
i = 0
ncvec = []
lengths = []
% if ~isempty(strintel1|strintel2)
%     rornaw = 'We''re at Georgia Tech, we can read that!'
% elseif isempty(strintel1|strintel2)
while ischar(line)  
    mask = line>=65 & line <=90 | line >=97 & line <=122 | line == ' '
    line(~mask) = []
    while ~isempty(line)
        
      [word, line] = strtok(line,' ');
      count = count + 1;
      wordlength = [wordlength length(word)];
      i = i + 1
    end
    
    
    
    line = fgetl(F)
%     if line ~=-1
%     
%     end
    
end
maxw = max(wordlength)
for k = 1:max(wordlength)
    numcount = find(wordlength==k)
    ncvec = [ncvec length(numcount)]
    lengths = [lengths k]
end
gtitle = name(1:end-4)
gtitle = sprintf('Can we read %s?',gtitle)
bar(lengths,ncvec)
title(gtitle)
xlabel('Length of Word')
ylabel('Number of Occurences')
strintel1 = strfind(txts,'Technology')
strintel2 = strfind(txts,'technology')
check1 = find(lengths) > 13
check2 =  ~isempty(strintel1) | ~isempty(strintel2)
if sum(check1) ~= 0 & check2 ==0
    rornaw = 'We''re at Georgia Tech, we can''t read that! :('
elseif sum(check1) == 0 | ~isempty(check2)
    rornaw = 'We''re at Georgia Tech, we can read that!'

end