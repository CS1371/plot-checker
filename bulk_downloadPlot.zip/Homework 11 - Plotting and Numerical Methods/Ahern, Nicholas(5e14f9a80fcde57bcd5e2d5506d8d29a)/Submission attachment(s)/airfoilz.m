function out = airfoilz(attack,lift,determine)
hold on
plot(attack,lift,'b*')
line = polyfit(attack,lift,2);
minval = min(attack);
maxval = max(attack);
xvals = minval:1:maxval;
yvals = polyval(line,xvals);
plot(xvals,yvals,'k')
out = polyval(line,determine);
out = round(out,3);
end