function molecule(lines,angles,rings)

points = [0;0];
angles = cumsum(angles);
l = length(angles);
points(:,2) = [cosd(angles(1)) -sind(angles(1)); sind(angles(1)) cosd(angles(1))]*[(points(1) + lines(1));points(2)];
for i = 3:l+1
    point = [cosd(angles(i-1)) -sind(angles(i-1)); sind(angles(i-1)) cosd(angles(i-1))]*[(points(1) + lines(1));points(2)];
    points(:,i) = point + points(:,i-1);
end
hold on
plot(points(1,:),points(2,:),'k')
axis square
axis off
[centers radii] = findCenter(points);
centers = centers(:,rings);
radii = radii(:,rings);
[a b] = size(centers);
for i = 1:b
    x = linspace(0,2*pi,100);
    X = radii(i).*cos(x)*.65;
    Y = radii(i).*sin(x)*.65;
    circ = [X;Y];
    circ(1,:) = centers(1,i)+circ(1,:);
    circ(2,:) = centers(2,i)+circ(2,:);
    plot(circ(1,:),circ(2,:),'b')
end

end