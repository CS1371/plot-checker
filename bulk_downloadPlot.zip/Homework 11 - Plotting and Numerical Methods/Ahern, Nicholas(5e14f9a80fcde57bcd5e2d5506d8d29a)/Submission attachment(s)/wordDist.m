function string = wordDist(txt)
fh = fopen(txt);
line = fgetl(fh);
lengths = [];
string = '';

while ischar(line)
    line = lower(line);
    mask = line>=65 & line<=90;
    mask1 = line>=97 & line<=122;
    mask2 = line == ' ';
    mask = mask + mask1 +mask2;
    line(~mask) = [];
    [word rest] = strtok(line);
    while ~isempty(word)
        l = length(word);
        lengths(l) = 1;
        [word rest] = strtok(rest);
    end
    line = fgetl(fh);
end
fclose(fh);

fh1 = fopen(txt);
line1 = fgetl(fh1);
lengths(:) = 0;
while ischar(line1)
    line1 = lower(line1);
    mask = line1>=65 & line1<=90;
    mask1 = line1>=97 & line1<=122;
    mask2 = line1 == ' ';
    mask = mask + mask1 +mask2;
    line1(~mask) = [];
    [word rest] = strtok(line1);
    while ~isempty(word)
        l = length(word);
        lengths(l) = lengths(l)+1;
        if strcmp(word,'technology')
            string = 'We''re at Georgia Tech, we can read that!';
        end
        [word rest] = strtok(rest);
    end
    line1 = fgetl(fh1);
end
l2 = length(lengths);
if ~isempty(string)
elseif l2 <=13
    string = 'We''re at Georgia Tech, we can read that!';
else
    string = 'We''re at Georgia Tech, we can''t read that :(';
end

xvals = 1:l2;
hold on
bar(xvals,lengths)
thing = txt(1:end-4);
title(sprintf('Can we read %s?',thing))
xlabel('Length of Word')
ylabel('Number of Occurances')
fclose(fh1);
end