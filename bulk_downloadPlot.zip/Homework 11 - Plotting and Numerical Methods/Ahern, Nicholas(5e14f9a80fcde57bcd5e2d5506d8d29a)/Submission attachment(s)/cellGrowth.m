function [] = cellGrowth(cells,times)
hold on 
plot(times,cells,'r.')
m = mean(cells);
l = length(cells);
meanvec = ones(1,l);
meanvec = m.*meanvec;
plot(times,meanvec,'b-.')
maxval = max(cells);
maxvec = ones(1,l);
maxvec = maxval.*maxvec;
plot(times,maxvec,'m--')
mintime = min(times);
maxtime = max(times);
mintime = mintime*.95;
maxtime = maxtime*1.05;
mincells = min(cells);
mincells = mincells.*.95;
maxcells = maxval.*1.05;
limits = [mintime maxtime mincells maxcells];
axis(limits)
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
end
