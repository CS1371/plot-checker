function [string area] = proctorTest(file,pct)

[nums txt raw] = xlsread(file);
xvals = nums(:,1)'; % moisture
yvals = nums(:,2)'; % Weights

u1 = txt{1};
u1 = u1(strfind(txt{1},'('):end);
u1 = u1(2:end-1);

u2 = txt{2};
u2 = u2(strfind(txt{1},'('):end);
u2 = u2(1:end-1);

diffx = diff(xvals);
diffy = diff(yvals);
dydx = diffy./diffx;

dxx = spline(dydx,xvals(1:end-1),0);
dyy = spline(dydx,yvals(2:end),0);
maxweight = (dxx+dyy)/2;
waterval = spline(xvals,yvals,maxweight);

string = sprintf('%0.3f %s, %0.3f %s',maxweight,u1,waterval,u2);

pctvals = maxweight*pct/100;
a = min(nums(:,1));
b = max(nums(:,1));
c = min(nums(:,2));
d = max(nums(:,2));
v = linspace(a,b);
z = linspace(c,d);
newvals = v-pctvals;
mask = newvals >= 0;
vals = newvals(mask);
z = z(mask);

area = trapz(z,vals);



end