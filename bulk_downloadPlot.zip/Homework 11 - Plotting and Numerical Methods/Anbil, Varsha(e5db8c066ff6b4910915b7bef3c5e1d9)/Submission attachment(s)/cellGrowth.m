function cellGrowth(cellcts, timepts)

meanpop = mean(cellcts); %mean cell population
meanvec = ones(1,length(timepts)).*meanpop; %ones vector of mean population for mean line
maxpop = max(cellcts); %max cell population
maxvec = ones(1,length(timepts)).*maxpop; %ones vec of max pop for max line
fivepery = maxpop.*.05; %five percent of max population
fiveperx = max(timepts).*.05; %five percent of max time

hold on
plot(timepts,cellcts,'r.') %plots cell pop vs time in red points

plot(timepts,meanvec,'b-.') %plots line of mean population in blue dash dots
plot(timepts,maxvec,'m--') %plots line of max population in magenta dashes

axis([min(timepts)-fiveperx,max(timepts)+fiveperx,min(cellcts)-fivepery,max(cellcts)+fivepery]) %adjusts axes
axis square %makes graph look square

title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')

end
