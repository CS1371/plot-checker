function [str] = wordDist(txtfile)

fh = fopen(txtfile);
line = fgetl(fh);

lengthvec = [];
readtech = false; %can we read this?
while ischar(line)
    while ~isempty(line)
        if strcmpi(line,'technology')
            readtech = true; %if technology is in the textfile, we can read it
        end
        mask = line >= 'a' & line <= 'z' | line >= 'A' & line <= 'Z' | line==' ';
        line(~mask) = []; %deletes everything that isn't a letter or space
        [word,rest] = strtok(line); 
        num = length(word); %finds length of each word in line
        lengthvec = [lengthvec, num]; %puts lengths in a vector
        rest = rest(2:end);
        line = rest;
    end
    line = fgetl(fh);
end
sortedlengths = sort(lengthvec); %sorted vector of the different lengths of words
sortedlengths(end+1) = 0; %adds a zero to the end so that there is no dimension mismatch
maxlength = max(sortedlengths);
timesvec = [];
count = 0;
for i = 1:maxlength
    j = 1;
    while isequal(i,sortedlengths(j))
        count = count + 1;
        j = j+1;
    end
    sortedlengths(1:count) = []; %deletes all the numbers that have already been counted
    timesvec = [timesvec count]; %number of occurrences for each number
    count = 0;  
end

if maxlength <= 13
    readtech = true;
end

if readtech==true
    str = 'We''re at Georgia Tech, we can read that!';
else
    str = 'We''re at Georgia Tech, we can''t read that :(';
end

lengthvec = 1:maxlength; %creates a vector of the different word lengths
bar(lengthvec,timesvec)

filename = txtfile(1:end-4); %extracts just the name of the file
title(sprintf('Can we read %s?',filename));
xlabel('Length of Word');
ylabel('Number of Occurrences');

end
