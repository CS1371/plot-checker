function [coeff] = airfoilz(angattack,liftco,angcoeff)

poly = polyfit(angattack, liftco, 2); %sets up polynomial

xs = min(angattack):1:max(angattack);
ys = polyval(poly,xs); %evaluates polynomial

plot(angattack, liftco, 'b*', xs, ys, 'k-');

coeff = round((interp1(xs,ys,angcoeff,'spline')),3);

end