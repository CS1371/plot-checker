function molecule(lengths, angles, rings)

pts = [0;0];
lastpt = [0;0];

hold on
newang = cumsum(angles);
for i = 1:length(lengths)
    pt = [lengths(i);0];
    rotmatrix = [cosd(newang(i)), -sind(newang(i)); sind(newang(i)), cosd(newang(i))];
    pt = rotmatrix*pt;
    pt = pt + lastpt;
    lastpt = pt;
    pts = [pts,lastpt];
end

x = pts(1,:);
y = pts(2,:);
plot(x,y,'k');
axis off
axis equal

th = linspace(0,2*pi);
[centers, hexsize] = findCenter(pts);
centers = centers(:,rings);

[~,col] = size(centers);

for i = 1:col
    xx = .65*hexsize(i)*cos(th);
    yy = .65*hexsize(i)*sin(th);
    xx = centers(1,i) + xx;
    yy = centers(2,i) + yy;
    
    plot(xx,yy,'b');
end

    