function [str,area] = proctorTest(xlsfile,percent)

[num, raw, ~] = xlsread(xlsfile);

xmoist = num(:, 1);
ywt = num(:, 2);
xdiff = diff(xmoist);
ydiff = diff(ywt);
deriv = ydiff./xdiff;

nums = [xmoist(1:end-1), xmoist(2:end)];
nums = nums';
mdpts = sum(nums)./2;

maxmoist = spline(deriv, mdpts, 0);
maxwt = spline(xmoist, ywt, maxmoist);
maxmoist2 = round(maxmoist, 3);
maxmoist2 = num2str(maxmoist2);
maxwt2 = round(maxwt, 3);
maxwt2 = num2str(maxwt2);

mhead = raw(1,1);
mhead = char(mhead);
moistnum = mhead(19:end-1);
wthead = raw(1,2);
wthead = char(wthead);
wtnum = wthead(18:end-1);

str = [maxmoist2, ' ', moistnum, ', ', maxwt2, ' ', wtnum];

pcts = maxwt.*(percent./100);
diffs = ywt - pcts;
xmoist(diffs < 0) = [];
diffs(diffs < 0) = [];

area = trapz(xmoist, diffs);
area = round(area, 3);

end