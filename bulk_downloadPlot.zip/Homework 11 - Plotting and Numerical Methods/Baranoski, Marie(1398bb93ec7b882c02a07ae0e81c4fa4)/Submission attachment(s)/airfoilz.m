function [coeff] = airfoilz(x, y, ang)
    hold on
    plot(x, y, 'b*');
    vec = polyfit(x, y, 2);
    xmin = min(x);
    xmax = max(x);
    nx = xmin:1:xmax;
    ny = polyval(vec, nx);
    plot(nx, ny, 'k');
    ny = spline(nx, ny, ang);
    coeff = round(ny, 3) 
end    