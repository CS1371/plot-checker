function cellGrowth(cell, time)

    plot(time, cell, 'r.');
    hold on
%     y = mean(cell);
    y = zeros(1, length(cell));
    y(:) = mean(cell);
%     plot([time(1), time(end)], [y, y], 'b-.');
    plot(time, y, 'b-.');
    m = y;
    m(:) = max(cell);
    plot(time, m, 'm--');
    
    x = min(time);
    x1 = max(time);
    range = x1 - x;
    xmin = x - (.05 * x1);
    xmax = x1 + (.05 *  x1);
    y = min(cell);
    y1 = max(cell);
    range = y1 - y;
    ymin = y - (.05 * y1);
    ymax = y1 + (.05 * y1);
    axis([xmin, xmax, ymin, ymax]);
    axis square;
    title('Cell Growth vs Time');
    xlabel('Time');
    ylabel('# Cells');
    
end