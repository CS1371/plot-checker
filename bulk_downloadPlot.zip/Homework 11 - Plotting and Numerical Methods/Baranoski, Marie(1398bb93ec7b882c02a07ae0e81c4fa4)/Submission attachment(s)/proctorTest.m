function [str, area] = proctorTest(xls, stdv)
    [num, txt, raw] = xlsread(xls);
    u = txt{1, 1};
    ind = strfind(u, '(');
    wunit = u(ind+1:end-1);
    u = txt{1, 2};
    ind = strfind(u, '(');
    dunit = u(ind+1:end-1);
    x = num(:, 1);
    y = num(:, 2);
    derivY = diff(y);
    dx = diff(x);
    derivX = x(1:end-1) + (diff(x) ./ 2);
    dydx = derivY ./ dx;
    xval = spline(dydx, derivX, 0);
    xval = round(xval, 3);
    yval = spline(x, y, xval);
    yval2 = round(yval, 3);
    str = sprintf('%.03f %s, %.03f %s', xval, wunit, yval2, dunit);
    stdv = stdv * .01;
    accept = yval * stdv;
    y = y - accept;
    xval2 = interp1(y, x, 0, [], 'extrap')
    a = 1;
    while a <= length(x)
        if y(a) < 0
            a = a + 1;
        else
            x1 = x(a:a + 1);
            y1 = y(a:a+1);
            xval1 = interp1(y1, x1, 0, [], 'extrap')
            break
        end
    end
    x = x - xval1;
    xval2 = xval2 - xval1;
    len = length(x);
    x = linspace(0, xval2, len);
    vec = cumtrapz(x, y);
    area = vec(end);
    area = round(area, 3)
    

    