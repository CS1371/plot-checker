function molecule(lengthl, angle, circle)
    %draw the first line of the molecule
    b = 2;
    n = 2;
    len = length(lengthl);
    ang = 0;
    nl = lengthl(1);
    na = angle(1);
    ang = na;
    x = nl * cosd(na);
    y = nl * sind(na);
    px = [0, x];
    py = [0, y];
    plot(px, py, 'k')
    hold on
    mat = [[0; 0], [x;y]];
    a = 2;
    %draw the rest of the lines of the molecule
    while a <= len
        nl = lengthl(a);
        na = ang + angle(a);
        ang = na;
        nx = x + (nl * cosd(na));
        ny = y + (nl * sind(na));
        px = [x, nx];
        py = [y, ny];
        plot(px, py, 'k')
        x = nx;
        y = ny;
        a = a + 1;
        vec = [x;y];
        mat = [mat, vec];
    end
    
    %add circles
    [centers, sizes] = findCenter(mat)
    centersx = centers(1, :);
    centersy = centers(2, :);
    centersx(~circle) = [];
    centersy(~circle) = [];
    sizes(~circle) = []
    a = 1;
    tx = [];
    ty = [];
    while a <= length(sizes)
        r = .65 .* sizes(a);
        vals = linspace(0, (2 * pi));
        x = (r .* cos(vals));
        y = (r .* sin(vals));
        x = x + centersx(a);
        y = y + centersy(a);
        plot(x, y, 'b');
        a = a + 1;
    end
    axis square
    axis off
end