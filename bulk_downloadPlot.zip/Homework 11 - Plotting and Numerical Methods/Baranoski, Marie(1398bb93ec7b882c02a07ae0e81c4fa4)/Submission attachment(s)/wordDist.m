function [out] = wordDist(file)
    fh = fopen(file);
    line = fgetl(fh);
    total = [];
    out = [];
    while line ~= -1;
        line = lower(line);
        mask = double(line) == 32 | (97 <= double(line) & double(line) <= 122);
        line(~mask) = [];
        ind = find(line == ' ');
        ds = diff(ind);
        mask = find(ds == 1);
        line(ind(mask)) = [];
        ind(mask) = [];
        ind = find(line == ' ');
        aaa = length(ind);
        if strfind(line, 'technology')
            out = sprintf('We''re at Georgia Tech, we can read that!');
        end
        if isempty(ind)
            lengths = length(line);
        elseif length(ind) == length(line)
            line = fgetl(fh);
        elseif aaa == 1
            w1 = line(1:ind-1);
            w2 = line(ind+1:end);
            lengths = [length(w1), length(w2)];
        else
            vec1 = [1, ind + 1];
            vec2 = [ind - 1, length(line)];
            vec = sort([vec1, vec2]);
            %             vec = [0, vec, length(line)];
            lengths = diff(vec) + 1;
            lengths = lengths(1:2:end);
        end
        line = fgetl(fh);
        total = [total, lengths];
        if isempty(line)
            line = fgetl(fh);
        else
            line = line;
        end
    end
    %     total = [total, lengths];
    vecl = [];
    vecn = [];
    while ~isempty(total)
        [len, nums] = mode(total);
        vecl = [vecl; len];
        vecn = [vecn; nums];
        ind = find(total == len);
        total(ind) = [];
    end
    [vecl, order] = sort(vecl);
    vecn = vecn(order);
    dif = diff(vecl);
    while any(dif > 1);
        ind = find(dif > 1);
        a = 1;
        while a <= length(ind)
            vec1 = vecl(1:ind(a));
            vec2 = vecl(ind(a)+1:end);
            x = vec1(end) + 1;
            vecl = [vec1; x; vec2];
            vec3 = vecn(1:ind(a));
            vec4 = vecn(ind(a)+1:end);
            vecn = [vec3; 0; vec4];
            a = a + 1;
        end
        dif = diff(vecl);
    end
    bar(vecn);
    xlabel('Length of Word');
    ylabel('Number of Occurances');
    str = file(1:end - 4);
    title(sprintf('Can we read %s?', str));
    if isempty(out)
        if any(vecl > 13)
            out = sprintf('We''re at Georgia Tech, we can''t read that :(');
        else
            out = sprintf('We''re at Georgia Tech, we can read that!');
        end
    else
        out = out;
    end
end

