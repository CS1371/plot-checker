function [out1] = airfoilz(ang,lifvec,nang)
    mypol = polyfit(ang,lifvec,2);
    var = polyval(mypol,nang);
    out1 = round(var,3);
    mang = max(ang);
    mnang = min(ang);
    xval = [mnang:mang];
    yval = interp1(ang,lifvec,xval,'spline');
    figure(1)
    plot(ang,lifvec,'b*')
    hold on
    new = [ang xval];
    new = sort(new);
    mval = polyval(mypol,new);
    plot(new,mval,'k-')
end