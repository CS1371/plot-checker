function molecule(seg,ang,l)
    % every time 180, add one to total count
    close all
    figure(1)
    hold on
    xvalz = []
    yvalz = []
    xsumm = 0
    ysumm = 0
    xptt = [0]
    yptt = [0]
    cuman = cumsum(ang)
    for i = 1:length(seg)
         xvalz = [xvalz, seg(i)*cosd(cuman(i))]
         yvalz = [yvalz, seg(i)*sind(cuman(i))]
         xsumm = xsumm+xvalz(i)
         ysumm = ysumm+yvalz(i)
         xptt = [xptt xsumm]
         yptt = [yptt ysumm]
    end
    plot(xptt,yptt,'k-')
    axis square
    arr = [xptt;yptt]
    [col,row] = findCenter(arr)
    for i = 1:length(l)
        if l(i)
            Rr = (row(i))*.65;
            theta = linspace(0,2*pi);
            Xss = col(1,i)+(Rr*cos(theta));
            Yss = col(2,i)+(Rr*sin(theta));
            plot(Xss,Yss,'b-')
        end
    end
    axis equal
    axis off
    hold off
end