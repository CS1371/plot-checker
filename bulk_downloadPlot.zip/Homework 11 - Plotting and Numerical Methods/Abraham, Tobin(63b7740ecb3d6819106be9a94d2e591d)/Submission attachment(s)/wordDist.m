function [level] = wordDist(filename)
fh = fopen(filename);
line = fgetl(fh);
totc = [];
tech = [];
while ischar(line); 
    line(~(line >= 'A' & line<='Z' | line>='a' & line<='z' | line == ' ')) = '';
    numspace = sum(line == ' ');
    [w r] = strtok(line,' ');
    numlet = [length(w)];
    for i = 1:numspace
        [w r] = strtok(r,' ');
        numlet = [numlet, length(w)];
        if any(strcmpi('technology',w))
            tech = 1;
        end
    end
    totc = [totc, numlet];
    line = fgetl(fh);
end
mwl = max(totc); %max word length
if tech
    level = sprintf('We''re at Georgia Tech, we can read that!')
elseif mwl <= 13
    level = sprintf('We''re at Georgia Tech, we can read that!')
else
    level = sprintf('We''re at Georgia Tech, we can''t read that :(')
end
totc(totc == 0) = [];
countc = zeros(1,mwl);
for j = totc
    countc(j) = countc(j) + 1;
end
Xs = (1:mwl);
bar(Xs,countc);
hold on
xlabel('Length of Word');
ylabel('Number of Occurrences');
title(['Can we read ' filename(1:end-4) '?']);
end