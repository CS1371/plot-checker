function [str,ar] = proctorTest(fn,per)
    [num,txt,jill] = xlsread(fn);
    [fuccboi, r] = strtok(txt{1},'(');
    mt = r(2:end-1);
    [~,r] = strtok(txt{2},'(');
    dr = r(2:end-1);
    xval = num(:,1);
    yval = num(:,2);
    derive = diff(yval)./diff(xval);
    mx = xval(1:end-1) + (diff(xval)./2);
    xvalx = spline(derive,mx,0);
    mdw = spline(xval,yval,xvalx);
    percent = per/100;
    sp = mdw*percent;
    yval = yval(yval-stndProc>=0);
    xval = xval(yval-stndProc>=0);
    ar = trapz(xval,(yval-stndProc));
    xvalx = round(xvalx,3);
    mdw = round(mdw,3);
    ar = round(ar,3);
    str = sprintf('%0.3f %s, %0.3f %s',xvalx,mt,mdw,dr);
end