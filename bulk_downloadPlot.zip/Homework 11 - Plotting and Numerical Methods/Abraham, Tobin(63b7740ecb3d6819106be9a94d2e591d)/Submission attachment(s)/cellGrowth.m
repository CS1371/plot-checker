function cellGrowth(cvec,tvec)
    figure(1)
    plot(tvec,cvec,'r.');
    hold on
    mn = mean(cvec);
    vecc = [];
    for i = 1:length(tvec)
        vecc = [vecc, mn];
    end
    plot(tvec,vecc,'b-.');
    my = max(cvec);
    vecc = [];
    for i = 1:length(tvec)
        vecc = [vecc,my];
    end
    plot(tvec,vecc,'m--')
    lit = (min(tvec))-((max(tvec))*.05);
    ut = (max(tvec))+((max(tvec))*.05);
    lc = (min(cvec))-((max(cvec))*.05);
    uc = (max(cvec))+((max(cvec))*.05);
    axis ([lit,ut,lc,uc])
    axis square
    title('Cell Growth vs Time')
    xlabel('Time')
    ylabel('# Cells')
end