function cellGrowth(cells,times)
hold all
plot(times,cells,'r.');
plot(times,mean(cells).*ones(1,length(cells)),'b-.');
plot(times,max(cells).*ones(1,length(cells)),'m--');
ax = [min(times)-(.05.*max(times)) max(times)+(.05.*max(times))...
    min(cells)-(.05.*max(cells)) max(cells)+(.05.*max(cells))];
axis(ax);
axis square
title('Cell Growth vs Time')
xlabel('time')
ylabel('# cells')
end