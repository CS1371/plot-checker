function cellGrowth(cellcts,timepts)
vec=ones(1,length(cellcts));
meancellcts=mean(cellcts);
meancellcts=meancellcts.*vec;
maxcellcts=max(cellcts);
maxcellcts=maxcellcts.*vec;
figure(1)
hold on
plot(timepts,cellcts,'r.',timepts,meancellcts,'b-.',timepts,maxcellcts,'m--');
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')
yaxismax=max(cellcts)+(.05.*max(cellcts));
yaxismin=min(cellcts)-(.05.*min(cellcts));
xaxismax=max(timepts)+(.05.*max(timepts));
xaxismin=min(timepts)-(.05.*min(timepts));
axis([xaxismin xaxismax yaxismin yaxismax]);
axis square
end