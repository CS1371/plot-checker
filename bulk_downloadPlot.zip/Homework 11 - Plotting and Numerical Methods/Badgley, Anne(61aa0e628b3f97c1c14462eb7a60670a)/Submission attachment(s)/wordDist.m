function statement=wordDist(textfile)
fh=fopen(textfile);
[filename,~]=strtok(textfile,'.');
line=fgets(fh);

linenums=double(line);
mask=linenums>=33&linenums<=64;
linenums=linenums(~mask);
line=char(linenums);
wordlengths=[];
technology=0;
while ischar(line)
    linenums=double(line);
    mask=linenums>=33&linenums<=64;
    linenums=linenums(~mask);
    line=char(linenums);
    [word,rest]=strtok(line,' ');
    while ~isempty(word)
        wordnums=double(word);
        wordnums=wordnums(wordnums~=32);
        word=char(wordnums);
        lengthword=length(word);
        if strcmpi(word,'technology');
            technology=technology+1;
        end
        [word,rest]=strtok(rest,' ');
        wordlengths=[wordlengths,lengthword];
    end
    wordlengths(end)=wordlengths(end)-2;
    line=fgets(fh);

    
end
wordlengths=sort(wordlengths);
maxlength=max(wordlengths);
if technology>0
    statement='We''re at Georgia Tech, we can read that!';
elseif maxlength<=13
    statement='We''re at Georgia Tech, we can read that!';
else
    statement='We''re at Georgia Tech, we can''t read that :(';
end
counts=histc(wordlengths,1:maxlength);
figure(1);
bar(counts);
xlabel('Length of Word');
ylabel('Number of Occurences');
title(sprintf('Can we read %s?',filename));



fclose(fh);

end