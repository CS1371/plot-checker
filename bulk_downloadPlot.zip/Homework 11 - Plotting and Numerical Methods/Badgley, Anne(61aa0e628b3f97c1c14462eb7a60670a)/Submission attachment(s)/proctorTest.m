function [statement,area]=proctorTest(xlfile,standardprocpercentile)
[nums,txt,raw]=xlsread(xlfile);
moisturecolumnheader=raw{1,1};
[~,moistureunit]=strtok(moisturecolumnheader,'(');
[moistureunit,~]=strtok(moistureunit,')');
moistureunit=moistureunit(2:end);
drycolumnheader=raw{1,2};
[~,dryunit]=strtok(drycolumnheader,'(');
[dryunit,~]=strtok(dryunit,')');
dryunit=dryunit(2:end);
moisturenums=nums(:,1);
drynums=nums(:,2);
diffmoisture=diff(moisturenums);
diffmoisture=diffmoisture./2;
diffmoisture=diffmoisture+moisturenums(1:end-1);
diffdry=diff(drynums);
deriv=diffdry./diffmoisture;

maxdry=interp1(deriv,drynums(1:end-1),0,'spline');
moisturemax=interp1(drynums,moisturenums,maxdry,'spline');
moisturemax=round(moisturemax,3);
maxdry=round(maxdry,3);
statement=sprintf('%.3f %s, %.3f %s',moisturemax, moistureunit, maxdry, dryunit);
standardprocvalue=(standardprocpercentile./100).*maxdry;
integralpointsdry=drynums(drynums>=standardprocvalue);
integralpointswet=moisturenums(drynums>=standardprocvalue);
area=trapz(integralpointswet,integralpointsdry);
w=max(integralpointswet)-min(integralpointswet);
rectangle=w.*standardprocvalue;
area=area - rectangle;
area=round(area,3);
end