function answer=airfoilz(attackangles,liftcoefficients,angles)
polynomial=polyfit(attackangles,liftcoefficients,2);
figure(1)
hold on
anglesmin=min(attackangles);
anglesmax=max(attackangles);
newangles=[anglesmin:anglesmax];
vec=polynomial(1).*newangles.^2+polynomial(2).*newangles+polynomial(3);
answer=spline(newangles,vec,angles);
plot(attackangles,liftcoefficients,'b*',newangles,vec,'k-');
answer=round(answer,3);
end