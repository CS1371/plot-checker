function cellGrowth( cells, times )
plot(times,cells,'r.');
hold on

means = zeros(1,length(times));
means(:) = mean(cells);
plot(times,means,'b-.')

hold on
theMax = zeros(1,length(times));
theMax(:) = max(cells);
plot(times,theMax,'m--')
hold off

xmin = min(times) - 0.05.*max(times);
xmax = 1.05.*max(times);
ymin = min(cells) - 0.05.*max(cells);
ymax = 1.05.*max(cells);

axis([xmin,xmax,ymin,ymax])
axis square
title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')


end

