function molecule( seg, ang, cir )
x = [0];
y = [0];
theta = 0;
for i = 1:length(seg)
    r = seg(i);
    theta = theta + ang(i);
    x = [x, r .* cosd(theta) + x(i)];
    y = [y, r .* sind(theta) + y(i)];
end

plot(x,y,'k')
hold on
[centerLocs, rad] = findCenter([x;y]);
centerLocs = centerLocs(:,cir);
rad = rad(:,cir) .* 0.65;
num = length(rad);
for j = 1:num
    x2 = rad(j) .* cosd(linspace(0,360)) + centerLocs(1,j);
    y2 = rad(j) .* sind(linspace(0,360)) + centerLocs(2,j);
    plot(x2,y2,'b')
    hold on
end
axis equal
axis off
end

