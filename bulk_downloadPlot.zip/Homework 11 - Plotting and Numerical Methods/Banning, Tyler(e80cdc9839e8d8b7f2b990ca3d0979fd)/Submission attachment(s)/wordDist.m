function [ str ] = wordDist( fn )
fh = fopen(fn,'r');
line = fgetl(fh);
canRead = true;
alwaysRead = false;
maxLength = 0;
while ischar(line)
    mask = (line < 'A' | (line > 'Z' & line < 'a') | line > 'z') & line ~= ' ';
    line(mask) = [];
    [word rest] = strtok(line,' ');
    while length(word)>0
        if length(word)>13
            canRead = false;
        end
        if strcmpi(word,'technology')
            alwaysRead = true;
        end
        if length(word)>maxLength
            maxLength = length(word);
        end
        
        [word rest] = strtok(rest,' ');
    end
    line = fgetl(fh);
end
fclose(fh);
if canRead
    str = 'We''re at Georgia Tech, we can read that!';
else
    str = 'We''re at Georgia Tech, we can''t read that :(';
end

if alwaysRead
    str = 'We''re at Georgia Tech, we can read that!';
end

fh2 = fopen(fn, 'r');
line2 = fgetl(fh2);
counter = zeros(1,maxLength);
while ischar(line2)
    mask2 = (line2 < 'A' | (line2 > 'Z' & line2 < 'a') | line2 > 'z') & line2 ~= ' ';
    line2(mask2) = [];
    [word2 rest2] = strtok(line2,' ');
    while length(word2)>0
        counter(length(word2)) = counter(length(word2)) + 1;
        [word2 rest2] = strtok(rest2,' ');
    end
    line2 = fgetl(fh2);
end
fclose(fh);

bar(1:maxLength,counter)
xlabel('Length of Word')
ylabel('Number of Occurrences')
name = strtok(fn,'.');
title(sprintf('Can we read %s?',name))



end

