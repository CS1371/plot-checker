function [ str, area ] = proctorTest( fn, pct )
[num, text, raw] = xlsread(fn);
[numRow, numCol] = size(num);
mCont = [];
dryWeight = [];
for i = 1:numRow
    mCont = [mCont , num(i,1)];
    dryWeight = [dryWeight, num(i,2)];
end
dy = diff(dryWeight);
dx = mCont(1:end-1) + 0.5 .* diff(mCont);
yi = dy./diff(mCont);
xi = spline(yi,dx,0);
%plot(mCont,dryWeight)
maxWeight = spline(mCont,dryWeight,xi);
corrCont = xi;
[junk,unitCont] =  strtok(text{1},'(');
unitCont =  unitCont(2:end-1);
[junk,unitWeight] =  strtok(text{2},'(');
unitWeight =  unitWeight(2:end-1);
str = [num2str(corrCont),' ',unitCont,', ',num2str(roundn(maxWeight,-3)),' ', unitWeight];
low = 0.01.*pct.*maxWeight;
y2 = dryWeight - low;
mask = y2>=0;
toInt = y2(mask);

area = roundn(trapz(mCont(mask),toInt),-3);
end

