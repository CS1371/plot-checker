function [ lift ] = airfoilz( attacks, liftVec, angleVec )
plot(attacks,liftVec,'b*')
hold on
[junk,a] = min(attacks);
[junk2, b] = max(attacks);
xi = attacks(a):1:attacks(b);
coeff = polyfit(attacks,liftVec,2);
curve = polyval(coeff,xi);
plot(xi,curve,'k-')
hold on

lift = roundn(spline(xi,curve,angleVec),-3);

end

