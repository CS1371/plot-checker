function [str, area] = proctorTest (name, percent)
[num txt raw] = xlsread(name);

A = txt{1};
B = txt{2};

[~, unit1] = strtok(A, '(');
mask1 = unit1 ~= '(' & unit1 ~= ')';
unit1 = unit1(mask1>0);

[~, unit2] = strtok(B, '(');
mask2 = unit2 ~= '(' & unit2 ~= ')';
unit2 = unit2(mask2>0);

x = num(:,1)';
y = num(:,2)';

derivY = diff(y) ./ diff(x);
derivX = [];

for i = 1:length(x)-1
    C = (x(i) + x(i+1)) ./ 2; 
    derivX = [derivX C];
end

newx = interp1(derivY, derivX, 0, 'spline');
newy = interp1(x, y, newx, 'spline');

aPercent = percent ./ 100;
line = newy .* aPercent;
J = y - line;
J = J(J>=0);
K = x(J>=0);

area = round(trapz(K, J),3);
str = sprintf('%0.3f %s, %0.3f %s', newx, unit1, newy, unit2);

end