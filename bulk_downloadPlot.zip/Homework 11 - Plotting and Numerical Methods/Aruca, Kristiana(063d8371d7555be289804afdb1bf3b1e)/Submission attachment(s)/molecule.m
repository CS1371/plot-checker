function molecule(lengths, angles, circles)

newAngles = cumsum(angles);
xVec = [];
yVec = [];

xVec(1) = 0;
yVec(1) = 0;

varX = 0;
varY = 0;

for i= 1:length(lengths)
    x = lengths(i) .* cosd(newAngles(i));
    y = lengths(i) .* sind(newAngles(i));
    
    varX = varX + x;
    varY = varY + y;
    
    xVec = [xVec varX];
    yVec = [yVec varY];
end

figure;
plot(xVec, yVec, 'k-');

axis off;
axis square;

hold on; 

[centers, r] = findCenter([xVec ;yVec]);
newR = .65 .* r;
col = find(circles);
centers = centers(:, col);
newR = newR(col);

for j = 1:length(newR)
    theta = linspace(0,2*pi);
    circx = newR(j) .* cos(theta);
    circy = newR(j) .* sin(theta);
    
    centersx = centers(1,j);
    centersy = centers(2,j);
    
    newcircx = circx + centersx;
    newcircy = circy + centersy;
    
    plot(newcircx,newcircy,'b-');

end
hold off;
end