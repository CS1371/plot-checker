function [coeff] = airfoilz (anglesAttack, vecCoeff, angles)

coeff2 = polyfit(anglesAttack, vecCoeff, 2);
A = min(anglesAttack);
B = max(anglesAttack);

new_x = A:B;
new_y = polyval(coeff2, new_x);

plot(new_x, new_y, 'k-');
hold on;
plot(anglesAttack, vecCoeff, 'b*');

coeff = round(spline(new_x, new_y, angles),3);

hold off;

end 