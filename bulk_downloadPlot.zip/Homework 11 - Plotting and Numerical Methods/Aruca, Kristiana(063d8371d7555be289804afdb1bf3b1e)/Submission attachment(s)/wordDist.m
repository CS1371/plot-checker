function [out1] = wordDist (str1)

fh = fopen(str1);                                   %opening file 
line = fgetl(fh);                                   %getting first line of txt

vec = [];                                           %creating empty vec
techcheck = 0;                                      %setting variable 

while ischar(line)                                  %running until out of lines
    while ~isempty(line)                            %running until out of words in line
        [tok, line] = strtok(line);                 
    
        mask = tok >= 'A' & tok<= 'Z';              %gets rid of extraneous characters
        mask1 = tok >= 'a' & tok <= 'z';            %gets rid of extraneous characters
        mask(mask1>0) = mask1(mask1>0);
        word = tok(mask>0);
        
        A = length(word);                           %finding the length of the word
        vec = [vec A];                              %adding word length to the vec
        
        if techcheck == 0                           %checking only if there isnt a previous "technology"
            B = strcmpi(word, 'technology');        %checking the word against "technology"
        
            if B 
                techcheck = 1;
            else
                techcheck = 0;
            end
        end
        
    end
    line = fgetl(fh);                               %getting new line
end

vec(vec==0) = [];                                   %getting rid of any extra values
C = min(vec);                                       %finding min of word lengths
D = max(vec);                                       %finding max of word lengths

y = [];                                             
for i = C:D                                         %checking for all word lengths
    numVec = vec(vec==i);                           %where the vec is equal to value of i
    lnumVec = length(numVec);                       %finding the length of the number of i values
    y = [y lnumVec];                                %adding the value to the new vec
end
    
newname = str1(1:end-4);                            %getting name of book
plotname = sprintf('Can we read %s?', newname);     %putting the book name into the string

bar(C:D, y);                                        %creating bar graph
xlabel('Length of Word');
ylabel('Number of Occurrences');
title(plotname);

if techcheck 
    out1 = 'We''re at Georgia Tech, we can read that!';
elseif D<=13
    out1 = 'We''re at Georgia Tech, we can read that!';
else
    out1 = 'We''re at Georgia Tech, we can''t read that :(';
end

fclose(fh);

end