function cellGrowth (cellcts, timepts)

plot(timepts, cellcts, 'r.');
hold on;

b = mean(cellcts);
mean_y = cellcts;
mean_y(1:end) = b;
plot(timepts, mean_y, 'b-.');

a = max(cellcts);
max_y = cellcts;
max_y(1:end) = a;
plot(timepts, max_y, 'm--');

hold off;

A = max(cellcts);
Aa = A .* 0.05;
yaxismax = A + Aa;

B = min(cellcts);
yaxismin = B - Aa;

C = max(timepts);
Cc = C .* 0.05;
xaxismax = C + Cc;

D = min(timepts);
xaxismin = D - Cc;

title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
axis([xaxismin xaxismax yaxismin yaxismax]);
axis square;

end 