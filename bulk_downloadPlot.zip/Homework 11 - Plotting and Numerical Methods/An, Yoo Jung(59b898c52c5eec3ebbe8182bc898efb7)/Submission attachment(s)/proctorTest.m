function [str, area] = proctorTest (xls, psp)

[num, ~, raw] = xlsread(xls);

mcunit = raw{1,1};
[~,mcunit] = strtok(mcunit, '(');
mcunit = mcunit(2:end-1);

duwunit = raw{1,2};
[~,duwunit] = strtok(duwunit, '(');
duwunit = duwunit(2:end-1);

x = num(:,1)';
y = num(:,2)';

dy = diff(y) ./ diff(x);
dx = 0.5 * diff(x) + x(1:end-1);

maxX = spline(dy,dx,0);
maxY = spline(x,y,maxX);

str = sprintf('%0.3f %s, %0.3f %s', maxX, mcunit, maxY, duwunit);

psp = psp ./ 100;
minY = maxY .* psp
newY = y - minY;
mask = newY > 0;
newY = newY(mask);
newX = x(mask);

area = round(trapz(newX, newY),3);
end