function cellGrowth (cell, time)

xmin = min(time);
xmax = max(time);
xdiff = xmax - xmin;
x5 = 0.05 .* xdiff;
xmin = xmin - x5;
xmax = xmax + x5;
x = [xmin xmax];

ymin = min(cell);
ymax = max(cell);
ydiff = ymax - ymin;
y5 = 0.05 .* ydiff;
ymin = ymin - y5;
ymax = ymax + y5;
y = [ymin ymax];

xlim(x);
ylim(y);

plot(time,cell,'r.');

hold on

avg = mean(cell);
empty = zeros(length(time));
avgs = empty;
avgs(:) = avg;
max0 = max(cell);
maxs = empty;
maxs(:) = max0;

plot(time, avgs, 'b-.')
plot(time, maxs, 'm--')

axis square

title('Cell Growth vs Time')
xlabel('Time')
ylabel('# Cells')

end