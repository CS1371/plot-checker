function [coeff] = airfoilz (attack, lift, angles)

plot(attack, lift, 'b*')

hold on

x = min(attack):max(attack);
coeff = polyfit(attack, lift, 2);
yi = polyval(coeff,x);
plot(x,yi,'k-');

coeff = round(spline(x,yi,angles),3);
end