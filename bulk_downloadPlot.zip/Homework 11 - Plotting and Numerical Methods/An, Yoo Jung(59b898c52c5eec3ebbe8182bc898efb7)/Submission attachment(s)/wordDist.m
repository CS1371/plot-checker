function [lvl] = wordDist (txt)

fh = fopen(txt);
line = fgetl(fh);
count = [];
technology = false;

while ischar(line)
    mask = line >= 65 & line <=90 | line >= 97 & line <= 122 | line == 32;
    line = line(mask);
    while ~isempty(line)
        [a line] = strtok(line);
        num = length(a);
        if strcmp(a, 'technology')
            technology = true;
        end
        if num > length(count)
            count(num) = 1;
        else count(num) = count(num) + 1;
        end
    end
    line = fgetl(fh);
end

if length(count) <= 13
    lvl = 'We''re at Georgia Tech, we can read that!';
elseif technology
    lvl = 'We''re at Georgia Tech, we can read that!';
else lvl = 'We''re at Georgia Tech, we can''t read that :(';
end

bar(count)

ttl = txt(1:end-4);
title(sprintf('Can we read %s?', ttl))
xlabel('Length of Word')
ylabel('Number of Occurrences')

end