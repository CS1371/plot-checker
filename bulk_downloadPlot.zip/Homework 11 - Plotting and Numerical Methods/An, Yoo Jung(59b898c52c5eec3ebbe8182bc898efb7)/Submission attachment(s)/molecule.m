function molecule (seg, ang, hex)

x = [0];
y = [0];
degree = 0;

for i = 1:length(seg)
    degree = degree + ang(i);
    x(i+1) = x(i) + seg(i).*cosd(degree);
    y(i+1) = y(i) + seg(i).*sind(degree);
    plot(x,y,'k')
    hold on
end

centers = findCenter([x;y]);
centers = centers(:,hex);
[~,c] = size(centers);

for c = 1:c;
    r = seg(1).* 0.65;
    theta = linspace(0,2*pi);
    x = r.*cos(theta) + centers(1,c);
    y = r.*sin(theta) + centers(2,c);
    plot(x,y,'b')
end

axis equal
axis off
end