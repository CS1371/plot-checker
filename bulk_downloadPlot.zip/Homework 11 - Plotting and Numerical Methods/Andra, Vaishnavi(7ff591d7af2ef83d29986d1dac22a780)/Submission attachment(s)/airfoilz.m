function liftco = airfoilz(x,y,angles)
eq = polyfit(x,y,2);
plot(x,y,'b*');
hold on;
minval = min(x);
diff = max(x) - minval;
x1 = (1:diff+1) + minval - 1;
y1 = (eq(1).*x1.*x1) + (eq(2).*x1) + eq(3);
plot(x1,y1,'k');
liftco = round(interp1(x1,y1,angles,'spline'),3);
end