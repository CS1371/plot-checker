function molecule(len,ang,benzene)
x = [0];
y = [0];
angletracker = 0;
for i = 1:length(len)
    angletracker = mod(angletracker+ang(i),360);
    x(end+1) = x(end) + (len(i).*cosd(angletracker));
    y(end+1) = y(end) + (len(i).*sind(angletracker));
end
plot(x,y,'k');
hold on;
axis square;
axis off;

[centers,sizes] = findCenter([x;y]);
centers(:,~benzene) = [];
sizes(~benzene) = [];
sizes = (0.65).*sizes;

for j = 1:length(sizes)
    pnt = linspace(0,360);
    x = sizes(j).*cosd(pnt);
    y = sizes(j).*sind(pnt);
    x = x+centers(1,j);
    y = y+centers(2,j);
    plot(x,y,'b');
end
end