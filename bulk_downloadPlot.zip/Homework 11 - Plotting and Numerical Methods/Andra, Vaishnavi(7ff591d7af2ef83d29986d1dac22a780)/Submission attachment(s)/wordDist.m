function result = wordDist(filename)
fh = fopen(filename);
line = fgetl(fh);
techtracker = 0;
y = [];
while ischar(line)
    [tok,rem] = strtok(line);
    while ~isempty(tok)
        tok = tok(find((tok>='a'&tok<='z')|(tok>='A'&tok<='Z')));
        if strcmpi(tok,'technology') == 1
            techtracker = 1;
        end
        if length(tok) > length(y)
            y(length(tok)) = 1;
        elseif ~isempty(tok)
            y(length(tok)) = y(length(tok))+1;
        end
        [tok,rem] = strtok(rem);
    end
    line = fgetl(fh);
end
x = 1:length(y);
bar(x,y);
header = sprintf('Can we read %s?',filename(1:end-4));
title(header);
xlabel('Length of Word');
ylabel('Number of Occurrences');

if techtracker > 0
    result = 'We''re at Georgia Tech, we can read that!';
elseif length(y) <= 13
    result = 'We''re at Georgia Tech, we can read that!';
else
    result = 'We''re at Georgia Tech, we can''t read that :(';
end
end