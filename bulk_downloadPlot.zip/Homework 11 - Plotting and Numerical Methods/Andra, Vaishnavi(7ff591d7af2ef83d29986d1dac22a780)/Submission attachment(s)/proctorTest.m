function [result,area] = proctorTest(filename,perc)
[num,txt] = xlsread(filename);
x = num(:,1);
y = num(:,2);
dydx = diff(y)./diff(x);
ddx = [];
for i = 1:length(x)-1
    ddx(i) = mean([x(i),x(i+1)]);
end
xmax = spline(dydx,ddx,0);
ymax = spline(x,y,xmax);
header1 = txt{1};
header2 = txt{2};
unitind1 = find(header1=='('|header1==')');
unitind2 = find(header2=='('|header2==')');
unit1 = header1(unitind1(1)+1:unitind1(2)-1);
unit2 = header2(unitind2(1)+1:unitind2(2)-1);
result = sprintf('%0.3f %s, %0.3f %s',xmax,unit1,ymax,unit2);
newxaxis = perc.*ymax./100;
y = y - newxaxis;
y = y(find(y>=0));
x = x(find(y>=0));
area = round(trapz(x,y),3);
end