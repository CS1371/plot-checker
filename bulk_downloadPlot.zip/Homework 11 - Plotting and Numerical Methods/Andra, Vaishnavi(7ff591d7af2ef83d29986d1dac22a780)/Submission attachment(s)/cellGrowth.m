function cellGrowth(cellCounts,time)
meanval = mean(cellCounts);
maxval = max(cellCounts);
line = ones(1,length(time));
plot(time,cellCounts,'r.',time,line.*meanval,'b-.',time,line.*maxval,'m--');
axis square;
title('Cell Growth vs Time');
xlabel('Time');
ylabel('# Cells');
xmin = min(time);
xmax = max(time);
ymin = min(cellCounts);
ymax = max(cellCounts);
xperc = 0.05.*(xmax-xmin);
yperc = 0.05.*(ymax-ymin);
xmin = xmin-xperc;
xmax = xmax+xperc;
ymin = ymin-yperc;
ymax = ymax+yperc;
axis([xmin,xmax,ymin,ymax]);
end